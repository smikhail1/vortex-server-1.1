from vortex_candle_utils import parse_bitget_candles_payload, parse_bitget_candles_data
import asyncio
from typing import Dict, List, Optional

from config import CONFIG
from market_regime import MarketRegimeEvaluator
from validators import safe_float, safe_str


class TAService:
    """
    VORTEX 1.5 TA layer based on real Bitget candles.

    Было:
    - EMA/RSI/ATR по 2-секундным тикам.

    Стало:
    - EMA20/EMA50 по 30m candles;
    - RSI по 30m candles;
    - ATR по 30m candles;
    - trend_4h по 4H candles;
    - recent_high/recent_low по реальным свечам;
    - breakout/retest/pullback по реальной структуре.
    """

    def __init__(self, state_manager, candle_service=None, logger=None) -> None:
        self.state = state_manager
        self.candle_service = candle_service
        self.logger = logger
        self.regime = MarketRegimeEvaluator()

    @staticmethod
    def _ema(values: List[float], period: int) -> float:
        clean = [safe_float(x, 0.0) for x in values if safe_float(x, 0.0) > 0]
        if not clean:
            return 0.0
        k = 2 / (period + 1)
        ema_val = float(clean[0])
        for value in clean[1:]:
            ema_val = value * k + ema_val * (1 - k)
        return ema_val

    @staticmethod
    def _rsi(closes: List[float], period: int = 14) -> float:
        if len(closes) < period + 1:
            return 50.0
        gains = []
        losses = []
        tail = closes[-(period + 1):]
        for i in range(1, len(tail)):
            delta = tail[i] - tail[i - 1]
            if delta >= 0:
                gains.append(delta)
                losses.append(0.0)
            else:
                gains.append(0.0)
                losses.append(abs(delta))
        avg_gain = sum(gains) / period
        avg_loss = sum(losses) / period
        if avg_loss == 0:
            return 100.0 if avg_gain > 0 else 50.0
        rs = avg_gain / avg_loss
        return 100.0 - (100.0 / (1.0 + rs))

    @staticmethod
    def _atr(candles: List[Dict[str, float]], period: int = 14) -> float:
        if len(candles) < 2:
            return 0.0
        tail = candles[-(period + 1):]
        trs = []
        for i in range(1, len(tail)):
            high = safe_float(tail[i].get("high"), 0.0)
            low = safe_float(tail[i].get("low"), 0.0)
            prev_close = safe_float(tail[i - 1].get("close"), 0.0)
            if high <= 0 or low <= 0 or prev_close <= 0:
                continue
            tr = max(
                high - low,
                abs(high - prev_close),
                abs(low - prev_close),
            )
            trs.append(tr)
        return sum(trs) / len(trs) if trs else 0.0

    @staticmethod
    def _volume_ratio(candles: List[Dict[str, float]], period: int = 20) -> float:
        if len(candles) < 3:
            return 1.0
        last = safe_float(candles[-1].get("quote_volume"), 0.0)
        if last <= 0:
            last = safe_float(candles[-1].get("volume"), 0.0)
        prev = candles[-(period + 1):-1] if len(candles) > period else candles[:-1]
        volumes = []
        for item in prev:
            value = safe_float(item.get("quote_volume"), 0.0)
            if value <= 0:
                value = safe_float(item.get("volume"), 0.0)
            if value > 0:
                volumes.append(value)
        if not volumes:
            return 1.0
        avg = sum(volumes) / len(volumes)
        if avg <= 0:
            return 1.0
        return max(0.1, last / avg)


    @staticmethod
    def _candle_momentum(candles: List[Dict[str, float]], lookback: int = 3) -> str:
        """Return bullish/bearish/mixed using the latest closed 30m candles."""
        if len(candles) < lookback + 1:
            return "mixed"
        tail = candles[-(lookback + 1):-1]
        bullish = 0
        bearish = 0
        for c in tail:
            close = safe_float(c.get("close"), 0.0)
            open_ = safe_float(c.get("open"), 0.0)
            if close > open_:
                bullish += 1
            elif close < open_:
                bearish += 1
        if bullish >= lookback - 1:
            return "bullish"
        if bearish >= lookback - 1:
            return "bearish"
        return "mixed"

    @classmethod
    def _rsi_direction(cls, closes: List[float], fast: int = 7, slow: int = 14) -> str:
        """Return RSI slope proxy using fast RSI vs slow RSI."""
        if len(closes) < slow + 1:
            return "flat"
        rsi_fast = cls._rsi(closes, fast)
        rsi_slow = cls._rsi(closes, slow)
        if rsi_fast > rsi_slow + 2.0:
            return "rising"
        if rsi_fast < rsi_slow - 2.0:
            return "falling"
        return "flat"

    @staticmethod
    def _pivot_structure(candles: List[Dict[str, float]], lookback: int = 20) -> str:
        """Simple structure proxy: HH/HL, LH/LL, or undefined."""
        if len(candles) < lookback:
            return "undefined"
        tail = candles[-lookback:]
        highs = [safe_float(c.get("high"), 0.0) for c in tail]
        lows = [safe_float(c.get("low"), 0.0) for c in tail]
        if not highs or not lows or max(highs) <= 0 or max(lows) <= 0:
            return "undefined"
        mid = lookback // 2
        first_high = max(highs[:mid])
        first_low = min(lows[:mid])
        last_high = highs[-1]
        last_low = lows[-1]
        if last_high > first_high and last_low > first_low:
            return "HH_HL"
        if last_high < first_high and last_low < first_low:
            return "LH_LL"
        return "undefined"

    def _trend_from_4h(self, candles_4h: List[Dict[str, float]]) -> str:
        closes = [safe_float(x.get("close"), 0.0) for x in candles_4h if safe_float(x.get("close"), 0.0) > 0]
        if len(closes) < 20:
            return "neutral"
        ema20 = self._ema(closes[-40:], 20)
        ema50 = self._ema(closes[-80:], 50) if len(closes) >= 50 else self._ema(closes, 50)
        price = closes[-1]
        if price <= 0 or ema20 <= 0 or ema50 <= 0:
            return "neutral"
        gap_pct = abs(ema20 - ema50) / price * 100.0
        if ema20 > ema50 and price >= ema20:
            return "strong_up" if gap_pct >= CONFIG.regime.strong_trend_ema_gap_pct else "up"
        if ema20 < ema50 and price <= ema20:
            return "strong_down" if gap_pct >= CONFIG.regime.strong_trend_ema_gap_pct else "down"
        return "neutral"

    def _bias_from_30m(self, price: float, ema20: float, ema50: float) -> str:
        if price <= 0 or ema20 <= 0 or ema50 <= 0:
            return "neutral"
        if price > ema20 >= ema50:
            return "up"
        if price < ema20 <= ema50:
            return "down"
        return "neutral"

    def _build_symbol_ta(
        self,
        symbol: str,
        candles_30m: List[Dict[str, float]],
        candles_4h: List[Dict[str, float]],
        live_price: float = 0.0,
    ) -> Optional[Dict[str, object]]:
        # v1.6.3.1: TA revive guard. After restart candle cache may have less than
        # CONFIG.regime.min_history_bars, but 30 closed 30m candles is enough for EMA/RSI/ATR bootstrap.
        min_bars = min(int(getattr(CONFIG.regime, "min_history_bars", 30)), 30)
        if len(candles_30m) < min_bars:
            return None

        closes = [safe_float(x.get("close"), 0.0) for x in candles_30m if safe_float(x.get("close"), 0.0) > 0]
        if len(closes) < min_bars:
            return None

        price = safe_float(live_price, 0.0) or closes[-1]
        if price <= 0:
            return None

        ema10 = self._ema(closes[-30:], 10)
        ema20 = self._ema(closes[-50:], 20)
        ema50 = self._ema(closes[-100:], 50) if len(closes) >= 50 else self._ema(closes, 50)
        rsi = self._rsi(closes, 14)
        atr = self._atr(candles_30m, 14)
        if atr <= 0:
            atr = price * 0.005
        atr_pct = atr / price * 100.0 if price > 0 else 0.0
        vol_ratio = self._volume_ratio(candles_30m, 20)
        candle_momentum_30m = self._candle_momentum(candles_30m, lookback=3)
        rsi_direction_30m = self._rsi_direction(closes, fast=7, slow=14)
        pivot_structure_30m = self._pivot_structure(candles_30m, lookback=20)

        lookback = candles_30m[-21:-1] if len(candles_30m) >= 21 else candles_30m[:-1]
        if not lookback:
            lookback = candles_30m[-20:]
        recent_high = max(safe_float(x.get("high"), price) for x in lookback)
        recent_low = min(safe_float(x.get("low"), price) for x in lookback)
        recent_mid = (recent_high + recent_low) / 2.0 if recent_high > recent_low else price

        breakout = False
        breakout_dir = ""
        breakout_level = 0.0
        if price > recent_high + atr * CONFIG.regime.breakout_buffer_atr:
            breakout = True
            breakout_dir = "up"
            breakout_level = recent_high
        elif price < recent_low - atr * CONFIG.regime.breakout_buffer_atr:
            breakout = True
            breakout_dir = "down"
            breakout_level = recent_low

        near_support = price <= (recent_low + atr * 0.40)
        near_resistance = price >= (recent_high - atr * 0.40)

        zone_buffer = price * CONFIG.regime.pullback_zone_buffer_pct
        ema50_tol = price * CONFIG.regime.pullback_ema50_tolerance_pct

        pullback_long_ready = (
            price > ema50 * 0.995
            and price <= ema20 + zone_buffer
            and price >= ema50 - ema50_tol
            and ema20 >= ema50
            and candle_momentum_30m in {"bullish", "mixed"}
            and rsi_direction_30m in {"rising", "flat"}
        )
        pullback_short_ready = (
            price < ema50 * 1.005
            and price >= ema20 - zone_buffer
            and price <= ema50 + ema50_tol
            and ema20 <= ema50
            and candle_momentum_30m in {"bearish", "mixed"}
            and rsi_direction_30m in {"falling", "flat"}
        )

        retest_long_ready = (
            breakout_dir == "up"
            and breakout_level > 0
            and abs(price - breakout_level) <= atr * CONFIG.regime.retest_buffer_atr
        )
        retest_short_ready = (
            breakout_dir == "down"
            and breakout_level > 0
            and abs(price - breakout_level) <= atr * CONFIG.regime.retest_buffer_atr
        )

        setup_zone = "-"
        if near_support:
            setup_zone = "support"
        elif near_resistance:
            setup_zone = "resistance"
        elif abs(price - ema20) <= zone_buffer:
            setup_zone = "ema20"
        elif abs(price - ema50) <= ema50_tol:
            setup_zone = "ema50"

        trend_4h = self._trend_from_4h(candles_4h)
        trend_bias_30m = self._bias_from_30m(price, ema20, ema50)

        base = {
            "price": round(price, 8),
            "ema10": round(ema10, 8),
            "ema20": round(ema20, 8),
            "ema50": round(ema50, 8),
            "rsi": round(rsi, 2),
            "rsi_main": round(rsi, 2),
            "candle_momentum_30m": candle_momentum_30m,
            "rsi_direction_30m": rsi_direction_30m,
            "pivot_structure_30m": pivot_structure_30m,
            "atr": round(atr, 8),
            "atr_pct": round(atr_pct, 4),
            "vol_ratio": round(vol_ratio, 4),
            "vol_ratio_30m": round(vol_ratio, 4),
            "vol_spike": vol_ratio >= CONFIG.regime.vol_spike_threshold,
            "recent_high": round(recent_high, 8),
            "recent_low": round(recent_low, 8),
            "recent_mid": round(recent_mid, 8),
            "dist_to_support": round(((price - recent_low) / price) * 100, 4) if price > 0 else 0.0,
            "dist_to_resistance": round(((recent_high - price) / price) * 100, 4) if price > 0 else 0.0,
            "imbalance": 1.0,
            "breakout": breakout,
            "breakout_dir": breakout_dir,
            "breakout_level": round(breakout_level, 8),
            "near_support": near_support,
            "near_resistance": near_resistance,
            "pullback_long_ready": pullback_long_ready,
            "pullback_short_ready": pullback_short_ready,
            "retest_long_ready": retest_long_ready,
            "retest_short_ready": retest_short_ready,
            "setup_zone": setup_zone,
            "trend_4h": trend_4h,
            "trend_bias_30m": trend_bias_30m,
            "trend_bias_1h": trend_bias_30m,
            "candle_source": "bitget",
            "candles_30m_count": len(candles_30m),
            "candles_4h_count": len(candles_4h),
        }

        regime_ctx = self.regime.build_symbol_context(base)
        base.update(regime_ctx)
        return base

    async def loop(self) -> None:
        while True:
            try:
                dash = await self.state.get_dashboard_state()
                prices = dash.get("market", {}).get("prices", {}) or {}
                fut_pool = dash.get("system", {}).get("fut_pool", []) or []
                spot_pool = dash.get("system", {}).get("spot_pool", []) or []
                symbols = []
                seen = set()
                for raw in list(fut_pool) + list(spot_pool):
                    sym = safe_str(raw).upper()
                    if sym and sym not in seen:
                        symbols.append(sym)
                        seen.add(sym)

                ta_data: Dict[str, Dict[str, object]] = {}

                for symbol in symbols:
                    if self.candle_service is None:
                        continue

                    # v1.6.3.1: try futures first, then spot, then generic snapshot.
                    # Some symbols can be present in spot_pool while the old code always requested only "fut".
                    snapshot = self.candle_service.get_symbol_snapshot(symbol, "fut") or {}
                    candles_30m = snapshot.get("candles_30m", []) or []
                    candles_4h = snapshot.get("candles_4h", []) or []

                    if not candles_30m:
                        snapshot = self.candle_service.get_symbol_snapshot(symbol, "spot") or {}
                        candles_30m = snapshot.get("candles_30m", []) or []
                        candles_4h = snapshot.get("candles_4h", []) or []

                    # Last-resort compatibility for candle services that ignore market arg differently.
                    if not candles_30m:
                        try:
                            snapshot = self.candle_service.get_symbol_snapshot(symbol) or {}
                            candles_30m = snapshot.get("candles_30m", []) or []
                            candles_4h = snapshot.get("candles_4h", []) or []
                        except TypeError:
                            pass

                    live_price = safe_float(prices.get(symbol), 0.0)

                    if self.logger:
                        self.logger.info("TA_BUILD", "symbol candles", {
                            "symbol": symbol,
                            "candles_30m": len(candles_30m),
                            "candles_4h": len(candles_4h),
                            "live_price": live_price,
                        })

                    item = self._build_symbol_ta(symbol, candles_30m, candles_4h, live_price=live_price)
                    if item is not None:
                        ta_data[symbol] = item
                    elif self.logger:
                        self.logger.info("TA_SKIP", "symbol skipped", {
                            "symbol": symbol,
                            "candles_30m": len(candles_30m),
                            "candles_4h": len(candles_4h),
                            "reason": "insufficient_or_invalid_candles",
                        })

                await self.state.update_ta_data(ta_data)

                if self.logger:
                    self.logger.info("TA_SERVICE", "ta data updated", {
                        "symbols": len(ta_data),
                        "source": "candles",
                    })

            except Exception as exc:
                await self.state.add_sys_log("❌ [TA]", str(exc))
                if self.logger:
                    self.logger.error("TA_SERVICE", "ta loop failed", {"error": str(exc)})

            await asyncio.sleep(CONFIG.loops.ta_sec)
