import asyncio
import copy
import time
from collections import deque
from typing import Any, Deque, Dict, List, Optional

from config import CONFIG, DEFAULT_STATE_META
from validators import (
    normalize_symbol,
    safe_float,
    safe_int,
    safe_str,
    validate_planner_payload,
    validate_position_payload,
    validate_symbol_health,
    validate_ta_payload,
    validate_watchlist_payload,
)


class StateManager:
    """
    Единственный источник истины по runtime-state сервера.

    Совместимость с Android-клиентом:
    - /api/dashboard -> market/account/positions/system/terminal/today/portfolio
    - /api/health
    - /api/spot-planner
    """

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._sys_logs: Deque[str] = deque(maxlen=CONFIG.logging.max_sys_logs)
        self._started_ts: float = time.time()

        self.state: Dict[str, Any] = {
            "meta": dict(DEFAULT_STATE_META),
            "market": {
                "prices": {},
                "price_timestamps": {},
                "ta_data": {},
                "symbol_health": {},
                "last_market_update_ts": 0.0,
                "last_ta_update_ts": 0.0,
            },
            "account": {
                "balances": {
                    "fut": float(CONFIG.futures.start_balance),
                    "spot": float(CONFIG.spot.start_balance),
                }
            },
            "positions": {
                "fut": {},
                "spot": {},
            },
            "system": {
                "fut_pool": [],
                "spot_pool": [],
                "macro": {
                    "btc_trend": "neutral",
                    "global_filter": "allow_all",
                    "binance_btc": 0.0,
                    "oi_amount": 0.0,
                    "fng_value": 50,
                },
                "rotation_timer": 0,
                "sys_logs": [],
                "uptime": "00:00:00",
                "ram_mb": "0",
                "ping_ms": "0",
            },
            "planner": {
                "market_data": {},
                "spot_ideas": [],
                "ideas": [],
                "generated_at": 0,
                "last_update_ts": 0,
                "mode": "PLANNER",
                "status": "idle",
            },
            "terminal": {
                "watchlist_mini": [],
            },
        }

    async def _copy_state(self) -> Dict[str, Any]:
        async with self._lock:
            self.state["system"]["sys_logs"] = list(self._sys_logs)
            return copy.deepcopy(self.state)

    async def get_dashboard_state(self) -> Dict[str, Any]:
        return await self._copy_state()

    async def get_spot_planner_state(self) -> Dict[str, Any]:
        async with self._lock:
            planner = copy.deepcopy(self.state["planner"])
            planner["spot_ideas"] = copy.deepcopy(planner.get("ideas", []))
            return planner

    async def get_health_state(self, mode: Optional[str] = None) -> Dict[str, Any]:
        async with self._lock:
            now = time.time()
            last_market = safe_float(self.state["market"].get("last_market_update_ts"), 0.0)
            last_ta = safe_float(self.state["market"].get("last_ta_update_ts"), 0.0)

            market_age = round(now - last_market, 3) if last_market > 0 else 9999.0
            ta_age = round(now - last_ta, 3) if last_ta > 0 else 9999.0

            if market_age <= 5 and ta_age <= 15:
                status = "online"
            elif market_age <= 15:
                status = "degraded"
            else:
                status = "offline"

            return {
                "status": status,
                "mode": mode or self.state["meta"].get("mode", "PAPER"),
                "uptime": safe_str(self.state["system"].get("uptime"), ""),
                "ping_ms": safe_str(self.state["system"].get("ping_ms"), "0"),
                "market_age_sec": market_age,
                "ta_age_sec": ta_age,
                "server_time": int(now),
            }

    async def set_mode(self, mode: str) -> None:
        async with self._lock:
            self.state["meta"]["mode"] = safe_str(mode, "PAPER").upper()

    async def set_pool(self, market_type: str, symbols: List[str]) -> None:
        target = "fut_pool" if market_type == "fut" else "spot_pool"
        clean = []
        seen = set()

        for symbol in symbols or []:
            sym = normalize_symbol(symbol)
            if sym and sym not in seen:
                clean.append(sym)
                seen.add(sym)

        async with self._lock:
            self.state["system"][target] = clean

    async def get_pool(self, market_type: str) -> List[str]:
        target = "fut_pool" if market_type == "fut" else "spot_pool"
        async with self._lock:
            return list(self.state["system"].get(target, []))

    async def update_timer(self, seconds_left: int) -> None:
        async with self._lock:
            self.state["system"]["rotation_timer"] = max(0, safe_int(seconds_left))

    async def add_sys_log(self, tag: str, message: str) -> None:
        line = f"{time.strftime('%H:%M:%S')} {safe_str(tag)} {safe_str(message)}".strip()
        async with self._lock:
            self._sys_logs.appendleft(line)
            self.state["system"]["sys_logs"] = list(self._sys_logs)

    async def clear_sys_logs(self) -> None:
        async with self._lock:
            self._sys_logs.clear()
            self.state["system"]["sys_logs"] = []

    async def update_market_price(self, symbol: str, price: float, ts: Optional[float] = None) -> None:
        sym = normalize_symbol(symbol)
        px = safe_float(price, 0.0)
        timestamp = safe_float(ts, time.time())

        if not sym or px <= 0:
            return

        async with self._lock:
            self.state["market"]["prices"][sym] = px
            self.state["market"]["price_timestamps"][sym] = timestamp
            self.state["market"]["last_market_update_ts"] = timestamp

    async def set_symbol_health(self, symbol: str, payload: Dict[str, Any]) -> None:
        sym = normalize_symbol(symbol)
        if not sym:
            return

        data = validate_symbol_health(sym, payload)

        async with self._lock:
            self.state["market"]["symbol_health"][sym] = data

    async def update_ta_data(self, ta_map: Dict[str, Dict[str, Any]]) -> None:
        clean = validate_ta_payload(ta_map)
        async with self._lock:
            self.state["market"]["ta_data"] = clean
            self.state["market"]["last_ta_update_ts"] = time.time()

    async def update_macro(self, macro: Dict[str, Any]) -> None:
        data = macro if isinstance(macro, dict) else {}
        clean = {
            "btc_trend": safe_str(data.get("btc_trend"), "neutral"),
            "global_filter": safe_str(data.get("global_filter"), "allow_all"),
            "binance_btc": safe_float(data.get("binance_btc")),
            "oi_amount": safe_float(data.get("oi_amount")),
            "fng_value": safe_int(data.get("fng_value"), 50),
        }
        async with self._lock:
            self.state["system"]["macro"] = clean

    async def update_system_metrics(self, uptime: str, ram_mb: Any, ping_ms: Any) -> None:
        async with self._lock:
            self.state["system"]["uptime"] = safe_str(uptime, "00:00:00")
            self.state["system"]["ram_mb"] = safe_str(ram_mb, "0")
            self.state["system"]["ping_ms"] = safe_str(ping_ms, "0")

    async def update_planner_market_data(self, snapshot: Dict[str, Any]) -> None:
        async with self._lock:
            self.state["planner"]["market_data"] = copy.deepcopy(snapshot if isinstance(snapshot, dict) else {})
            self.state["planner"]["status"] = "market_ready"

    async def update_spot_planner(self, payload: Dict[str, Any]) -> None:
        clean = validate_planner_payload(payload)
        async with self._lock:
            self.state["planner"]["ideas"] = clean["ideas"]
            self.state["planner"]["spot_ideas"] = clean["spot_ideas"]
            self.state["planner"]["generated_at"] = clean["generated_at"]
            self.state["planner"]["last_update_ts"] = clean["last_update_ts"]
            self.state["planner"]["mode"] = clean["mode"]
            self.state["planner"]["status"] = clean["status"]

    async def set_watchlist_mini(self, items: List[Dict[str, Any]]) -> None:
        clean = validate_watchlist_payload(items)
        async with self._lock:
            self.state["terminal"]["watchlist_mini"] = clean

    async def sync_router_snapshot(self, router: Any) -> None:
        """
        Совместимость со старой архитектурой:
        подтягивает balances/positions из execution router в state.
        """
        fut_balance = 0.0
        spot_balance = 0.0
        fut_position = None
        spot_positions = {}

        try:
            fut_balance = safe_float(router.get_futures_balance())
        except Exception:
            pass

        try:
            spot_balance = safe_float(router.get_spot_balance())
        except Exception:
            pass

        try:
            fut_position = router.get_futures_position()
        except Exception:
            fut_position = None

        try:
            spot_positions = router.get_all_spot_positions() or {}
        except Exception:
            spot_positions = {}

        fut_map: Dict[str, Any] = {}
        spot_map: Dict[str, Any] = {}

        if fut_position is not None:
            symbol = normalize_symbol(getattr(fut_position, "symbol", ""))
            if symbol:
                fut_map[symbol] = self._serialize_position_object(fut_position, market_type="fut")

        for symbol, pos in (spot_positions or {}).items():
            sym = normalize_symbol(symbol)
            if not sym:
                continue
            spot_map[sym] = self._serialize_position_object(pos, market_type="spot")

        async with self._lock:
            self.state["account"]["balances"]["fut"] = round(fut_balance, 8)
            self.state["account"]["balances"]["spot"] = round(spot_balance, 8)
            self.state["positions"]["fut"] = fut_map
            self.state["positions"]["spot"] = spot_map

    def _serialize_position_object(self, pos: Any, market_type: str) -> Dict[str, Any]:
        raw = {
            "entry": getattr(pos, "entry", None),
            "avg_price": getattr(pos, "avg_price", getattr(pos, "entry", None)),
            "sl": getattr(pos, "sl", None),
            "tp": getattr(pos, "tp", None),
            "tp1": getattr(pos, "tp", None),
            "tp2": getattr(pos, "tp2", None),
            "side": getattr(pos, "side", "BUY" if market_type == "spot" else None),
            "leverage": getattr(pos, "leverage", None),
            "liq_price": getattr(pos, "liq_price", None),
            "pnl": getattr(pos, "pnl", None),
            "pnl_net": getattr(pos, "pnl_net", None),
            "fills_count": getattr(pos, "fills_count", None),
            "tp1_hit": getattr(pos, "tp1_hit", None),
            "breakeven": getattr(pos, "breakeven", None),
            "status_label": None,
        }

        clean = validate_position_payload(raw)

        if market_type == "fut":
            side = safe_str(clean.get("side"), "").upper()
            if clean.get("tp1_hit"):
                clean["status_label"] = "TP1 / TRAIL"
            elif side:
                clean["status_label"] = f"{side} OPEN"
            else:
                clean["status_label"] = "OPEN"
        else:
            fills_count = clean.get("fills_count")
            if fills_count and fills_count > 1:
                clean["status_label"] = f"LADDER x{fills_count}"
            else:
                clean["status_label"] = "SPOT OPEN"

        return clean

    async def replace_state(self, new_state: Dict[str, Any]) -> None:
        """
        Полная замена state — только для debug/reload сценариев.
        """
        if not isinstance(new_state, dict):
            return

        async with self._lock:
            current_meta = dict(self.state.get("meta", {}))
            current_logs = list(self._sys_logs)

            self.state = copy.deepcopy(new_state)
            self.state.setdefault("meta", current_meta)
            self.state.setdefault("system", {})
            self.state["system"].setdefault("sys_logs", current_logs)

            self._sys_logs = deque(current_logs, maxlen=CONFIG.logging.max_sys_logs)

    async def get_runtime_snapshot(self) -> Dict[str, Any]:
        async with self._lock:
            now = time.time()
            return {
                "meta": copy.deepcopy(self.state.get("meta", {})),
                "market_last_update_ts": safe_float(self.state["market"].get("last_market_update_ts")),
                "ta_last_update_ts": safe_float(self.state["market"].get("last_ta_update_ts")),
                "planner_last_update_ts": safe_int(self.state["planner"].get("last_update_ts")),
                "sys_logs_count": len(self._sys_logs),
                "fut_pool_size": len(self.state["system"].get("fut_pool", [])),
                "spot_pool_size": len(self.state["system"].get("spot_pool", [])),
                "watchlist_size": len(self.state["terminal"].get("watchlist_mini", [])),
                "server_time": now,
                "uptime_sec": int(now - self._started_ts),
            }