from typing import Dict, List, Optional

from config import CONFIG
from validators import safe_bool, safe_float, safe_str

try:
    from momentum_engine import MomentumEngine
except Exception:
    MomentumEngine = None


class SwingStrategy:
    """
    VORTEX 1.5 Strategy Engine.

    Публичный контракт:
    - analyze_futures(current, macro_filter="allow_all") -> dict
    - analyze_spot(current, macro_filter="allow_all") -> dict
    - calculate_futures_trade(price, side, atr, setup_type=None) -> dict
    - calculate_spot_ladder(price, atr, setup_type=None) -> dict

    Главная логика:
    1. Обычная trend/pullback/retest/breakout стратегия.
    2. Dead/chaotic/unknown regime = hard block.
    3. Но Movement Hunter может сделать dead override:
       - dead_override_momentum_long
       - dead_override_momentum_short
    """

    def __init__(self) -> None:
        self.momentum = MomentumEngine() if MomentumEngine is not None else None

    # ------------------------------------------------------------------
    # Common helpers
    # ------------------------------------------------------------------

    def _result(
        self,
        should_open: bool = False,
        signal: Optional[str] = None,
        score: int = 0,
        setup_type: Optional[str] = None,
        args: Optional[List[str]] = None,
        blocked_reason: Optional[str] = None,
        threshold: int = 0,
        extra: Optional[Dict[str, object]] = None,
    ) -> Dict[str, object]:
        args = args or []

        payload: Dict[str, object] = {
            "should_open": bool(should_open),
            "signal": signal,
            "score": int(score),
            "setup_type": setup_type,
            "args_text": " | ".join([safe_str(x) for x in args if safe_str(x)]),
            "blocked_reason": blocked_reason,
            "threshold": int(threshold),
        }

        if extra:
            payload.update(extra)

        return payload

    def _macro_blocks_side(self, macro_filter: str, side: str) -> bool:
        mf = safe_str(macro_filter, "allow_all").lower()
        side = safe_str(side).upper()

        if mf in {"allow_all", "neutral", "none", ""}:
            return False

        if mf in {"block_all", "risk_off", "panic"}:
            return True

        if side == "LONG" and mf in {
            "block_longs",
            "short_only",
            "risk_off_longs",
            "no_longs",
        }:
            return True

        if side == "SHORT" and mf in {
            "block_shorts",
            "long_only",
            "risk_off_shorts",
            "no_shorts",
        }:
            return True

        return False

    def _momentum_macro_override_score(self) -> int:
        momentum_cfg = getattr(CONFIG, "momentum", None)
        if momentum_cfg is None:
            return 10

        return int(getattr(momentum_cfg, "macro_override_score", 10))

    def _trend_is_up(self, trend: str) -> bool:
        return safe_str(trend).lower() in {"up", "strong_up", "bull", "bullish"}

    def _trend_is_down(self, trend: str) -> bool:
        return safe_str(trend).lower() in {"down", "strong_down", "bear", "bearish"}

    def _good_volume(self, data: Dict[str, object], market: str) -> bool:
        vol_ratio = safe_float(data.get("vol_ratio"), 1.0)

        if market == "spot":
            return vol_ratio >= safe_float(CONFIG.strategy.min_vol_ratio_spot, 1.05)

        return vol_ratio >= safe_float(CONFIG.strategy.min_vol_ratio_futures, 1.10)

    def _ema_long_ok(self, data: Dict[str, object]) -> bool:
        price = safe_float(data.get("price"), 0.0)
        ema20 = safe_float(data.get("ema20"), 0.0)
        ema50 = safe_float(data.get("ema50"), 0.0)

        if not safe_bool(getattr(CONFIG.strategy, "ema_filter_enabled", True), True):
            return True

        if price <= 0 or ema20 <= 0:
            return False

        if ema50 <= 0:
            return price >= ema20

        return price >= ema20 >= ema50

    def _ema_short_ok(self, data: Dict[str, object]) -> bool:
        price = safe_float(data.get("price"), 0.0)
        ema20 = safe_float(data.get("ema20"), 0.0)
        ema50 = safe_float(data.get("ema50"), 0.0)

        if not safe_bool(getattr(CONFIG.strategy, "ema_filter_enabled", True), True):
            return True

        if price <= 0 or ema20 <= 0:
            return False

        if ema50 <= 0:
            return price <= ema20

        return price <= ema20 <= ema50

    def _rsi_long_ok(self, data: Dict[str, object]) -> bool:
        rsi = safe_float(data.get("rsi_main", data.get("rsi")), 50.0)
        return rsi >= safe_float(CONFIG.strategy.long_rsi_min, 45.0)

    def _rsi_short_ok(self, data: Dict[str, object]) -> bool:
        rsi = safe_float(data.get("rsi_main", data.get("rsi")), 50.0)
        return rsi <= safe_float(CONFIG.strategy.short_rsi_max, 55.0)

    def _is_pullback_long(self, data: Dict[str, object]) -> bool:
        return safe_bool(data.get("pullback_long_ready"), False) or safe_bool(data.get("pullback_long"), False)

    def _is_pullback_short(self, data: Dict[str, object]) -> bool:
        return safe_bool(data.get("pullback_short_ready"), False) or safe_bool(data.get("pullback_short"), False)

    def _is_retest_long(self, data: Dict[str, object]) -> bool:
        return safe_bool(data.get("retest_long_ready"), False) or safe_bool(data.get("retest_long"), False)

    def _is_retest_short(self, data: Dict[str, object]) -> bool:
        return safe_bool(data.get("retest_short_ready"), False) or safe_bool(data.get("retest_short"), False)

    def _is_breakout_long(self, data: Dict[str, object]) -> bool:
        if safe_bool(data.get("breakout_long_ready"), False):
            return True

        return safe_bool(data.get("breakout"), False) and safe_str(data.get("breakout_dir")).lower() == "up"

    def _is_breakout_short(self, data: Dict[str, object]) -> bool:
        if safe_bool(data.get("breakout_short_ready"), False):
            return True

        return safe_bool(data.get("breakout"), False) and safe_str(data.get("breakout_dir")).lower() == "down"

    def _entry_quality_block_reason(self, data: Dict[str, object], signal: str, setup_type: Optional[str]) -> str:
        # v1.7.7: blocks late classic breakout entries.
        cfg = CONFIG.momentum

        if not safe_bool(getattr(cfg, "quality_filter_enabled", True), True):
            return ""

        setup = safe_str(setup_type).lower()

        if "momentum" not in setup and "breakout" not in setup:
            return ""

        if "breakout" in setup and not safe_bool(getattr(cfg, "quality_filter_blocks_breakouts", True), True):
            return ""

        side = safe_str(signal).upper()
        price = safe_float(data.get("price"), 0.0)
        atr = safe_float(data.get("atr"), 0.0)
        ema20 = safe_float(data.get("ema20"), 0.0)
        rsi = safe_float(data.get("rsi_main", data.get("rsi")), 50.0)

        range_pct = safe_float(
            data.get("range_pct", data.get("range_24h_pct", data.get("h24_range_pct"))),
            0.0,
        )
        change_pct = safe_float(
            data.get("change_pct", data.get("change_24h_pct", data.get("h24_change_pct", data.get("price_change_pct")))),
            0.0,
        )

        if side == "LONG" and rsi >= safe_float(getattr(cfg, "long_rsi_exhaustion", 78.0), 78.0):
            return f"long RSI exhaustion {rsi:.2f}"

        if side == "SHORT" and rsi <= safe_float(getattr(cfg, "short_rsi_exhaustion", 22.0), 22.0):
            return f"short RSI exhaustion {rsi:.2f}"

        if price > 0 and ema20 > 0:
            ema_dist_pct = abs(price - ema20) / ema20 * 100.0
            max_ema_pct = safe_float(getattr(cfg, "max_ema_distance_pct", 8.0), 8.0)

            if ema_dist_pct > max_ema_pct:
                return f"EMA distance too high {ema_dist_pct:.2f}%>{max_ema_pct:.2f}%"

        if price > 0 and ema20 > 0 and atr > 0:
            ema_dist_atr = abs(price - ema20) / atr
            max_ema_atr = safe_float(getattr(cfg, "max_ema_distance_atr", 5.0), 5.0)

            if ema_dist_atr > max_ema_atr:
                return f"EMA distance ATR too high {ema_dist_atr:.2f}>{max_ema_atr:.2f}"

        max_range = safe_float(getattr(cfg, "max_quality_range_pct", 22.0), 22.0)
        if range_pct >= max_range:
            return f"range overextended {range_pct:.2f}%"

        max_change = safe_float(getattr(cfg, "max_quality_change_abs_pct", 18.0), 18.0)
        if abs(change_pct) >= max_change:
            return f"change overextended {change_pct:.2f}%"

        return ""

    def _fee_guard_ok(
        self,
        price: float,
        tp: float,
        sl: float,
        side: str,
        market: str,
    ) -> bool:
        if not safe_bool(getattr(CONFIG.strategy, "fee_guard_enabled", True), True):
            return True

        if price <= 0 or tp <= 0:
            return False

        side = safe_str(side).upper()

        if side == "LONG":
            gross_pct = max(0.0, (tp - price) / price)
        else:
            gross_pct = max(0.0, (price - tp) / price)

        if market == "spot":
            fee_est = safe_float(CONFIG.spot.taker_fee, 0.001) * 2.0
            required = fee_est * safe_float(CONFIG.strategy.spot_fee_edge_multiplier, 2.6)
        else:
            fee_est = safe_float(CONFIG.futures.taker_fee, 0.0006) * 2.0
            required = fee_est * safe_float(CONFIG.strategy.futures_fee_edge_multiplier, 2.2)

        return gross_pct >= required

    # ------------------------------------------------------------------
    # Movement Hunter
    # ------------------------------------------------------------------

    def _try_momentum_futures(
        self,
        data: Dict[str, object],
        macro_filter: str,
        market_regime: str,
        threshold: int,
    ) -> Optional[Dict[str, object]]:
        if self.momentum is None:
            return None

        signal = self.momentum.evaluate_futures(data, market_regime=market_regime)

        if not signal.active:
            return None

        side = safe_str(signal.side).upper()
        score = int(signal.score)

        # VORTEX v1.6.1.1 HOTFIX:
        # dead_override generated most losing trades in v1.6 stats, so it is blocked
        # before WatchEngine can create/confirm a candidate.
        if safe_str(signal.setup_type).startswith("dead_override_momentum"):
            return self._result(
                should_open=False,
                signal=side,
                score=score,
                setup_type=signal.setup_type,
                args=[signal.reason],
                blocked_reason="dead_override disabled in v1.6.1.1 hotfix",
                threshold=threshold,
                extra={"momentum": signal.to_dict()},
            )

        args = [
            signal.reason,
            f"trigger={safe_float(signal.trigger_price):.8f}",
            f"invalidation={safe_float(signal.invalidation_price):.8f}",
        ]

        macro_blocked = self._macro_blocks_side(macro_filter, side)
        override_score = self._momentum_macro_override_score()

        if macro_blocked and score < override_score:
            return self._result(
                should_open=False,
                signal=side,
                score=score,
                setup_type=signal.setup_type,
                args=args,
                blocked_reason=f"macro blocks {side.lower()}s",
                threshold=threshold,
                extra={
                    "momentum": signal.to_dict(),
                    "trigger_price": signal.trigger_price,
                    "invalidation_price": signal.invalidation_price,
                },
            )

        if macro_blocked and score >= override_score:
            args.append(f"macro override score>={override_score}")

        # Для WATCH нужно should_open=True:
        # main.py тогда отправит кандидата в WatchEngine.
        return self._result(
            should_open=True,
            signal=side,
            score=max(score, threshold),
            setup_type=signal.setup_type,
            args=args,
            blocked_reason=None,
            threshold=threshold,
            extra={
                "momentum": signal.to_dict(),
                "trigger_price": signal.trigger_price,
                "invalidation_price": signal.invalidation_price,
                "confirmed": signal.confirmed,
            },
        )

    # ------------------------------------------------------------------
    # Futures analysis
    # ------------------------------------------------------------------

    def analyze_futures(self, current: Dict[str, object], macro_filter: str = "allow_all") -> Dict[str, object]:
        data = current or {}
        threshold = int(CONFIG.trading.futures_min_score_to_open)

        price = safe_float(data.get("price"), 0.0)
        atr = safe_float(data.get("atr"), 0.0)
        market_regime = safe_str(
            data.get("market_regime", data.get("regime", data.get("trend_regime"))),
            "unknown",
        ).lower()

        if price <= 0 or atr <= 0:
            return self._result(
                should_open=False,
                score=0,
                blocked_reason="invalid price/atr",
                threshold=threshold,
            )

        # 1. Momentum first.
        # Важно: это даёт шанс dead_override до hard block.
        momentum_result = self._try_momentum_futures(
            data=data,
            macro_filter=macro_filter,
            market_regime=market_regime,
            threshold=threshold,
        )

        if momentum_result is not None and momentum_result.get("should_open"):
            return momentum_result

        # 2. Hard block для плохого рынка.
        if market_regime in {"chaotic", "unknown", "dead"}:
            if momentum_result is not None:
                return momentum_result

            return self._result(
                should_open=False,
                score=0,
                blocked_reason=f"bad regime:{market_regime}",
                threshold=threshold,
            )

        trend_4h = safe_str(data.get("trend_4h"), "neutral").lower()
        trend_bias_1h = safe_str(data.get("trend_bias_1h"), "neutral").lower()

        long_setups = {
            "pullback_long": self._is_pullback_long(data),
            "retest_long": self._is_retest_long(data),
            "breakout_long": self._is_breakout_long(data),
        }

        short_setups = {
            "pullback_short": self._is_pullback_short(data),
            "retest_short": self._is_retest_short(data),
            "breakout_short": self._is_breakout_short(data),
        }

        long_score = 0
        short_score = 0
        long_args: List[str] = []
        short_args: List[str] = []

        if self._trend_is_up(trend_4h):
            long_score += 3 if trend_4h == "strong_up" else 2
            long_args.append(f"4H {trend_4h}")

        if self._trend_is_down(trend_4h):
            short_score += 3 if trend_4h == "strong_down" else 2
            short_args.append(f"4H {trend_4h}")

        if trend_bias_1h == "up":
            long_score += 1
            long_args.append("1H bias up")

        if trend_bias_1h == "down":
            short_score += 1
            short_args.append("1H bias down")

        if long_setups["pullback_long"]:
            long_score += 3
            long_args.append("pullback long ready")
        if long_setups["retest_long"]:
            long_score += 2
            long_args.append("retest long ready")
        if long_setups["breakout_long"]:
            long_score += 2
            long_args.append("breakout continuation up")

        if short_setups["pullback_short"]:
            short_score += 3
            short_args.append("pullback short ready")
        if short_setups["retest_short"]:
            short_score += 2
            short_args.append("retest short ready")
        if short_setups["breakout_short"]:
            short_score += 2
            short_args.append("breakout continuation down")

        if self._ema_long_ok(data):
            long_score += 1
            long_args.append("EMA aligned long")

        if self._ema_short_ok(data):
            short_score += 1
            short_args.append("EMA aligned short")

        if self._rsi_long_ok(data):
            long_score += 1
            long_args.append("RSI supports long")

        if self._rsi_short_ok(data):
            short_score += 1
            short_args.append("RSI supports short")

        if self._good_volume(data, "fut"):
            long_score += 1
            short_score += 1
            long_args.append("volume confirmed")
            short_args.append("volume confirmed")

        has_long_setup = any(long_setups.values())
        has_short_setup = any(short_setups.values())

        signal: Optional[str] = None
        score = 0
        setup_type: Optional[str] = None
        args: List[str] = []

        if long_score > short_score and has_long_setup:
            signal = "LONG"
            score = long_score
            args = long_args

            if long_setups["pullback_long"]:
                setup_type = "pullback_long"
            elif long_setups["retest_long"]:
                setup_type = "retest_long"
            elif long_setups["breakout_long"]:
                setup_type = "breakout_long"

        elif short_score > long_score and has_short_setup:
            signal = "SHORT"
            score = short_score
            args = short_args

            if short_setups["pullback_short"]:
                setup_type = "pullback_short"
            elif short_setups["retest_short"]:
                setup_type = "retest_short"
            elif short_setups["breakout_short"]:
                setup_type = "breakout_short"

        else:
            return self._result(
                should_open=False,
                score=max(long_score, short_score),
                blocked_reason="no concrete setup or tie",
                threshold=threshold,
            )

        quality_block = self._entry_quality_block_reason(data, signal, setup_type)
        if quality_block:
            return self._result(
                should_open=False,
                signal=signal,
                score=score,
                setup_type=setup_type,
                args=args + [f"quality filter: {quality_block}"],
                blocked_reason=f"quality filter: {quality_block}",
                threshold=threshold,
            )

        if self._macro_blocks_side(macro_filter, signal):
            return self._result(
                should_open=False,
                signal=signal,
                score=score,
                setup_type=setup_type,
                args=args,
                blocked_reason=f"macro blocks {signal.lower()}s",
                threshold=threshold,
            )

        ladder = self.calculate_futures_trade(
            price=price,
            side=signal,
            atr=atr,
            setup_type=setup_type,
        )

        if not self._fee_guard_ok(price, ladder["tp"], ladder["sl"], signal, "fut"):
            return self._result(
                should_open=False,
                signal=signal,
                score=score,
                setup_type=setup_type,
                args=args,
                blocked_reason="fee guard",
                threshold=threshold,
            )

        if score < threshold:
            return self._result(
                should_open=False,
                signal=signal,
                score=score,
                setup_type=setup_type,
                args=args,
                blocked_reason=f"score below threshold {score}<{threshold}",
                threshold=threshold,
            )

        return self._result(
            should_open=True,
            signal=signal,
            score=score,
            setup_type=setup_type,
            args=args,
            blocked_reason=None,
            threshold=threshold,
        )

    # ------------------------------------------------------------------
    # Spot analysis
    # ------------------------------------------------------------------

    def analyze_spot(self, current: Dict[str, object], macro_filter: str = "allow_all") -> Dict[str, object]:
        data = current or {}
        threshold = int(CONFIG.trading.spot_min_score_to_open)

        price = safe_float(data.get("price"), 0.0)
        atr = safe_float(data.get("atr"), 0.0)
        market_regime = safe_str(
            data.get("market_regime", data.get("regime", data.get("trend_regime"))),
            "unknown",
        ).lower()

        if price <= 0 or atr <= 0:
            return self._result(
                should_open=False,
                score=0,
                blocked_reason="invalid price/atr",
                threshold=threshold,
            )

        if market_regime in {"chaotic", "unknown", "dead"}:
            return self._result(
                should_open=False,
                score=0,
                blocked_reason=f"bad regime:{market_regime}",
                threshold=threshold,
            )

        if self._macro_blocks_side(macro_filter, "LONG"):
            return self._result(
                should_open=False,
                signal="LONG",
                score=0,
                blocked_reason="macro blocks longs",
                threshold=threshold,
            )

        trend_4h = safe_str(data.get("trend_4h"), "neutral").lower()
        trend_bias_1h = safe_str(data.get("trend_bias_1h"), "neutral").lower()

        score = 0
        args: List[str] = []

        if self._trend_is_up(trend_4h):
            score += 3 if trend_4h == "strong_up" else 2
            args.append(f"4H {trend_4h}")

        if trend_bias_1h == "up":
            score += 1
            args.append("1H bias up")

        has_setup = False
        setup_type = None

        if self._is_pullback_long(data):
            score += 3
            has_setup = True
            setup_type = "spot_pullback_long"
            args.append("pullback long ready")

        if self._is_retest_long(data):
            score += 2
            has_setup = True
            setup_type = setup_type or "spot_retest_long"
            args.append("retest long ready")

        if self._is_breakout_long(data):
            score += 2
            has_setup = True
            setup_type = setup_type or "spot_breakout_long"
            args.append("breakout continuation up")

        if self._ema_long_ok(data):
            score += 1
            args.append("EMA aligned long")

        if self._rsi_long_ok(data):
            score += 1
            args.append("RSI supports long")

        if self._good_volume(data, "spot"):
            score += 1
            args.append("volume confirmed")

        if not has_setup:
            return self._result(
                should_open=False,
                signal="LONG",
                score=score,
                blocked_reason="no concrete spot setup",
                threshold=threshold,
            )

        ladder = self.calculate_spot_ladder(
            price=price,
            atr=atr,
            setup_type=setup_type,
        )

        if not self._fee_guard_ok(price, ladder["tp"], ladder["sl"], "LONG", "spot"):
            return self._result(
                should_open=False,
                signal="LONG",
                score=score,
                setup_type=setup_type,
                args=args,
                blocked_reason="fee guard",
                threshold=threshold,
            )

        if score < threshold:
            return self._result(
                should_open=False,
                signal="LONG",
                score=score,
                setup_type=setup_type,
                args=args,
                blocked_reason=f"score below threshold {score}<{threshold}",
                threshold=threshold,
            )

        return self._result(
            should_open=True,
            signal="LONG",
            score=score,
            setup_type=setup_type,
            args=args,
            blocked_reason=None,
            threshold=threshold,
        )

    # ------------------------------------------------------------------
    # Trade ladders
    # ------------------------------------------------------------------

    def calculate_futures_trade(
        self,
        price: float,
        side: str,
        atr: float,
        setup_type: Optional[str] = None,
    ) -> Dict[str, float]:
        price = safe_float(price, 0.0)
        atr = safe_float(atr, 0.0)
        side = safe_str(side).upper()
        setup_type = safe_str(setup_type)

        if price <= 0:
            price = 1.0

        if atr <= 0:
            atr = price * 0.01

        tp_mult = safe_float(CONFIG.strategy.futures_tp_atr_mult, 3.2)
        sl_mult = safe_float(CONFIG.strategy.futures_sl_atr_mult, 1.4)

        if setup_type.startswith("dead_override_momentum"):
            tp_mult = max(tp_mult, safe_float(getattr(CONFIG.momentum, "tp_atr_mult", 3.0), 3.0))
            sl_mult = max(1.0, safe_float(getattr(CONFIG.momentum, "sl_atr_mult", 1.2), 1.2))

        if side == "SHORT":
            tp = price - atr * tp_mult
            sl = price + atr * sl_mult
        else:
            tp = price + atr * tp_mult
            sl = price - atr * sl_mult

        if side == "SHORT":
            tp2 = price - atr * tp_mult * 1.65
        else:
            tp2 = price + atr * tp_mult * 1.65

        return {
            "tp": round(tp, 8),
            "tp2": round(tp2, 8),
            "sl": round(sl, 8),
            "leverage": safe_float(CONFIG.trading.futures_default_leverage, 3.0),
        }

    def calculate_spot_ladder(
        self,
        price: float,
        atr: float,
        setup_type: Optional[str] = None,
    ) -> Dict[str, float]:
        price = safe_float(price, 0.0)
        atr = safe_float(atr, 0.0)

        if price <= 0:
            price = 1.0

        if atr <= 0:
            atr = price * 0.01

        tp_mult = safe_float(CONFIG.strategy.spot_tp_atr_mult, 3.0)
        sl_mult = safe_float(CONFIG.strategy.spot_sl_atr_mult, 2.0)

        tp = price + atr * tp_mult
        tp2 = price + atr * tp_mult * 1.8
        sl = price - atr * sl_mult

        return {
            "tp": round(tp, 8),
            "tp2": round(tp2, 8),
            "sl": round(sl, 8),
        }

# VORTEX v1.6.4 standalone helper; used by main before risk/execution.
def apply_exchange_intel_filters_to_analysis(analysis: dict, exchange_ctx: dict | None = None) -> dict:
    if not isinstance(analysis, dict):
        return analysis
    ctx = exchange_ctx or analysis.get("exchange_ctx") or analysis.get("exchange") or {}
    if not isinstance(ctx, dict) or not ctx:
        return analysis
    signal = str(analysis.get("signal") or analysis.get("side") or "").upper()
    score = int(analysis.get("score") or 0)
    args = str(analysis.get("args_text") or analysis.get("args") or "")
    funding_signal = str(ctx.get("funding_signal") or "unknown")
    oi_signal = str(ctx.get("oi_signal") or "unknown")

    def blocked(reason: str) -> dict:
        out = dict(analysis)
        out["should_open"] = False
        out["blocked_reason"] = reason
        out["exchange_ctx"] = ctx
        out["args_text"] = (args + f" | EX_BLOCK:{reason}").strip(" |")
        return out

    if funding_signal == "extreme_long_bias" and signal == "LONG":
        return blocked("funding extreme long bias")
    if funding_signal == "extreme_short_bias" and signal == "SHORT":
        return blocked("funding extreme short bias")
    if oi_signal == "long_liquidation" and signal == "LONG":
        return blocked("OI longs liquidating")
    if oi_signal == "short_squeeze" and signal == "SHORT":
        return blocked("OI shorts squeezed")

    if oi_signal == "real_trend_up" and signal == "LONG":
        score += 1
        args += " | OI confirms long"
    elif oi_signal == "real_trend_down" and signal == "SHORT":
        score += 1
        args += " | OI confirms short"

    if funding_signal == "long_bias" and signal == "LONG":
        score -= 1
        args += " | funding caution long"
    elif funding_signal == "short_bias" and signal == "SHORT":
        score -= 1
        args += " | funding caution short"

    out = dict(analysis)
    out["score"] = score
    out["args_text"] = args.strip(" |")
    out["exchange_ctx"] = ctx
    return out

