import asyncio
import time
from typing import Dict

import aiohttp

from config import CONFIG
from market_regime import MarketRegimeEvaluator
from validators import safe_float, safe_int, safe_str


class MarketOracle:
    """
    Macro/oracle layer.

    VORTEX 1.5 fix:
    - BTC trend is no longer a 4-minute window;
    - BTC price is sampled from Bitget every 5 minutes;
    - 24 samples ~= 2 hours of macro context.
    """

    def __init__(self, state_manager, logger=None) -> None:
        self.state = state_manager
        self.logger = logger
        self.regime = MarketRegimeEvaluator()
        self.macro: Dict[str, object] = {
            "btc_trend": "neutral",
            "global_filter": "allow_all",
            "binance_btc": 0.0,
            "bitget_btc": 0.0,
            "oi_amount": 0.0,
            "fng_value": 50,
            "risk_state": "neutral",
            "allow_longs": True,
            "allow_shorts": True,
            "oracle_ts": 0,
        }
        self.btc_prices: list[float] = []
        self.last_btc_sample_ts: float = 0.0
        self.btc_sample_interval_sec: int = 300
        self.btc_sample_limit: int = 24

    async def fetch_btc(self, session: aiohttp.ClientSession) -> None:
        try:
            async with session.get(
                "https://api.bitget.com/api/v2/mix/market/ticker",
                params={"symbol": "BTCUSDT", "productType": "USDT-FUTURES"},
            ) as resp:
                payload = await resp.json(content_type=None)

            if payload.get("code") != "00000":
                raise RuntimeError(f"bad code {payload.get('code')}")
            items = payload.get("data", [])
            item = items[0] if isinstance(items, list) and items else {}
            price = safe_float(item.get("lastPr") or item.get("last") or item.get("close"), 0.0)
            if price <= 0:
                return

            now = time.time()
            self.macro["bitget_btc"] = price
            self.macro["binance_btc"] = price  # compatibility with existing API/UI field

            if not self.btc_prices or (now - self.last_btc_sample_ts) >= self.btc_sample_interval_sec:
                self.btc_prices.append(price)
                self.last_btc_sample_ts = now
                if len(self.btc_prices) > self.btc_sample_limit:
                    self.btc_prices.pop(0)

            if len(self.btc_prices) >= 4:
                start = self.btc_prices[0]
                end = self.btc_prices[-1]
                delta = (end - start) / start if start > 0 else 0.0

                if delta >= 0.015:
                    trend = "strong_bullish"
                elif delta >= 0.006:
                    trend = "bullish"
                elif delta <= -0.015:
                    trend = "strong_bearish"
                elif delta <= -0.006:
                    trend = "bearish"
                else:
                    trend = "neutral"
                self.macro["btc_trend"] = trend

        except Exception as exc:
            if self.logger:
                self.logger.error("ORACLE", "fetch_btc failed", {"error": str(exc)})

    async def fetch_oi(self, session: aiohttp.ClientSession) -> None:
        try:
            async with session.get(
                "https://api.bitget.com/api/v2/mix/market/open-interest",
                params={"symbol": "BTCUSDT", "productType": "USDT-FUTURES"},
            ) as resp:
                data = await resp.json(content_type=None)
            if data.get("code") == "00000":
                raw = data.get("data", {})
                if isinstance(raw, dict):
                    self.macro["oi_amount"] = safe_float(raw.get("amount"), 0.0)
        except Exception as exc:
            if self.logger:
                self.logger.error("ORACLE", "fetch_oi failed", {"error": str(exc)})

    async def fetch_fng(self, session: aiohttp.ClientSession) -> None:
        try:
            async with session.get("https://api.alternative.me/fng/?limit=1") as resp:
                data = await resp.json(content_type=None)
            values = data.get("data", [])
            if values and isinstance(values, list):
                self.macro["fng_value"] = safe_int(values[0].get("value"), 50)
        except Exception as exc:
            if self.logger:
                self.logger.error("ORACLE", "fetch_fng failed", {"error": str(exc)})

    def evaluate(self) -> None:
        evaluated = self.regime.evaluate_macro(self.macro)
        self.macro.update(evaluated)
        self.macro["oracle_ts"] = int(time.time())
        self.macro["btc_samples"] = len(self.btc_prices)

    async def loop(self) -> None:
        last_fng = 0.0
        last_oi = 0.0
        timeout = aiohttp.ClientTimeout(total=5)

        async with aiohttp.ClientSession(timeout=timeout) as session:
            while True:
                try:
                    now = time.time()
                    await self.fetch_btc(session)
                    if now - last_oi >= 60:
                        await self.fetch_oi(session)
                        last_oi = now
                    if now - last_fng >= 300:
                        await self.fetch_fng(session)
                        last_fng = now

                    self.evaluate()
                    await self.state.update_macro(self.macro)

                    trend = safe_str(self.macro.get("btc_trend"), "neutral")
                    filt = safe_str(self.macro.get("global_filter"), "allow_all")
                    risk_state = safe_str(self.macro.get("risk_state"), "neutral")
                    btc = safe_float(self.macro.get("bitget_btc"), 0.0)
                    fng = safe_int(self.macro.get("fng_value"), 50)
                    samples = safe_int(self.macro.get("btc_samples"), 0)

                    icon = "⚪"
                    if "bear" in trend:
                        icon = "🔴"
                    elif "bull" in trend:
                        icon = "🟢"

                    await self.state.add_sys_log(
                        "🧠 [ORACLE]",
                        f"BTC:{btc:.0f} {icon} | trend={trend} | samples={samples} | fng={fng} | risk={risk_state} | filter={filt}",
                    )
                except Exception as exc:
                    await self.state.add_sys_log("❌ [ORACLE]", str(exc))
                    if self.logger:
                        self.logger.error("ORACLE", "oracle loop failed", {"error": str(exc)})

                await asyncio.sleep(CONFIG.loops.oracle_sec)
