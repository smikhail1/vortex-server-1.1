import time
from collections import defaultdict
from typing import Dict, Tuple

from config import CONFIG
from validators import safe_float, safe_str


class RiskManager:
    """
    Risk layer:
    - cooldown per symbol/market
    - daily symbol cap
    - daily realized loss guard
    - simple regime blocks
    """

    def __init__(
        self,
        futures_symbol_cooldown_sec: int = CONFIG.risk.futures_symbol_cooldown_sec,
        spot_symbol_cooldown_sec: int = CONFIG.risk.spot_symbol_cooldown_sec,
        max_trades_per_symbol_per_day: int = CONFIG.risk.max_trades_per_symbol_per_day,
        daily_loss_limit_usdt: float = CONFIG.risk.daily_loss_limit_usdt,
        max_open_futures_positions: int = CONFIG.risk.max_open_futures_positions,
        max_open_spot_positions: int = CONFIG.risk.max_open_spot_positions,
    ) -> None:
        self.futures_symbol_cooldown_sec = int(futures_symbol_cooldown_sec)
        self.spot_symbol_cooldown_sec = int(spot_symbol_cooldown_sec)
        self.max_trades_per_symbol_per_day = int(max_trades_per_symbol_per_day)
        self.daily_loss_limit_usdt = float(daily_loss_limit_usdt)
        self.max_open_futures_positions = int(max_open_futures_positions)
        self.max_open_spot_positions = int(max_open_spot_positions)

        self.last_open_ts: Dict[Tuple[str, str], float] = {}
        self.trades_per_day: Dict[Tuple[str, str, str], int] = defaultdict(int)
        self.daily_realized_pnl: float = 0.0
        self.last_reset_day: str = self._day_key()

        self.regime_blocks: Dict[str, str] = {}
        self.last_loss_ts: Dict[Tuple[str, str], float] = {}

    def _day_key(self) -> str:
        return time.strftime("%Y-%m-%d", time.gmtime())

    def _maybe_reset_day(self) -> None:
        today = self._day_key()
        if today != self.last_reset_day:
            self.daily_realized_pnl = 0.0
            self.trades_per_day.clear()
            self.regime_blocks.clear()
            self.last_reset_day = today

    def _cooldown_sec(self, market_type: str) -> int:
        return self.futures_symbol_cooldown_sec if market_type == "fut" else self.spot_symbol_cooldown_sec

    def set_regime_block(self, market_type: str, reason: str = "") -> None:
        mkt = safe_str(market_type).lower()
        self.regime_blocks[mkt] = reason or "regime blocked"

    def clear_regime_block(self, market_type: str) -> None:
        mkt = safe_str(market_type).lower()
        if mkt in self.regime_blocks:
            del self.regime_blocks[mkt]

    def can_open(self, symbol: str, market_type: str) -> tuple[bool, str]:
        self._maybe_reset_day()

        sym = safe_str(symbol).upper()
        mkt = safe_str(market_type).lower()

        if self.daily_realized_pnl <= self.daily_loss_limit_usdt:
            return False, "daily loss limit reached"

        if mkt in self.regime_blocks:
            return False, self.regime_blocks[mkt]

        key = (sym, mkt)
        cooldown = self._cooldown_sec(mkt)
        last_ts = self.last_open_ts.get(key, 0.0)
        now = time.time()

        if last_ts > 0 and now - last_ts < cooldown:
            left = int(cooldown - (now - last_ts))
            return False, f"cooldown active ({left}s left)"

        day_key = (self.last_reset_day, sym, mkt)
        if self.trades_per_day.get(day_key, 0) >= self.max_trades_per_symbol_per_day:
            return False, "symbol daily cap reached"

        return True, "ok"

    def register_open(self, symbol: str, market_type: str) -> None:
        self._maybe_reset_day()

        sym = safe_str(symbol).upper()
        mkt = safe_str(market_type).lower()
        now = time.time()

        self.last_open_ts[(sym, mkt)] = now
        self.trades_per_day[(self.last_reset_day, sym, mkt)] += 1

    def register_close(self, symbol: str, market_type: str, pnl: float, reason: str) -> None:
        self._maybe_reset_day()

        sym = safe_str(symbol).upper()
        mkt = safe_str(market_type).lower()
        value = safe_float(pnl)
        self.daily_realized_pnl += value

        if value < 0:
            self.last_loss_ts[(sym, mkt)] = time.time()

    def get_status(self) -> Dict[str, object]:
        self._maybe_reset_day()
        return {
            "block_new_entries": self.daily_realized_pnl <= self.daily_loss_limit_usdt,
            "daily_realized_pnl": round(self.daily_realized_pnl, 8),
            "daily_loss_limit_usdt": round(self.daily_loss_limit_usdt, 8),
            "day": self.last_reset_day,
            "max_open_futures_positions": self.max_open_futures_positions,
            "max_open_spot_positions": self.max_open_spot_positions,
            "regime_blocks": dict(self.regime_blocks),
        }

    def reset(self) -> None:
        self.last_open_ts.clear()
        self.trades_per_day.clear()
        self.regime_blocks.clear()
        self.last_loss_ts.clear()
        self.daily_realized_pnl = 0.0
        self.last_reset_day = self._day_key()