from execution_router import ExecutionRouter
from risk_manager import RiskManager
from strategy import SwingStrategy


def assert_true(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def build_long_context():
    return {
        "price": 105.0,
        "atr": 2.0,
        "ema20": 104.0,
        "ema50": 100.0,
        "rsi_main": 54.0,
        "vol_ratio": 1.3,
        "trend_4h": "strong_up",
        "trend_bias_30m": "up",
        "market_regime": "trend",
        "breakout": False,
        "breakout_dir": "",
        "near_support": True,
        "near_resistance": False,
        "pullback_long_ready": True,
        "pullback_short_ready": False,
        "retest_long_ready": False,
        "retest_short_ready": False,
        "vol_confirmed": True,
        "breakout_volume_confirmed": True,
        "recent_high": 110.0,
        "recent_low": 98.0,
    }


def scenario_risk_cooldown():
    r = RiskManager(futures_symbol_cooldown_sec=999999)
    ok, _ = r.can_open("BTCUSDT", "fut")
    assert_true(ok, "first open should be allowed")
    r.register_open("BTCUSDT", "fut")
    ok2, reason2 = r.can_open("BTCUSDT", "fut")
    assert_true(not ok2, "second open must be blocked by cooldown")
    assert_true("cooldown" in reason2, "cooldown reason expected")
    print("OK: scenario_risk_cooldown")


def scenario_router_manual_cycle_futures():
    router = ExecutionRouter(mode="PAPER")

    open_result = router.manual_open_futures(
        symbol="BTCUSDT",
        side="LONG",
        price=70000,
        atr=400,
        margin_usdt=20,
        leverage=3,
        tp_mult=2.5,
        sl_mult=1.3,
        setup_type="test_manual_fut",
        args_text="integration fut",
    )
    assert_true(open_result.get("code") == "00000", f"futures open failed: {open_result}")

    pos = router.get_futures_position()
    assert_true(pos is not None, "futures position must exist")

    close_result = router.close_futures_position(70500, "MANUAL")
    assert_true(close_result is not None and close_result.get("code") == "00000", "futures close failed")
    assert_true(router.get_futures_position() is None, "futures position must be closed")
    print("OK: scenario_router_manual_cycle_futures")


def scenario_router_manual_cycle_spot():
    router = ExecutionRouter(mode="PAPER")

    open_result = router.manual_open_spot(
        symbol="ETHUSDT",
        price=2200,
        atr=30,
        order_usdt=20,
        tp_mult=3.0,
        setup_type="test_manual_spot",
        args_text="integration spot",
    )
    assert_true(open_result.get("code") == "00000", f"spot open failed: {open_result}")

    pos = router.get_spot_position("ETHUSDT")
    assert_true(pos is not None, "spot position must exist")

    close_result = router.close_spot_position("ETHUSDT", 2240, "MANUAL")
    assert_true(close_result is not None and close_result.get("code") == "00000", "spot close failed")
    assert_true(router.get_spot_position("ETHUSDT") is None, "spot position must be closed")
    print("OK: scenario_router_manual_cycle_spot")


def scenario_strategy_threshold_block():
    s = SwingStrategy()
    result = s.analyze_spot(build_long_context(), "allow_all")
    assert_true(result["signal"] == "BUY", "spot signal missing")
    assert_true(result["should_open"] is False, "auto-open should still be disabled")
    assert_true("score<" in (result["blocked_reason"] or ""), "threshold block expected")
    print("OK: scenario_strategy_threshold_block")


def run_all():
    scenario_risk_cooldown()
    scenario_router_manual_cycle_futures()
    scenario_router_manual_cycle_spot()
    scenario_strategy_threshold_block()
    print("ALL INTEGRATION TESTS PASSED")


if __name__ == "__main__":
    run_all()