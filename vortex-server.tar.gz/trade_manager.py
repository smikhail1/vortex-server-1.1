from typing import Any, Dict, Optional

from validators import safe_float, safe_str


class TradeManager:
    """
    Поводырь открытых сделок.

    Задачи:
    - следит за открытыми futures / spot позициями
    - прогоняет check_* у router
    - логирует TP1 / BE / CLOSE события
    - регистрирует realized pnl в risk_manager
    - пишет сделку в trade_logger

    Важно:
    - не открывает сделки
    - не принимает решение о входе
    - только сопровождает уже открытую позицию
    """

    def __init__(self, logger=None) -> None:
        self.logger = logger

        self._last_fut_event_key: Optional[str] = None
        self._last_spot_event_keys: Dict[str, str] = {}

    def _event_key(self, symbol: str, reason: str, exit_price: Any, pnl: Any) -> str:
        return f"{safe_str(symbol)}|{safe_str(reason)}|{safe_float(exit_price):.8f}|{safe_float(pnl):.8f}"

    async def process_futures(self, state, router, trade_logger, risk_manager) -> None:
        fut_pos = router.get_futures_position()
        if fut_pos is None:
            self._last_fut_event_key = None
            return

        dash = await state.get_dashboard_state()
        prices = dash.get("market", {}).get("prices", {}) or {}
        sym = getattr(fut_pos, "symbol", "")
        price = safe_float(prices.get(sym), 0.0)

        if price <= 0:
            return

        result = router.check_futures_position(price)
        if not result or result.get("code") != "00000":
            if self.logger:
                self.logger.warning("TRADE_MANAGER", "futures check returned non-ok", {
                    "symbol": sym,
                    "result": result,
                })
            return

        data = result.get("data", {}) or {}

        if data.get("event_only"):
            reason = safe_str(data.get("reason"), "EVENT")
            pnl = safe_float(data.get("pnl"), 0.0)
            exit_price = safe_float(data.get("exit_price"), 0.0)
            event_key = self._event_key(sym, reason, exit_price, pnl)

            if event_key != self._last_fut_event_key:
                self._last_fut_event_key = event_key

                await state.add_sys_log(
                    "🟦 [FUT EVENT]",
                    f"{sym} {reason} | pnl={pnl:.8f} | px={exit_price:.8f}",
                )

                if self.logger:
                    self.logger.info("TRADE_MANAGER", "futures event", {
                        "symbol": sym,
                        "reason": reason,
                        "pnl": pnl,
                        "pnl_net": safe_float(data.get("pnl_net"), 0.0),
                        "exit_price": exit_price,
                        "setup_type": data.get("setup_type", ""),
                    })
            return

        # если после check позиция исчезла — значит она закрыта
        if router.get_futures_position() is None:
            pnl = safe_float(data.get("pnl", 0.0))
            reason = safe_str(data.get("reason", "UNKNOWN"))
            exit_price = safe_float(data.get("exit_price"), 0.0)

            risk_manager.register_close(sym, "fut", pnl, reason)

            await state.add_sys_log(
                "🟢 [FUT CLOSE]" if pnl >= 0 else "🔴 [FUT CLOSE]",
                f"{sym} {reason} | pnl={pnl:.8f} | exit={exit_price:.8f}",
            )

            if self.logger:
                self.logger.info("TRADE_MANAGER", "futures closed", {
                    "symbol": sym,
                    "reason": reason,
                    "pnl": pnl,
                    "exit_price": exit_price,
                    "setup_type": data.get("setup_type", ""),
                })

            trade_logger.log_trade(
                sym,
                safe_str(getattr(fut_pos, "side", "")).upper(),
                "FUT",
                safe_float(getattr(fut_pos, "entry", 0.0)),
                safe_float(getattr(fut_pos, "tp", 0.0)),
                exit_price,
                pnl,
                reason,
                safe_str(getattr(fut_pos, "setup_type", "")),
                safe_str(getattr(fut_pos, "args_text", "")),
            )

            self._last_fut_event_key = None

    async def process_spot(self, state, router, trade_logger, risk_manager) -> None:
        dash = await state.get_dashboard_state()
        prices = dash.get("market", {}).get("prices", {}) or {}

        for sym, pos in list(router.get_all_spot_positions().items()):
            price = safe_float(prices.get(sym), 0.0)
            if price <= 0:
                continue

            result = router.check_spot_position(sym, price)
            if not result or result.get("code") != "00000":
                if self.logger:
                    self.logger.warning("TRADE_MANAGER", "spot check returned non-ok", {
                        "symbol": sym,
                        "result": result,
                    })
                continue

            data = result.get("data", {}) or {}

            if data.get("event_only"):
                reason = safe_str(data.get("reason"), "EVENT")
                pnl = safe_float(data.get("pnl"), 0.0)
                exit_price = safe_float(data.get("exit_price"), 0.0)
                event_key = self._event_key(sym, reason, exit_price, pnl)

                if self._last_spot_event_keys.get(sym) != event_key:
                    self._last_spot_event_keys[sym] = event_key

                    await state.add_sys_log(
                        "🟨 [SPOT EVENT]",
                        f"{sym} {reason} | pnl={pnl:.8f} | px={exit_price:.8f}",
                    )

                    if self.logger:
                        self.logger.info("TRADE_MANAGER", "spot event", {
                            "symbol": sym,
                            "reason": reason,
                            "pnl": pnl,
                            "pnl_net": safe_float(data.get("pnl_net"), 0.0),
                            "exit_price": exit_price,
                            "setup_type": data.get("setup_type", ""),
                        })
                continue

            if router.get_spot_position(sym) is None:
                pnl = safe_float(data.get("pnl", 0.0))
                reason = safe_str(data.get("reason", "UNKNOWN"))
                exit_price = safe_float(data.get("exit_price"), 0.0)

                risk_manager.register_close(sym, "spot", pnl, reason)

                await state.add_sys_log(
                    "🟢 [SPOT CLOSE]" if pnl >= 0 else "🔴 [SPOT CLOSE]",
                    f"{sym} {reason} | pnl={pnl:.8f} | exit={exit_price:.8f}",
                )

                if self.logger:
                    self.logger.info("TRADE_MANAGER", "spot closed", {
                        "symbol": sym,
                        "reason": reason,
                        "pnl": pnl,
                        "exit_price": exit_price,
                        "setup_type": data.get("setup_type", ""),
                    })

                trade_logger.log_trade(
                    sym,
                    "BUY",
                    "SPOT",
                    safe_float(getattr(pos, "entry", 0.0)),
                    safe_float(getattr(pos, "tp", 0.0)),
                    exit_price,
                    pnl,
                    reason,
                    safe_str(getattr(pos, "setup_type", "")),
                    safe_str(getattr(pos, "args_text", "")),
                )

                if sym in self._last_spot_event_keys:
                    del self._last_spot_event_keys[sym]

    async def loop(self, state, router, trade_logger, risk_manager) -> None:
        await self.process_futures(
            state=state,
            router=router,
            trade_logger=trade_logger,
            risk_manager=risk_manager,
        )

        await self.process_spot(
            state=state,
            router=router,
            trade_logger=trade_logger,
            risk_manager=risk_manager,
        )