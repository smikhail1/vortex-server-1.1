from typing import Dict, Optional

from config import CONFIG
from contracts import StrategyResult
from validators import safe_bool, safe_float, safe_str


class SwingStrategy:
    """
    Core strategy:
    - основной сценарий: trend-following pullback / retest
    - вторичный сценарий: breakout continuation
    - жёсткий запрет chase-входов
    - обязательный учёт market regime + macro filter
    - анти-комиссионный фильтр

    Логика:
    - futures: chaotic/unknown блокируются, dead -> soft penalty
    - spot: chaotic/unknown/dead блокируются
    - futures: ничья -> no-trade
    - futures/spot: обязателен concrete setup
    - futures: volume confirmed добавляется только выбранному направлению
    - spot: trend_bias_1h == down блокирует вход
    """

    def __init__(
        self,
        ema_filter_enabled: bool = CONFIG.strategy.ema_filter_enabled,
        volume_filter_enabled: bool = CONFIG.strategy.volume_filter_enabled,
        min_vol_ratio_futures: float = CONFIG.strategy.min_vol_ratio_futures,
        min_vol_ratio_spot: float = CONFIG.strategy.min_vol_ratio_spot,
    ) -> None:
        self.ema_filter_enabled = bool(ema_filter_enabled)
        self.volume_filter_enabled = bool(volume_filter_enabled)
        self.min_vol_ratio_futures = float(min_vol_ratio_futures)
        self.min_vol_ratio_spot = float(min_vol_ratio_spot)

    def _block_by_macro(self, signal: Optional[str], macro_filter: str) -> Optional[str]:
        mf = safe_str(macro_filter, "allow_all")
        if signal in {"LONG", "BUY"} and mf == "block_longs":
            return "macro blocks longs"
        if signal == "SHORT" and mf == "block_shorts":
            return "macro blocks shorts"
        return None

    def _build_result(
        self,
        signal: Optional[str],
        score: int,
        setup_type: Optional[str],
        reasons: list[str],
        blocked_reason: Optional[str] = None,
        threshold: int = 999,
    ) -> Dict[str, object]:
        result = StrategyResult(
            should_open=False,
            signal=signal,
            setup_type=setup_type,
            score=int(score),
            args_text=" | ".join(reasons[:8]),
            blocked_reason=blocked_reason,
        )

        if signal is None:
            result.blocked_reason = result.blocked_reason or "no valid setup"
            return result.to_dict()

        result.should_open = score >= threshold and blocked_reason is None
        if not result.should_open and result.blocked_reason is None:
            result.blocked_reason = f"score<{threshold}"

        return result.to_dict()

    def _is_chasing_long(self, price: float, ema20: float, recent_high: float, atr: float) -> bool:
        if price <= 0 or ema20 <= 0 or atr <= 0:
            return False
        too_far_from_ema = price > ema20 + atr * 1.15
        too_close_to_recent_high = recent_high > 0 and price >= recent_high - atr * 0.15
        return too_far_from_ema or too_close_to_recent_high

    def _is_chasing_short(self, price: float, ema20: float, recent_low: float, atr: float) -> bool:
        if price <= 0 or ema20 <= 0 or atr <= 0:
            return False
        too_far_from_ema = price < ema20 - atr * 1.15
        too_close_to_recent_low = recent_low > 0 and price <= recent_low + atr * 0.15
        return too_far_from_ema or too_close_to_recent_low

    def _estimate_futures_roundtrip_cost_usdt(self, price: float) -> float:
        if price <= 0:
            return 0.0

        qty = CONFIG.trading.futures_margin_usdt / price
        notional = qty * price

        fee_cost = notional * (CONFIG.futures.taker_fee * 2.0)
        spread_slip_cost = notional * (
            (CONFIG.futures.spread_bps / 10000.0)
            + (CONFIG.futures.slippage_bps / 10000.0) * 2.0
        )

        return fee_cost + spread_slip_cost

    def _estimate_spot_roundtrip_cost_usdt(self, price: float) -> float:
        if price <= 0:
            return 0.0

        qty = CONFIG.trading.spot_order_usdt / price
        notional = qty * price

        fee_cost = notional * (CONFIG.spot.taker_fee * 2.0)
        spread_slip_cost = notional * (
            (CONFIG.spot.spread_bps / 10000.0)
            + (CONFIG.spot.slippage_bps / 10000.0) * 2.0
        )

        return fee_cost + spread_slip_cost

    def _estimate_futures_target_gross_usdt(self, price: float, tp: float) -> float:
        if price <= 0:
            return 0.0
        qty = CONFIG.trading.futures_margin_usdt / price
        return abs(tp - price) * qty

    def _estimate_spot_target_gross_usdt(self, price: float, tp: float) -> float:
        if price <= 0:
            return 0.0
        qty = CONFIG.trading.spot_order_usdt / price
        return abs(tp - price) * qty

    def _passes_futures_fee_guard(self, price: float, tp: float) -> tuple[bool, str]:
        if not CONFIG.strategy.fee_guard_enabled:
            return True, ""

        gross_target = self._estimate_futures_target_gross_usdt(price, tp)
        roundtrip_cost = self._estimate_futures_roundtrip_cost_usdt(price)

        threshold = max(
            roundtrip_cost * CONFIG.strategy.futures_fee_edge_multiplier,
            roundtrip_cost + CONFIG.strategy.futures_min_expected_net_usdt,
        )

        if gross_target < threshold:
            return False, f"fee_guard fut gross={gross_target:.4f} < need={threshold:.4f}"

        return True, ""

    def _passes_spot_fee_guard(self, price: float, tp: float) -> tuple[bool, str]:
        if not CONFIG.strategy.fee_guard_enabled:
            return True, ""

        gross_target = self._estimate_spot_target_gross_usdt(price, tp)
        roundtrip_cost = self._estimate_spot_roundtrip_cost_usdt(price)

        threshold = max(
            roundtrip_cost * CONFIG.strategy.spot_fee_edge_multiplier,
            roundtrip_cost + CONFIG.strategy.spot_min_expected_net_usdt,
        )

        if gross_target < threshold:
            return False, f"fee_guard spot gross={gross_target:.4f} < need={threshold:.4f}"

        return True, ""

    # ─────────────────────────────────────────────
    # FUTURES
    # ─────────────────────────────────────────────

    def analyze_futures(self, data: Dict[str, object], macro_filter: str) -> Dict[str, object]:
        price = safe_float(data.get("price"))
        atr = safe_float(data.get("atr"))
        ema20 = safe_float(data.get("ema20"))
        ema50 = safe_float(data.get("ema50"))
        rsi = safe_float(data.get("rsi_main"), 50.0)
        vol_ratio = safe_float(data.get("vol_ratio"), 1.0)
        trend_4h = safe_str(data.get("trend_4h"), "neutral")
        trend_bias_1h = safe_str(data.get("trend_bias_1h"), "neutral")
        market_regime = safe_str(data.get("market_regime"), "unknown")
        breakout = safe_bool(data.get("breakout"))
        breakout_dir = safe_str(data.get("breakout_dir"), "")
        near_support = safe_bool(data.get("near_support"))
        near_resistance = safe_bool(data.get("near_resistance"))
        pullback_long_ready = safe_bool(data.get("pullback_long_ready"))
        pullback_short_ready = safe_bool(data.get("pullback_short_ready"))
        retest_long_ready = safe_bool(data.get("retest_long_ready"))
        retest_short_ready = safe_bool(data.get("retest_short_ready"))
        vol_confirmed = safe_bool(
            data.get("vol_confirmed"),
            vol_ratio >= self.min_vol_ratio_futures,
        )
        breakout_volume_confirmed = safe_bool(
            data.get("breakout_volume_confirmed"),
            vol_ratio >= CONFIG.regime.breakout_volume_threshold,
        )
        recent_high = safe_float(data.get("recent_high"))
        recent_low = safe_float(data.get("recent_low"))

        if price <= 0 or atr <= 0:
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason="invalid price/atr",
                threshold=CONFIG.trading.futures_min_score_to_open,
            )

        if market_regime in {"chaotic", "unknown"}:
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason=f"bad regime:{market_regime}",
                threshold=CONFIG.trading.futures_min_score_to_open,
            )

        is_dead_regime = market_regime == "dead"

        has_long_setup = (
            pullback_long_ready
            or retest_long_ready
            or (breakout and breakout_dir == "up" and breakout_volume_confirmed)
        )
        has_short_setup = (
            pullback_short_ready
            or retest_short_ready
            or (breakout and breakout_dir == "down" and breakout_volume_confirmed)
        )

        if not has_long_setup and not has_short_setup:
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason="no concrete setup",
                threshold=CONFIG.trading.futures_min_score_to_open,
            )

        long_score = 0
        short_score = 0
        long_reasons: list[str] = []
        short_reasons: list[str] = []

        if trend_4h in {"up", "strong_up"}:
            pts = 2 if trend_4h == "up" else 3
            long_score += pts
            long_reasons.append(f"4H {trend_4h}")
        elif trend_4h in {"down", "strong_down"}:
            pts = 2 if trend_4h == "down" else 3
            short_score += pts
            short_reasons.append(f"4H {trend_4h}")

        if trend_bias_1h == "up":
            long_score += 1
            long_reasons.append("1H bullish bias")
        elif trend_bias_1h == "down":
            short_score += 1
            short_reasons.append("1H bearish bias")

        if pullback_long_ready:
            long_score += 3
            long_reasons.append("pullback long ready")
        if pullback_short_ready:
            short_score += 3
            short_reasons.append("pullback short ready")

        if retest_long_ready:
            long_score += 3
            long_reasons.append("retest long ready")
        if retest_short_ready:
            short_score += 3
            short_reasons.append("retest short ready")

        if breakout and breakout_dir == "up" and breakout_volume_confirmed:
            long_score += 2
            long_reasons.append("breakout continuation up")
        elif breakout and breakout_dir == "down" and breakout_volume_confirmed:
            short_score += 2
            short_reasons.append("breakout continuation down")

        if near_support:
            long_score += 1
            long_reasons.append("near support")
        if near_resistance:
            short_score += 1
            short_reasons.append("near resistance")

        if self.ema_filter_enabled:
            if price > ema20 > ema50:
                long_score += 1
                long_reasons.append("EMA aligned long")
            elif price < ema20 < ema50:
                short_score += 1
                short_reasons.append("EMA aligned short")

        if rsi >= CONFIG.strategy.long_rsi_min:
            long_score += 1
            long_reasons.append("RSI supports long")
        if rsi <= CONFIG.strategy.short_rsi_max:
            short_score += 1
            short_reasons.append("RSI supports short")

        if is_dead_regime:
            long_score = max(0, long_score - 2)
            short_score = max(0, short_score - 2)

            if long_score > 0:
                long_reasons.append("dead regime penalty")
            if short_score > 0:
                short_reasons.append("dead regime penalty")

        if long_score == short_score:
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason="tie no-trade",
                threshold=CONFIG.trading.futures_min_score_to_open,
            )

        signal: Optional[str] = None
        score = 0
        setup_type: Optional[str] = None
        reasons: list[str] = []

        if long_score > short_score and has_long_setup:
            signal = "LONG"
            score = int(long_score)
            if self.volume_filter_enabled and vol_confirmed:
                score += 1
                long_reasons.append("volume confirmed")
            if pullback_long_ready:
                setup_type = "pullback_long"
            elif retest_long_ready:
                setup_type = "retest_long"
            elif breakout and breakout_dir == "up":
                setup_type = "breakout_long"
            else:
                setup_type = "trend_long"
            reasons = long_reasons

        elif short_score > long_score and has_short_setup:
            signal = "SHORT"
            score = int(short_score)
            if self.volume_filter_enabled and vol_confirmed:
                score += 1
                short_reasons.append("volume confirmed")
            if pullback_short_ready:
                setup_type = "pullback_short"
            elif retest_short_ready:
                setup_type = "retest_short"
            elif breakout and breakout_dir == "down":
                setup_type = "breakout_short"
            else:
                setup_type = "trend_short"
            reasons = short_reasons

        if signal is None:
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason="no valid futures setup",
                threshold=CONFIG.trading.futures_min_score_to_open,
            )

        if signal == "LONG" and self._is_chasing_long(price, ema20, recent_high, atr):
            return self._build_result(
                signal=signal,
                score=score,
                setup_type=setup_type,
                reasons=reasons,
                blocked_reason="no-chase long",
                threshold=CONFIG.trading.futures_min_score_to_open,
            )

        if signal == "SHORT" and self._is_chasing_short(price, ema20, recent_low, atr):
            return self._build_result(
                signal=signal,
                score=score,
                setup_type=setup_type,
                reasons=reasons,
                blocked_reason="no-chase short",
                threshold=CONFIG.trading.futures_min_score_to_open,
            )

        macro_block = self._block_by_macro(signal, macro_filter)
        if macro_block:
            return self._build_result(
                signal=signal,
                score=score,
                setup_type=setup_type,
                reasons=reasons,
                blocked_reason=macro_block,
                threshold=CONFIG.trading.futures_min_score_to_open,
            )

        trade_plan = self.calculate_futures_trade(
            price=price,
            side=signal,
            atr=atr,
            setup_type=setup_type,
        )
        fee_guard_ok, fee_guard_reason = self._passes_futures_fee_guard(price, trade_plan["tp"])
        if not fee_guard_ok:
            return self._build_result(
                signal=signal,
                score=score,
                setup_type=setup_type,
                reasons=reasons,
                blocked_reason=fee_guard_reason,
                threshold=CONFIG.trading.futures_min_score_to_open,
            )

        return self._build_result(
            signal=signal,
            score=score,
            setup_type=setup_type,
            reasons=reasons,
            blocked_reason=None,
            threshold=CONFIG.trading.futures_min_score_to_open,
        )

    # ─────────────────────────────────────────────
    # SPOT
    # ─────────────────────────────────────────────

    def analyze_spot(self, data: Dict[str, object], macro_filter: str) -> Dict[str, object]:
        price = safe_float(data.get("price"))
        atr = safe_float(data.get("atr"))
        ema20 = safe_float(data.get("ema20"))
        ema50 = safe_float(data.get("ema50"))
        rsi = safe_float(data.get("rsi_main"), 50.0)
        vol_ratio = safe_float(data.get("vol_ratio"), 1.0)
        trend_4h = safe_str(data.get("trend_4h"), "neutral")
        trend_bias_1h = safe_str(data.get("trend_bias_1h"), "neutral")
        market_regime = safe_str(data.get("market_regime"), "unknown")
        breakout = safe_bool(data.get("breakout"))
        breakout_dir = safe_str(data.get("breakout_dir"), "")
        near_support = safe_bool(data.get("near_support"))
        pullback_long_ready = safe_bool(data.get("pullback_long_ready"))
        retest_long_ready = safe_bool(data.get("retest_long_ready"))
        vol_confirmed = safe_bool(
            data.get("vol_confirmed"),
            vol_ratio >= self.min_vol_ratio_spot,
        )
        breakout_volume_confirmed = safe_bool(
            data.get("breakout_volume_confirmed"),
            vol_ratio >= CONFIG.regime.breakout_volume_threshold,
        )
        recent_high = safe_float(data.get("recent_high"))

        if price <= 0 or atr <= 0:
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason="invalid price/atr",
                threshold=CONFIG.trading.spot_min_score_to_open,
            )

        if market_regime in {"chaotic", "unknown", "dead"}:
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason=f"bad regime:{market_regime}",
                threshold=CONFIG.trading.spot_min_score_to_open,
            )

        if trend_4h not in {"up", "strong_up"}:
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason=f"spot requires uptrend:{trend_4h}",
                threshold=CONFIG.trading.spot_min_score_to_open,
            )

        if trend_bias_1h == "down":
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason="spot 1H bias down",
                threshold=CONFIG.trading.spot_min_score_to_open,
            )

        has_setup = (
            pullback_long_ready
            or retest_long_ready
            or (breakout and breakout_dir == "up" and breakout_volume_confirmed)
        )
        if not has_setup:
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason="no concrete setup",
                threshold=CONFIG.trading.spot_min_score_to_open,
            )

        score = 0
        reasons: list[str] = []

        score += 2 if trend_4h == "up" else 3
        reasons.append(f"4H {trend_4h}")

        if trend_bias_1h == "up":
            score += 1
            reasons.append("1H bullish bias")

        if self.ema_filter_enabled and price > ema20 > ema50:
            score += 1
            reasons.append("EMA aligned")

        if near_support:
            score += 1
            reasons.append("near support")

        if pullback_long_ready:
            score += 3
            reasons.append("pullback ready")

        if retest_long_ready:
            score += 3
            reasons.append("retest ready")

        if breakout and breakout_dir == "up" and breakout_volume_confirmed:
            score += 2
            reasons.append("breakout continuation")

        if self.volume_filter_enabled and vol_confirmed:
            score += 1
            reasons.append("volume confirmed")

        if rsi >= CONFIG.strategy.long_rsi_min:
            score += 1
            reasons.append("RSI supports")

        if score <= 0:
            return self._build_result(
                signal=None,
                score=0,
                setup_type=None,
                reasons=[],
                blocked_reason="no valid spot setup",
                threshold=CONFIG.trading.spot_min_score_to_open,
            )

        setup_type = (
            "spot_pullback"
            if pullback_long_ready
            else ("spot_retest" if retest_long_ready else "spot_breakout")
        )

        if self._is_chasing_long(price, ema20, recent_high, atr):
            return self._build_result(
                signal="BUY",
                score=score,
                setup_type=setup_type,
                reasons=reasons,
                blocked_reason="no-chase long",
                threshold=CONFIG.trading.spot_min_score_to_open,
            )

        macro_block = self._block_by_macro("BUY", macro_filter)
        if macro_block:
            return self._build_result(
                signal="BUY",
                score=score,
                setup_type=setup_type,
                reasons=reasons,
                blocked_reason=macro_block,
                threshold=CONFIG.trading.spot_min_score_to_open,
            )

        trade_plan = self.calculate_spot_ladder(
            price=price,
            setup_type=setup_type,
        )
        fee_guard_ok, fee_guard_reason = self._passes_spot_fee_guard(price, trade_plan["tp"])
        if not fee_guard_ok:
            return self._build_result(
                signal="BUY",
                score=score,
                setup_type=setup_type,
                reasons=reasons,
                blocked_reason=fee_guard_reason,
                threshold=CONFIG.trading.spot_min_score_to_open,
            )

        return self._build_result(
            signal="BUY",
            score=score,
            setup_type=setup_type,
            reasons=reasons,
            blocked_reason=None,
            threshold=CONFIG.trading.spot_min_score_to_open,
        )

    def calculate_futures_trade(self, price: float, side: str, atr: float, setup_type: Optional[str]) -> Dict[str, float]:
        px = safe_float(price)
        atr_abs = safe_float(atr)
        signal = safe_str(side).upper()

        if signal == "LONG":
            tp = px + atr_abs * CONFIG.strategy.futures_tp_atr_mult
            sl = px - atr_abs * CONFIG.strategy.futures_sl_atr_mult
        else:
            tp = px - atr_abs * CONFIG.strategy.futures_tp_atr_mult
            sl = px + atr_abs * CONFIG.strategy.futures_sl_atr_mult

        leverage = CONFIG.trading.futures_default_leverage
        if setup_type and "breakout" in safe_str(setup_type):
            leverage = max(2.0, CONFIG.trading.futures_default_leverage - 0.5)

        return {
            "tp": round(tp, 8),
            "sl": round(sl, 8),
            "leverage": round(leverage, 4),
        }

    def calculate_spot_ladder(self, price: float, setup_type: Optional[str]) -> Dict[str, float]:
        px = safe_float(price)

        if setup_type and "breakout" in safe_str(setup_type):
            tp = px * 1.04
        else:
            tp = px * 1.028

        return {
            "tp": round(tp, 8),
        }