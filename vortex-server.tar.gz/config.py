from dataclasses import dataclass, field
from typing import Dict, List


@dataclass(frozen=True)
class ServerConfig:
    host: str = "0.0.0.0"
    port: int = 8000
    cors_allow_all: bool = True


@dataclass(frozen=True)
class LoopIntervals:
    market_data_sec: float = 1.0
    pool_rotation_sec: float = 30.0
    ta_sec: float = 2.0
    system_metrics_sec: float = 5.0
    monitor_sec: float = 10.0
    router_sync_sec: float = 1.0
    planner_market_sec: float = 600.0
    planner_sec: float = 120.0
    watchlist_sec: float = 5.0
    strategy_sec: float = 5.0
    execution_sec: float = 1.0
    oracle_sec: float = 10.0
    safe_loop_backoff_sec: float = 2.0


@dataclass(frozen=True)
class UniverseConfig:
    enabled: bool = True
    refresh_sec: int = 30
    top_n: int = 50
    fut_pool_size: int = 5
    spot_pool_size: int = 3
    min_quote_volume_usdt: float = 10_000_000.0
    min_last_price: float = 0.000001
    max_last_price: float = 1_000_000.0
    exclude_stables: bool = True
    exclude_leveraged_tokens: bool = True
    exclude_fiat_pairs: bool = True
    fallback_symbols: List[str] = field(
        default_factory=lambda: [
            "BTCUSDT",
            "ETHUSDT",
            "SOLUSDT",
            "BNBUSDT",
            "XRPUSDT",
            "ADAUSDT",
            "LINKUSDT",
            "AVAXUSDT",
            "NEARUSDT",
            "ARBUSDT",
        ]
    )
    excluded_base_assets: List[str] = field(
        default_factory=lambda: [
            "USDC",
            "FDUSD",
            "TUSD",
            "BUSD",
            "USDP",
            "DAI",
            "EUR",
            "EURS",
            "GBP",
            "TRY",
            "BRL",
            "UAH",
            "RUB",
            "AUD",
            "JPY",
            "USD1",
            "PYUSD",
            "USDE",
            "USDD",
            "FRAX",
            "MIM",
            "RLUSD",
            "XAUT",
            "PAXG",
        ]
    )


@dataclass(frozen=True)
class TradingConfig:
    mode: str = "PAPER"

    futures_margin_usdt: float = 20.0
    spot_order_usdt: float = 20.0

    futures_default_leverage: float = 3.0

    futures_min_score_to_open: int = 7
    spot_min_score_to_open: int = 4
    watchlist_min_score: int = 3

    allow_manual_trades: bool = True
    allow_force_close: bool = True
    allow_risk_reset: bool = True
    debug_api_enabled: bool = True


@dataclass(frozen=True)
class RiskConfig:
    futures_symbol_cooldown_sec: int = 1800
    spot_symbol_cooldown_sec: int = 1800
    max_trades_per_symbol_per_day: int = 5
    daily_loss_limit_usdt: float = -5.0
    max_open_futures_positions: int = 1
    max_open_spot_positions: int = 5


@dataclass(frozen=True)
class PaperFuturesConfig:
    start_balance: float = 100.0
    taker_fee: float = 0.0006
    maker_fee: float = 0.0002
    spread_bps: float = 4.0
    slippage_bps: float = 2.0
    maintenance_margin_rate: float = 0.005

    profit_timeout_sec: int = 1200
    tp1_stall_sec: int = 900
    min_timeout_profit_usdt: float = 0.20

    fade_giveback_pct: float = 0.90


@dataclass(frozen=True)
class PaperSpotConfig:
    start_balance: float = 100.0
    taker_fee: float = 0.001
    maker_fee: float = 0.0008
    spread_bps: float = 4.0
    slippage_bps: float = 2.0
    profit_timeout_sec: int = 900
    tp1_stall_sec: int = 600
    min_timeout_profit_usdt: float = 0.10
    fade_giveback_pct: float = 0.65


@dataclass(frozen=True)
class StrategyConfig:
    ema_filter_enabled: bool = True
    volume_filter_enabled: bool = True
    min_vol_ratio_futures: float = 1.10
    min_vol_ratio_spot: float = 1.05

    futures_tp_atr_mult: float = 3.2
    futures_sl_atr_mult: float = 1.4
    spot_tp_atr_mult: float = 3.0
    spot_sl_atr_mult: float = 2.0

    long_rsi_min: float = 45.0
    short_rsi_max: float = 55.0

    # Анти-комиссионный фильтр
    fee_guard_enabled: bool = True

    futures_fee_edge_multiplier: float = 2.2
    spot_fee_edge_multiplier: float = 2.6

    futures_min_expected_net_usdt: float = 0.03
    spot_min_expected_net_usdt: float = 0.08


@dataclass(frozen=True)
class RegimeConfig:
    min_history_bars: int = 20
    strong_trend_ema_gap_pct: float = 0.35
    weak_trend_ema_gap_pct: float = 0.12
    breakout_buffer_atr: float = 0.08
    retest_buffer_atr: float = 0.35
    pullback_zone_buffer_pct: float = 0.0025
    pullback_ema50_tolerance_pct: float = 0.006
    min_workable_atr_pct: float = 1.0
    max_bad_atr_pct: float = 14.0
    vol_spike_threshold: float = 1.5
    breakout_volume_threshold: float = 1.2
    trend_volume_threshold: float = 1.0
    macro_fng_riskoff_threshold: int = 35
    macro_fng_riskon_threshold: int = 60


@dataclass(frozen=True)
class PlannerConfig:
    enabled: bool = True
    max_ideas: int = 12
    snapshot_universe: List[str] = field(
        default_factory=lambda: [
            "BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT", "XRPUSDT", "ADAUSDT",
            "LINKUSDT", "AVAXUSDT", "ARBUSDT", "OPUSDT", "INJUSDT", "ATOMUSDT",
            "NEARUSDT", "IMXUSDT", "RNDRUSDT", "FETUSDT", "SUIUSDT", "APTUSDT",
        ]
    )


@dataclass(frozen=True)
class LoggingConfig:
    runtime_log_path: str = "vortex.log"
    trades_csv_path: str = "trades.csv"
    max_sys_logs: int = 300
    print_to_stdout: bool = True


@dataclass(frozen=True)
class AppConfig:
    server: ServerConfig = ServerConfig()
    loops: LoopIntervals = LoopIntervals()
    universe: UniverseConfig = UniverseConfig()
    trading: TradingConfig = TradingConfig()
    risk: RiskConfig = RiskConfig()
    futures: PaperFuturesConfig = PaperFuturesConfig()
    spot: PaperSpotConfig = PaperSpotConfig()
    strategy: StrategyConfig = StrategyConfig()
    regime: RegimeConfig = RegimeConfig()
    planner: PlannerConfig = PlannerConfig()
    logging: LoggingConfig = LoggingConfig()


CONFIG = AppConfig()


DEFAULT_STATE_META: Dict[str, str] = {
    "version": "1.4-core",
    "compatibility": "android-vortex-terminal",
    "mode": CONFIG.trading.mode,
}