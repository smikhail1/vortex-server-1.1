import asyncio
from typing import Any, Dict

from aiohttp import web
import aiohttp_cors

from config import CONFIG
from validators import safe_float, safe_int, safe_str


class APIServer:
    def __init__(
        self,
        state_manager,
        execution_router=None,
        risk_manager=None,
        logger=None,
        mode: str = "PAPER",
    ):
        self.state = state_manager
        self.router = execution_router
        self.risk_manager = risk_manager
        self.logger = logger
        self.mode = safe_str(mode, "PAPER").upper()
        self.app = web.Application()

        cors = aiohttp_cors.setup(
            self.app,
            defaults={
                "*": aiohttp_cors.ResourceOptions(
                    allow_credentials=True,
                    expose_headers="*",
                    allow_headers="*",
                )
            },
        )

        routes = [
            self.app.router.add_get("/api/dashboard", self.handle_dashboard),
            self.app.router.add_get("/api/health", self.handle_health),
            self.app.router.add_get("/api/spot-planner", self.handle_spot_planner),
        ]

        if CONFIG.trading.debug_api_enabled:
            routes.extend([
                self.app.router.add_get("/api/debug/runtime", self.handle_debug_runtime),
                self.app.router.add_get("/api/debug/test-config", self.handle_debug_test_config),
                self.app.router.add_post("/api/debug/open-futures", self.handle_debug_open_futures),
                self.app.router.add_post("/api/debug/close-futures", self.handle_debug_close_futures),
                self.app.router.add_post("/api/debug/open-spot", self.handle_debug_open_spot),
                self.app.router.add_post("/api/debug/close-spot", self.handle_debug_close_spot),
                self.app.router.add_post("/api/debug/close-all-spot", self.handle_debug_close_all_spot),
                self.app.router.add_post("/api/debug/risk/reset", self.handle_debug_risk_reset),
                self.app.router.add_get("/api/debug/risk/status", self.handle_debug_risk_status),
                self.app.router.add_post("/api/debug/state/reload", self.handle_debug_state_reload),
                self.app.router.add_get("/api/debug/logs/tail", self.handle_debug_logs_tail),
            ])

        for route in routes:
            cors.add(route)

    async def _build_dashboard_payload(self) -> Dict[str, Any]:
        dashboard = await self.state.get_dashboard_state()

        fut_positions = dashboard.get("positions", {}).get("fut", {}) or {}
        spot_positions = dashboard.get("positions", {}).get("spot", {}) or {}
        balances = dashboard.get("account", {}).get("balances", {}) or {}

        dashboard["today"] = {
            "today_realized_fut": 0.0,
            "today_realized_spot": 0.0,
            "today_total_realized": 0.0,
            "today_open_fut": round(sum(safe_float(p.get("pnl_net", 0.0)) for p in fut_positions.values()), 4),
            "today_open_spot": round(sum(safe_float(p.get("pnl_net", 0.0)) for p in spot_positions.values()), 4),
            "today_total_open": round(
                sum(safe_float(p.get("pnl_net", 0.0)) for p in fut_positions.values())
                + sum(safe_float(p.get("pnl_net", 0.0)) for p in spot_positions.values()),
                4,
            ),
        }

        dashboard["portfolio"] = {
            "spot_free": round(safe_float(balances.get("spot", 0.0)), 4),
            "spot_equity": round(
                safe_float(balances.get("spot", 0.0))
                + sum(safe_float(p.get("pnl_net", 0.0)) for p in spot_positions.values()),
                4,
            ),
            "fut_free": round(safe_float(balances.get("fut", 0.0)), 4),
            "fut_equity": round(
                safe_float(balances.get("fut", 0.0))
                + sum(safe_float(p.get("pnl_net", 0.0)) for p in fut_positions.values()),
                4,
            ),
            "total_equity": round(
                safe_float(balances.get("spot", 0.0))
                + safe_float(balances.get("fut", 0.0))
                + sum(safe_float(p.get("pnl_net", 0.0)) for p in spot_positions.values())
                + sum(safe_float(p.get("pnl_net", 0.0)) for p in fut_positions.values()),
                4,
            ),
        }

        dashboard["counts"] = {
            "fut_open_positions": len(fut_positions),
            "spot_open_positions": len(spot_positions),
        }

        return dashboard

    async def handle_dashboard(self, request: web.Request) -> web.Response:
        return web.json_response(await self._build_dashboard_payload())

    async def handle_health(self, request: web.Request) -> web.Response:
        return web.json_response(await self.state.get_health_state(mode=self.mode))

    async def handle_spot_planner(self, request: web.Request) -> web.Response:
        return web.json_response(await self.state.get_spot_planner_state())

    async def handle_debug_runtime(self, request: web.Request) -> web.Response:
        state_snapshot = await self.state.get_runtime_snapshot()
        router_snapshot = self.router.get_runtime_snapshot() if self.router else {}
        risk_status = self.risk_manager.get_status() if self.risk_manager else {}

        return web.json_response({
            "state": state_snapshot,
            "router": router_snapshot,
            "risk": risk_status,
        })

    async def handle_debug_test_config(self, request: web.Request) -> web.Response:
        return web.json_response({
            "mode": CONFIG.trading.mode,
            "allow_manual_trades": CONFIG.trading.allow_manual_trades,
            "allow_force_close": CONFIG.trading.allow_force_close,
            "allow_risk_reset": CONFIG.trading.allow_risk_reset,
            "debug_api_enabled": CONFIG.trading.debug_api_enabled,
            "futures_margin_usdt": CONFIG.trading.futures_margin_usdt,
            "spot_order_usdt": CONFIG.trading.spot_order_usdt,
            "futures_default_leverage": CONFIG.trading.futures_default_leverage,
        })

    async def handle_debug_open_futures(self, request: web.Request) -> web.Response:
        if not CONFIG.trading.allow_manual_trades or self.router is None:
            return web.json_response({"code": "ERROR", "msg": "manual futures disabled"}, status=403)

        payload = await request.json()
        result = self.router.manual_open_futures(
            symbol=safe_str(payload.get("symbol"), "BTCUSDT"),
            side=safe_str(payload.get("side"), "LONG"),
            price=safe_float(payload.get("price")),
            atr=safe_float(payload.get("atr")),
            margin_usdt=safe_float(payload.get("margin_usdt"), CONFIG.trading.futures_margin_usdt),
            leverage=safe_float(payload.get("leverage"), CONFIG.trading.futures_default_leverage),
            tp_mult=safe_float(payload.get("tp_mult"), CONFIG.strategy.futures_tp_atr_mult),
            sl_mult=safe_float(payload.get("sl_mult"), CONFIG.strategy.futures_sl_atr_mult),
            setup_type=safe_str(payload.get("setup_type"), "manual_fut"),
            args_text=safe_str(payload.get("args_text"), "manual futures open"),
        )

        if self.logger:
            self.logger.info("DEBUG_API", "manual futures open", {"payload": payload, "result": result})

        return web.json_response(result)

    async def handle_debug_close_futures(self, request: web.Request) -> web.Response:
        if not CONFIG.trading.allow_force_close or self.router is None:
            return web.json_response({"code": "ERROR", "msg": "manual futures close disabled"}, status=403)

        payload = await request.json()
        current_price = safe_float(payload.get("price"))
        reason = safe_str(payload.get("reason"), "MANUAL")

        result = self.router.close_futures_position(current_price=current_price, reason=reason)
        if result is None:
            result = {"code": "ERROR", "msg": "no open futures position"}

        if self.logger:
            self.logger.info("DEBUG_API", "manual futures close", {"payload": payload, "result": result})

        return web.json_response(result)

    async def handle_debug_open_spot(self, request: web.Request) -> web.Response:
        if not CONFIG.trading.allow_manual_trades or self.router is None:
            return web.json_response({"code": "ERROR", "msg": "manual spot disabled"}, status=403)

        payload = await request.json()
        result = self.router.manual_open_spot(
            symbol=safe_str(payload.get("symbol"), "BTCUSDT"),
            price=safe_float(payload.get("price")),
            atr=safe_float(payload.get("atr")),
            order_usdt=safe_float(payload.get("order_usdt"), CONFIG.trading.spot_order_usdt),
            tp_mult=safe_float(payload.get("tp_mult"), CONFIG.strategy.spot_tp_atr_mult),
            setup_type=safe_str(payload.get("setup_type"), "manual_spot"),
            args_text=safe_str(payload.get("args_text"), "manual spot open"),
        )

        if self.logger:
            self.logger.info("DEBUG_API", "manual spot open", {"payload": payload, "result": result})

        return web.json_response(result)

    async def handle_debug_close_spot(self, request: web.Request) -> web.Response:
        if not CONFIG.trading.allow_force_close or self.router is None:
            return web.json_response({"code": "ERROR", "msg": "manual spot close disabled"}, status=403)

        payload = await request.json()
        symbol = safe_str(payload.get("symbol"), "")
        current_price = safe_float(payload.get("price"))
        reason = safe_str(payload.get("reason"), "MANUAL")

        result = self.router.close_spot_position(symbol=symbol, current_price=current_price, reason=reason)
        if result is None:
            result = {"code": "ERROR", "msg": "no open spot position for symbol"}

        if self.logger:
            self.logger.info("DEBUG_API", "manual spot close", {"payload": payload, "result": result})

        return web.json_response(result)

    async def handle_debug_close_all_spot(self, request: web.Request) -> web.Response:
        if not CONFIG.trading.allow_force_close or self.router is None:
            return web.json_response({"code": "ERROR", "msg": "manual spot close-all disabled"}, status=403)

        payload = await request.json()
        prices = payload.get("prices", {}) or {}
        reason = safe_str(payload.get("reason"), "MANUAL")

        result = self.router.manual_close_all_spot(prices=prices, reason=reason)

        if self.logger:
            self.logger.info("DEBUG_API", "manual spot close-all", {"payload": payload, "result_count": len(result)})

        return web.json_response({"code": "00000", "data": result})

    async def handle_debug_risk_reset(self, request: web.Request) -> web.Response:
        if not CONFIG.trading.allow_risk_reset or self.risk_manager is None:
            return web.json_response({"code": "ERROR", "msg": "risk reset disabled"}, status=403)

        self.risk_manager.reset()

        if self.logger:
            self.logger.info("DEBUG_API", "risk reset", {})

        return web.json_response({"code": "00000", "msg": "risk reset ok"})

    async def handle_debug_risk_status(self, request: web.Request) -> web.Response:
        if self.risk_manager is None:
            return web.json_response({"code": "ERROR", "msg": "risk manager unavailable"}, status=503)
        return web.json_response(self.risk_manager.get_status())

    async def handle_debug_state_reload(self, request: web.Request) -> web.Response:
        payload = await request.json()
        new_state = payload.get("state")

        if not isinstance(new_state, dict):
            return web.json_response({"code": "ERROR", "msg": "state must be dict"}, status=400)

        await self.state.replace_state(new_state)

        if self.logger:
            self.logger.info("DEBUG_API", "state replaced", {})

        return web.json_response({"code": "00000", "msg": "state replaced"})

    async def handle_debug_logs_tail(self, request: web.Request) -> web.Response:
        lines = safe_int(request.query.get("lines"), 50)
        if self.logger is None:
            return web.json_response({"code": "ERROR", "msg": "logger unavailable"}, status=503)

        return web.json_response({
            "code": "00000",
            "data": {
                "lines": lines,
                "tail": self.logger.tail_runtime(lines=lines),
            },
        })

    async def start(self, port: int = CONFIG.server.port) -> None:
        runner = web.AppRunner(self.app)
        await runner.setup()
        site = web.TCPSite(runner, CONFIG.server.host, port)
        await site.start()

        if self.logger:
            self.logger.info("API", f"server started on {CONFIG.server.host}:{port}", {})
        else:
            print(f"🚀 API сервер запущен на порту {port}", flush=True)

        while True:
            await asyncio.sleep(3600)