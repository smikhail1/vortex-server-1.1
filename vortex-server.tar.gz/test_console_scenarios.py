import json
import time
import urllib.request


BASE_URL = "http://127.0.0.1:8000"


def http_get(path: str):
    req = urllib.request.Request(BASE_URL + path, method="GET")
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8"))


def http_post(path: str, payload: dict):
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        BASE_URL + path,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8"))


def assert_true(condition: bool, message: str):
    if not condition:
        raise AssertionError(message)


def scenario_health_alive():
    data = http_get("/api/health")
    assert_true("status" in data, "health has no status")
    print("OK: scenario_health_alive")


def scenario_runtime_alive():
    data = http_get("/api/debug/runtime")
    assert_true("state" in data, "runtime has no state")
    assert_true("router" in data, "runtime has no router")
    print("OK: scenario_runtime_alive")


def scenario_watchlist_not_empty_or_pools_empty():
    dash = http_get("/api/dashboard")
    fut_pool = dash.get("system", {}).get("fut_pool", [])
    spot_pool = dash.get("system", {}).get("spot_pool", [])
    watch = dash.get("terminal", {}).get("watchlist_mini", [])

    if fut_pool or spot_pool:
        assert_true(isinstance(watch, list), "watchlist is not list")
    print("OK: scenario_watchlist_not_empty_or_pools_empty")


def scenario_manual_fut_open_close():
    open_result = http_post("/api/debug/open-futures", {
        "symbol": "BTCUSDT",
        "side": "LONG",
        "price": 65000,
        "atr": 500,
        "margin_usdt": 20,
        "leverage": 3,
        "setup_type": "test_manual_fut",
        "args_text": "scenario manual futures",
    })
    assert_true(open_result.get("code") == "00000", f"futures open failed: {open_result}")

    runtime = http_get("/api/debug/runtime")
    fut_pos = runtime.get("router", {}).get("fut_position")
    assert_true(fut_pos is not None, "futures position missing after open")

    close_result = http_post("/api/debug/close-futures", {
        "price": 65500,
        "reason": "MANUAL",
    })
    assert_true(close_result.get("code") == "00000", f"futures close failed: {close_result}")
    print("OK: scenario_manual_fut_open_close")


def scenario_manual_spot_open_close():
    open_result = http_post("/api/debug/open-spot", {
        "symbol": "ETHUSDT",
        "price": 3200,
        "atr": 40,
        "order_usdt": 20,
        "setup_type": "test_manual_spot",
        "args_text": "scenario manual spot",
    })
    assert_true(open_result.get("code") == "00000", f"spot open failed: {open_result}")

    runtime = http_get("/api/debug/runtime")
    spot_positions = runtime.get("router", {}).get("spot_positions", {})
    assert_true("ETHUSDT" in spot_positions, "spot position missing after open")

    close_result = http_post("/api/debug/close-spot", {
        "symbol": "ETHUSDT",
        "price": 3260,
        "reason": "MANUAL",
    })
    assert_true(close_result.get("code") == "00000", f"spot close failed: {close_result}")
    print("OK: scenario_manual_spot_open_close")


def scenario_risk_reset():
    data = http_post("/api/debug/risk/reset", {})
    assert_true(data.get("code") == "00000", f"risk reset failed: {data}")
    print("OK: scenario_risk_reset")


def scenario_logs_tail():
    data = http_get("/api/debug/logs/tail?lines=10")
    assert_true(data.get("code") == "00000", f"log tail failed: {data}")
    print("OK: scenario_logs_tail")


def run_all():
    scenario_health_alive()
    scenario_runtime_alive()
    scenario_watchlist_not_empty_or_pools_empty()
    scenario_risk_reset()
    scenario_manual_fut_open_close()
    scenario_manual_spot_open_close()
    scenario_logs_tail()
    print("ALL SCENARIOS PASSED")


if __name__ == "__main__":
    run_all()