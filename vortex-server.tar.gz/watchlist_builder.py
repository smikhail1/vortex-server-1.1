from typing import Dict, List

from config import CONFIG
from validators import safe_float, safe_int, safe_str


class WatchlistBuilder:
    """
    Terminal watchlist:
    - planner != watchlist
    - watchlist показывает только рыночных кандидатов для торговли

    Состояния:
    - ready
    - near_entry
    - watch
    - blocked
    """

    def __init__(self, strategy, logger=None) -> None:
        self.strategy = strategy
        self.logger = logger

    def _status_from_analysis(self, analysis: Dict[str, object], current: Dict[str, object]) -> str:
        if analysis.get("should_open"):
            return "ready"

        blocked_reason = safe_str(analysis.get("blocked_reason"))
        price = safe_float(current.get("price"))
        ema20 = safe_float(current.get("ema20"))
        atr = safe_float(current.get("atr"))

        if blocked_reason:
            if blocked_reason.startswith("score<") and price > 0 and ema20 > 0 and atr > 0:
                if abs(price - ema20) <= atr * 0.75:
                    return "near_entry"
            return "blocked"

        return "watch"

    def _build_item(self, symbol: str, market: str, current: Dict[str, object], analysis: Dict[str, object]) -> Dict[str, object]:
        score = safe_int(analysis.get("score"), 0)
        status = self._status_from_analysis(analysis, current)
        blocked_reason = safe_str(analysis.get("blocked_reason"))
        args_text = safe_str(analysis.get("args_text")) or blocked_reason

        return {
            "symbol": safe_str(symbol).upper(),
            "price": round(safe_float(current.get("price")), 8),
            "market": market,
            "score": score,
            "setup_type": safe_str(analysis.get("setup_type"), "-"),
            "args_text": args_text,
            "status": status,
        }

    def build(
        self,
        ta_data: Dict[str, Dict[str, object]],
        fut_pool: List[str],
        spot_pool: List[str],
        macro_filter: str,
    ) -> List[Dict[str, object]]:
        items: List[Dict[str, object]] = []

        for symbol in fut_pool:
            current = ta_data.get(symbol)
            if not current:
                continue

            analysis = self.strategy.analyze_futures(current, macro_filter)
            item = self._build_item(symbol, "fut", current, analysis)

            if (
                item["status"] in {"ready", "near_entry", "blocked"}
                or item["score"] >= CONFIG.trading.watchlist_min_score
            ):
                items.append(item)

        for symbol in spot_pool:
            current = ta_data.get(symbol)
            if not current:
                continue

            analysis = self.strategy.analyze_spot(current, macro_filter)
            item = self._build_item(symbol, "spot", current, analysis)

            if (
                item["status"] in {"ready", "near_entry", "blocked"}
                or item["score"] >= CONFIG.trading.watchlist_min_score
            ):
                items.append(item)

        if not items:
            for symbol in fut_pool:
                current = ta_data.get(symbol)
                if current:
                    items.append({
                        "symbol": safe_str(symbol).upper(),
                        "price": round(safe_float(current.get("price")), 8),
                        "market": "fut",
                        "score": 0,
                        "setup_type": "-",
                        "args_text": "watch fallback",
                        "status": "watch",
                    })

            for symbol in spot_pool:
                current = ta_data.get(symbol)
                if current:
                    items.append({
                        "symbol": safe_str(symbol).upper(),
                        "price": round(safe_float(current.get("price")), 8),
                        "market": "spot",
                        "score": 0,
                        "setup_type": "-",
                        "args_text": "watch fallback",
                        "status": "watch",
                    })

        status_rank = {
            "ready": 4,
            "near_entry": 3,
            "watch": 2,
            "blocked": 1,
        }

        items.sort(
            key=lambda x: (
                status_rank.get(x["status"], 0),
                x["score"],
            ),
            reverse=True,
        )

        return items[:8]