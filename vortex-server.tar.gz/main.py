import asyncio
import time

from api_server import APIServer
from config import CONFIG
from decision_engine import DecisionEngine
from execution_router import ExecutionRouter
from logger import Logger
from loop_runner import create_task
from market_data import MarketDataStream
from market_oracle import MarketOracle
from market_screener import MarketScreener
from planner_data_provider import PlannerDataProvider
from risk_manager import RiskManager
from spot_planner import SpotPlannerEngine
from state_manager import StateManager
from strategy import SwingStrategy
from ta_service import TAService
from trade_manager import TradeManager
from watchlist_builder import WatchlistBuilder
from validators import safe_float, safe_str


async def pool_loop(state, screener, logger=None) -> None:
    next_rotation = time.time()

    while True:
        try:
            now = time.time()

            if now >= next_rotation:
                buckets = await screener.get_market_buckets()
                fut = buckets.get("fut_candidates", [])[: CONFIG.universe.fut_pool_size]
                spot = buckets.get("spot_candidates", [])[: CONFIG.universe.spot_pool_size]

                await state.set_pool("fut", fut)
                await state.set_pool("spot", spot)
                await state.add_sys_log("🧺 [POOL]", f"fut={fut} | spot={spot}")

                if logger:
                    logger.info("POOL", "pool rotated", {"fut": fut, "spot": spot})

                next_rotation = now + CONFIG.loops.pool_rotation_sec

            await state.update_timer(max(0, int(next_rotation - time.time())))
            await asyncio.sleep(1)

        except Exception as exc:
            await state.add_sys_log("❌ [POOL]", str(exc))
            if logger:
                logger.error("POOL", "pool loop failed", {"error": str(exc)})
            await asyncio.sleep(CONFIG.loops.safe_loop_backoff_sec)


async def system_metrics_loop(state, logger=None) -> None:
    started = time.time()

    while True:
        try:
            uptime_sec = int(time.time() - started)
            hh = uptime_sec // 3600
            mm = (uptime_sec % 3600) // 60
            ss = uptime_sec % 60
            uptime = f"{hh:02d}:{mm:02d}:{ss:02d}"

            await state.update_system_metrics(uptime, 0, 0)
            await asyncio.sleep(CONFIG.loops.system_metrics_sec)

        except Exception as exc:
            await state.add_sys_log("❌ [SYS]", str(exc))
            if logger:
                logger.error("SYS", "system metrics loop failed", {"error": str(exc)})
            await asyncio.sleep(CONFIG.loops.safe_loop_backoff_sec)


async def monitor_loop(state, logger=None) -> None:
    while True:
        try:
            dash = await state.get_dashboard_state()
            health = dash.get("market", {}).get("symbol_health", {}) or {}

            for sym, item in health.items():
                if item.get("status") != "OK":
                    await state.add_sys_log("⚠️ [MONITOR]", f"{sym} degraded | {item.get('error', 'unknown')}")
                    if logger:
                        logger.warning("MONITOR", "symbol degraded", {
                            "symbol": sym,
                            "error": item.get("error", "unknown"),
                        })

            await asyncio.sleep(CONFIG.loops.monitor_sec)

        except Exception as exc:
            await state.add_sys_log("❌ [MONITOR]", str(exc))
            if logger:
                logger.error("MONITOR", "monitor loop failed", {"error": str(exc)})
            await asyncio.sleep(CONFIG.loops.safe_loop_backoff_sec)


async def sync_router_loop(state, router, logger=None) -> None:
    while True:
        try:
            await state.sync_router_snapshot(router)
            await asyncio.sleep(CONFIG.loops.router_sync_sec)
        except Exception as exc:
            await state.add_sys_log("❌ [SYNC]", str(exc))
            if logger:
                logger.error("SYNC", "router sync failed", {"error": str(exc)})
            await asyncio.sleep(CONFIG.loops.safe_loop_backoff_sec)


async def planner_market_loop(state, provider, logger=None) -> None:
    while True:
        try:
            snapshot = await provider.build_snapshot()
            await state.update_planner_market_data(snapshot)
            count = len(snapshot.get("symbols", {}))
            await state.add_sys_log("🧠 [PLANNER]", f"market snapshot updated | symbols={count}")

            if logger:
                logger.info("PLANNER", "planner market snapshot updated", {"symbols": count})

        except Exception as exc:
            await state.add_sys_log("❌ [PLANNER]", f"market loop error | {exc}")
            if logger:
                logger.error("PLANNER", "planner market loop failed", {"error": str(exc)})

        await asyncio.sleep(CONFIG.loops.planner_market_sec)


async def planner_loop(state, planner_engine, logger=None) -> None:
    while True:
        try:
            dashboard = await state.get_dashboard_state()
            planner_market_data = dashboard.get("planner", {}).get("market_data", {})
            macro = dashboard.get("system", {}).get("macro", {})

            if not planner_market_data:
                await state.add_sys_log("⏳ [PLANNER]", "market data empty, waiting for snapshot")
                await asyncio.sleep(10)
                continue

            planner_payload = planner_engine.build(
                planner_market_data=planner_market_data,
                macro=macro,
            )
            await state.update_spot_planner(planner_payload)

            count = len(planner_payload.get("ideas", []))
            await state.add_sys_log("📘 [PLANNER]", f"ideas updated | count={count}")

            if logger:
                logger.info("PLANNER", "planner ideas updated", {"count": count})

        except Exception as exc:
            await state.add_sys_log("❌ [PLANNER]", f"planner loop error | {exc}")
            if logger:
                logger.error("PLANNER", "planner loop failed", {"error": str(exc)})

        await asyncio.sleep(CONFIG.loops.planner_sec)


async def watchlist_loop(state, watchlist_builder, logger=None) -> None:
    while True:
        try:
            dash = await state.get_dashboard_state()
            ta_data = dash.get("market", {}).get("ta_data", {})
            fut_pool = dash.get("system", {}).get("fut_pool", [])
            spot_pool = dash.get("system", {}).get("spot_pool", [])
            macro_filter = dash.get("system", {}).get("macro", {}).get("global_filter", "allow_all")

            items = watchlist_builder.build(
                ta_data=ta_data,
                fut_pool=fut_pool,
                spot_pool=spot_pool,
                macro_filter=macro_filter,
            )

            await state.set_watchlist_mini(items)

            if logger:
                logger.info("WATCHLIST", "watchlist updated", {"count": len(items)})

        except Exception as exc:
            await state.add_sys_log("❌ [WATCHLIST]", str(exc))
            if logger:
                logger.error("WATCHLIST", "watchlist loop failed", {"error": str(exc)})

        await asyncio.sleep(CONFIG.loops.watchlist_sec)


async def strategy_loop(state, router, strategy, decision_engine, trade_logger, risk_manager, logger=None) -> None:
    while True:
        try:
            dash = await state.get_dashboard_state()

            ta_data = dash.get("market", {}).get("ta_data", {})
            fut_pool = dash.get("system", {}).get("fut_pool", [])
            spot_pool = dash.get("system", {}).get("spot_pool", [])
            macro_filter = dash.get("system", {}).get("macro", {}).get("global_filter", "allow_all")

            risk_status = risk_manager.get_status()
            if risk_status["block_new_entries"]:
                msg = (
                    f"daily stop active | "
                    f"day={risk_status['daily_realized_pnl']:.4f} / "
                    f"limit={risk_status['daily_loss_limit_usdt']:.4f}"
                )
                await state.add_sys_log("🛑 [RISK]", msg)
                if logger:
                    logger.warning("RISK", "daily stop active", {
                        "daily_realized_pnl": risk_status["daily_realized_pnl"],
                        "daily_loss_limit_usdt": risk_status["daily_loss_limit_usdt"],
                    })
                await asyncio.sleep(CONFIG.loops.strategy_sec)
                continue

            current_fut_open_count = 1 if router.get_futures_position() is not None else 0
            current_spot_open_count = len(router.get_all_spot_positions())

            if current_fut_open_count == 0:
                for sym in fut_pool:
                    current = ta_data.get(sym)
                    if not current:
                        continue

                    analysis = strategy.analyze_futures(current, macro_filter)
                    decision = decision_engine.evaluate(
                        symbol=sym,
                        market="fut",
                        analysis=analysis,
                        risk_manager=risk_manager,
                        current_open_count=current_fut_open_count,
                        max_open_positions=risk_status["max_open_futures_positions"],
                    )

                    if not decision["allow"]:
                        await state.add_sys_log("⚠️ [RISK]", f"{sym} blocked | {decision['reason']}")
                        if logger:
                            logger.info("STRATEGY", "futures blocked", {
                                "symbol": sym,
                                "reason": decision["reason"],
                                "score": analysis.get("score"),
                                "setup_type": analysis.get("setup_type"),
                                "signal": analysis.get("signal"),
                            })
                        continue

                    price = safe_float(current.get("price"), 0.0)
                    atr_abs = safe_float(current.get("atr"), 0.0)
                    side = safe_str(analysis.get("signal"))

                    if price <= 0 or atr_abs <= 0 or side not in {"LONG", "SHORT"}:
                        if logger:
                            logger.warning("STRATEGY", "invalid futures trade params", {
                                "symbol": sym,
                                "price": price,
                                "atr": atr_abs,
                                "side": side,
                            })
                        continue

                    ladder = strategy.calculate_futures_trade(
                        price=price,
                        side=side,
                        atr=atr_abs,
                        setup_type=analysis.get("setup_type"),
                    )

                    qty = CONFIG.trading.futures_margin_usdt / price

                    result = router.open_futures_position(
                        symbol=sym,
                        side=side,
                        qty=qty,
                        price=price,
                        tp=ladder["tp"],
                        sl=ladder["sl"],
                        atr=atr_abs,
                        leverage=ladder["leverage"],
                        setup_type=safe_str(analysis.get("setup_type")),
                        args_text=safe_str(analysis.get("args_text")),
                    )

                    if result.get("code") == "00000":
                        risk_manager.register_open(sym, "fut")
                        open_msg = f"{sym} {side} {analysis['setup_type']} @ {price:.8f} | {analysis['args_text']}"
                        await state.add_sys_log("🟢 [FUT OPEN]", open_msg)
                        if logger:
                            logger.info("STRATEGY", "futures opened", {
                                "symbol": sym,
                                "side": side,
                                "setup_type": analysis.get("setup_type"),
                                "price": price,
                                "score": analysis.get("score"),
                                "tp": ladder["tp"],
                                "sl": ladder["sl"],
                            })
                        trade_logger.log_trade(
                            symbol=sym,
                            side=side,
                            trade_type="FUT",
                            entry_price=result["data"]["entry"],
                            target_tp=ladder["tp"],
                            status="OPEN",
                            setup_type=safe_str(analysis.get("setup_type")),
                            args_text=safe_str(analysis.get("args_text")),
                        )
                        break
                    else:
                        if logger:
                            logger.warning("STRATEGY", "futures open rejected", {
                                "symbol": sym,
                                "result": result,
                            })

            if current_spot_open_count < risk_status["max_open_spot_positions"]:
                for sym in spot_pool:
                    if router.get_spot_position(sym) is not None:
                        continue

                    current = ta_data.get(sym)
                    if not current:
                        continue

                    analysis = strategy.analyze_spot(current, macro_filter)
                    decision = decision_engine.evaluate(
                        symbol=sym,
                        market="spot",
                        analysis=analysis,
                        risk_manager=risk_manager,
                        current_open_count=current_spot_open_count,
                        max_open_positions=risk_status["max_open_spot_positions"],
                    )

                    if not decision["allow"]:
                        await state.add_sys_log("⚠️ [RISK]", f"{sym} blocked | {decision['reason']}")
                        if logger:
                            logger.info("STRATEGY", "spot blocked", {
                                "symbol": sym,
                                "reason": decision["reason"],
                                "score": analysis.get("score"),
                                "setup_type": analysis.get("setup_type"),
                                "signal": analysis.get("signal"),
                            })
                        continue

                    price = safe_float(current.get("price"), 0.0)
                    atr_abs = safe_float(current.get("atr"), 0.0)
                    if price <= 0 or atr_abs <= 0:
                        if logger:
                            logger.warning("STRATEGY", "invalid spot trade params", {
                                "symbol": sym,
                                "price": price,
                                "atr": atr_abs,
                            })
                        continue

                    ladder = strategy.calculate_spot_ladder(
                        price=price,
                        setup_type=analysis.get("setup_type"),
                    )

                    qty = CONFIG.trading.spot_order_usdt / price

                    result = router.open_spot_position(
                        symbol=sym,
                        qty=qty,
                        price=price,
                        tp=ladder["tp"],
                        atr=atr_abs,
                        setup_type=safe_str(analysis.get("setup_type")),
                        args_text=safe_str(analysis.get("args_text")),
                    )

                    if result.get("code") == "00000":
                        risk_manager.register_open(sym, "spot")
                        open_msg = f"{sym} BUY {analysis['setup_type']} @ {price:.8f} | {analysis['args_text']}"
                        await state.add_sys_log("🟢 [SPOT OPEN]", open_msg)
                        if logger:
                            logger.info("STRATEGY", "spot opened", {
                                "symbol": sym,
                                "setup_type": analysis.get("setup_type"),
                                "price": price,
                                "score": analysis.get("score"),
                                "tp": ladder["tp"],
                            })
                        trade_logger.log_trade(
                            symbol=sym,
                            side="BUY",
                            trade_type="SPOT",
                            entry_price=result["data"]["entry"],
                            target_tp=ladder["tp"],
                            status="OPEN",
                            setup_type=safe_str(analysis.get("setup_type")),
                            args_text=safe_str(analysis.get("args_text")),
                        )
                        break
                    else:
                        if logger:
                            logger.warning("STRATEGY", "spot open rejected", {
                                "symbol": sym,
                                "result": result,
                            })

        except Exception as exc:
            await state.add_sys_log("❌ [STRATEGY]", str(exc))
            if logger:
                logger.error("STRATEGY", "strategy loop failed", {"error": str(exc)})

        await asyncio.sleep(CONFIG.loops.strategy_sec)


async def trade_manager_loop(state, router, trade_manager, trade_logger, risk_manager, logger=None) -> None:
    while True:
        try:
            await trade_manager.loop(
                state=state,
                router=router,
                trade_logger=trade_logger,
                risk_manager=risk_manager,
            )
        except Exception as exc:
            await state.add_sys_log("❌ [TRADE_MANAGER]", str(exc))
            if logger:
                logger.error("TRADE_MANAGER", "trade manager loop failed", {"error": str(exc)})

        await asyncio.sleep(CONFIG.loops.execution_sec)


async def main() -> None:
    logger = Logger()

    logger.info("BOOT", "starting VORTEX core", {})

    state = StateManager()
    await state.set_mode(CONFIG.trading.mode)

    screener = MarketScreener(logger=logger)
    data = MarketDataStream(state, logger=logger)
    oracle = MarketOracle(state, logger=logger)
    ta_service = TAService(state, logger=logger)

    strategy = SwingStrategy()
    decision_engine = DecisionEngine(logger=logger)
    watchlist_builder = WatchlistBuilder(strategy=strategy, logger=logger)

    risk_manager = RiskManager()
    router = ExecutionRouter(mode=CONFIG.trading.mode)
    trade_manager = TradeManager(logger=logger)

    planner_provider = PlannerDataProvider(logger=logger)
    planner_engine = SpotPlannerEngine(logger=logger)

    api = APIServer(
        state_manager=state,
        execution_router=router,
        risk_manager=risk_manager,
        logger=logger,
        mode=CONFIG.trading.mode,
    )

    logger.info("BOOT", "all services initialized", {})

    tasks = [
        create_task(data.loop(), name="market_data"),
        create_task(pool_loop(state, screener, logger=logger), name="pool"),
        create_task(oracle.loop(), name="oracle"),
        create_task(ta_service.loop(), name="ta"),
        create_task(system_metrics_loop(state, logger=logger), name="system_metrics"),
        create_task(monitor_loop(state, logger=logger), name="monitor"),
        create_task(sync_router_loop(state, router, logger=logger), name="router_sync"),
        create_task(planner_market_loop(state, planner_provider, logger=logger), name="planner_market"),
        create_task(planner_loop(state, planner_engine, logger=logger), name="planner"),
        create_task(watchlist_loop(state, watchlist_builder, logger=logger), name="watchlist"),
        create_task(
            strategy_loop(
                state=state,
                router=router,
                strategy=strategy,
                decision_engine=decision_engine,
                trade_logger=logger,
                risk_manager=risk_manager,
                logger=logger,
            ),
            name="strategy",
        ),
        create_task(
            trade_manager_loop(
                state=state,
                router=router,
                trade_manager=trade_manager,
                trade_logger=logger,
                risk_manager=risk_manager,
                logger=logger,
            ),
            name="trade_manager",
        ),
        create_task(api.start(port=CONFIG.server.port), name="api"),
    ]

    try:
        await asyncio.gather(*tasks)
    except asyncio.CancelledError:
        logger.warning("BOOT", "main cancelled", {})
        raise
    except Exception as exc:
        logger.error("BOOT", "fatal main error", {"error": str(exc)})
        raise


if __name__ == "__main__":
    asyncio.run(main())