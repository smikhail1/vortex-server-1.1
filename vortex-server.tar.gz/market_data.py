import asyncio
import time
from typing import Any, Dict, List, Optional, Set, Tuple

import aiohttp

from config import CONFIG
from validators import normalize_symbol, safe_float, safe_str


class MarketDataStream:
    """
    Отвечает только за market data:
    - futures ticker
    - spot bulk ticker
    - retry/timeout/fail counters
    - symbol health
    - quarantine

    Не занимается:
    - strategy
    - planner
    - watchlist
    - execution
    """

    def __init__(self, state, logger=None) -> None:
        self.state = state
        self.logger = logger
        self.fail_counts: Dict[Tuple[str, str], int] = {}
        self.quarantine: Set[Tuple[str, str]] = set()
        self.timeout = aiohttp.ClientTimeout(total=10)

    async def fetch_futures(self, session: aiohttp.ClientSession, symbol: str) -> None:
        sym = normalize_symbol(symbol)
        if not sym:
            return

        try:
            url = "https://api.bitget.com/api/v2/mix/market/ticker"
            params = {
                "symbol": sym,
                "productType": "USDT-FUTURES",
            }

            async with session.get(url, params=params) as resp:
                data = await resp.json(content_type=None)

            if data.get("code") != "00000":
                raise RuntimeError(f"bad code {data.get('code')}")

            items = data.get("data", [])
            if not items:
                raise RuntimeError("empty futures data")

            last_price = safe_float(items[0].get("lastPr"), 0.0)
            if last_price <= 0:
                raise RuntimeError("invalid futures price")

            ts = time.time()
            await self.state.update_market_price(sym, last_price, ts)
            await self.state.set_symbol_health(sym, {
                "status": "OK",
                "market_type": "fut",
                "last_update": ts,
                "fails": 0,
                "error": "",
            })

            self.fail_counts[("fut", sym)] = 0
            if ("fut", sym) in self.quarantine:
                self.quarantine.remove(("fut", sym))

        except Exception as exc:
            key = ("fut", sym)
            self.fail_counts[key] = self.fail_counts.get(key, 0) + 1
            if self.fail_counts[key] >= 10:
                self.quarantine.add(key)

            await self.state.set_symbol_health(sym, {
                "status": "FAIL",
                "market_type": "fut",
                "error": str(exc),
                "fails": self.fail_counts[key],
                "last_update": time.time(),
            })
            await self.state.add_sys_log("❌ [DATA]", f"fut:{sym} {exc}")

            if self.logger:
                self.logger.error("MARKET_DATA", f"futures {sym} failed", {
                    "symbol": sym,
                    "market": "fut",
                    "fails": self.fail_counts[key],
                    "error": str(exc),
                    "quarantined": key in self.quarantine,
                })

    async def fetch_spot_all(self, session: aiohttp.ClientSession) -> Tuple[Dict[str, float], float]:
        try:
            url = "https://api.bitget.com/api/v2/spot/market/tickers"
            async with session.get(url) as resp:
                data = await resp.json(content_type=None)

            if data.get("code") != "00000":
                raise RuntimeError(f"bad code {data.get('code')}")

            items = data.get("data", [])
            if not items:
                raise RuntimeError("empty spot data")

            mapping: Dict[str, float] = {}
            for item in items:
                symbol = normalize_symbol(item.get("symbol"))
                last_price = safe_float(item.get("lastPr"), 0.0)
                if symbol and last_price > 0:
                    mapping[symbol] = last_price

            return mapping, time.time()

        except Exception as exc:
            await self.state.add_sys_log("❌ [DATA]", f"spot:bulk {exc}")
            if self.logger:
                self.logger.error("MARKET_DATA", "spot bulk failed", {"error": str(exc)})
            return {}, time.time()

    async def apply_spot_prices(self, symbols: List[str], mapping: Dict[str, float], ts: float) -> None:
        for symbol in symbols:
            sym = normalize_symbol(symbol)
            if not sym:
                continue

            try:
                if sym not in mapping:
                    raise RuntimeError("symbol not found in bulk spot mapping")

                price = safe_float(mapping.get(sym), 0.0)
                if price <= 0:
                    raise RuntimeError("invalid spot price")

                await self.state.update_market_price(sym, price, ts)
                await self.state.set_symbol_health(sym, {
                    "status": "OK",
                    "market_type": "spot",
                    "last_update": ts,
                    "fails": 0,
                    "error": "",
                })

                self.fail_counts[("spot", sym)] = 0
                if ("spot", sym) in self.quarantine:
                    self.quarantine.remove(("spot", sym))

            except Exception as exc:
                key = ("spot", sym)
                self.fail_counts[key] = self.fail_counts.get(key, 0) + 1
                if self.fail_counts[key] >= 10:
                    self.quarantine.add(key)

                await self.state.set_symbol_health(sym, {
                    "status": "FAIL",
                    "market_type": "spot",
                    "error": str(exc),
                    "fails": self.fail_counts[key],
                    "last_update": time.time(),
                })
                await self.state.add_sys_log("❌ [DATA]", f"spot:{sym} {exc}")

                if self.logger:
                    self.logger.error("MARKET_DATA", f"spot {sym} failed", {
                        "symbol": sym,
                        "market": "spot",
                        "fails": self.fail_counts[key],
                        "error": str(exc),
                        "quarantined": key in self.quarantine,
                    })

    async def loop(self) -> None:
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            while True:
                fut_pool = await self.state.get_pool("fut")
                spot_pool = await self.state.get_pool("spot")

                fut_tasks = []
                for symbol in fut_pool:
                    sym = normalize_symbol(symbol)
                    if sym and ("fut", sym) not in self.quarantine:
                        fut_tasks.append(self.fetch_futures(session, sym))

                if fut_tasks:
                    await asyncio.gather(*fut_tasks, return_exceptions=True)

                spot_mapping, ts = await self.fetch_spot_all(session)
                await self.apply_spot_prices(spot_pool, spot_mapping, ts)

                await asyncio.sleep(CONFIG.loops.market_data_sec)