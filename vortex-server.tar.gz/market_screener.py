import time
from typing import Dict, List, Tuple

import aiohttp

from config import CONFIG
from validators import (
    is_ascii_asset_code,
    is_leveraged_or_service_asset,
    is_tradable_universe_symbol,
    normalize_symbol,
    safe_float,
    split_usdt_symbol,
)


class MarketScreener:
    """
    Dynamic universe scanner.

    Улучшения блока 1.1:
    - ASCII-only base assets
    - фильтр новых stable/synthetic/service assets
    - исключение мусорных / мемных / нецелевых тикеров
    - quality-first universe
    """

    def __init__(self, fallback_symbols: List[str] | None = None, logger=None) -> None:
        self.logger = logger
        self.fallback_symbols = fallback_symbols or list(CONFIG.universe.fallback_symbols)

        self.last_source = "init"
        self.last_debug = "init"
        self.last_refresh_ts = 0.0

        self.cache_all: List[str] = []
        self.cache_meta: Dict[str, Dict[str, float]] = {}

    async def _fetch_binance_24h(self) -> List[dict]:
        timeout = aiohttp.ClientTimeout(total=8)
        url = "https://api.binance.com/api/v3/ticker/24hr"

        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    raise RuntimeError(f"binance status {resp.status}")

                data = await resp.json(content_type=None)
                if not isinstance(data, list):
                    raise RuntimeError("unexpected 24hr payload")

                return data

    def _extra_universe_filters(self, symbol: str, item: dict) -> bool:
        base, quote = split_usdt_symbol(symbol)
        if quote != "USDT":
            return False

        if not is_ascii_asset_code(base):
            return False

        if is_leveraged_or_service_asset(base):
            return False

        # дополнительные явные исключения
        excluded = {
            "USD1", "USDK", "USDX", "USDM", "USDL", "USDQ",
            "PYUSD", "USDE", "USDD", "FRAX", "MIM",
            "XAUT", "PAXG",
            "BARD",
        }
        if base in excluded:
            return False

        last_price = safe_float(item.get("lastPrice"), 0.0)
        quote_volume = safe_float(item.get("quoteVolume"), 0.0)
        count = safe_float(item.get("count"), 0.0)

        if last_price < CONFIG.universe.min_last_price or last_price > CONFIG.universe.max_last_price:
            return False

        if quote_volume < CONFIG.universe.min_quote_volume_usdt:
            return False

        if count < 1000:
            return False

        # исключаем сверх-дёрганый мусор для базового universe
        abs_change = abs(safe_float(item.get("priceChangePercent"), 0.0))
        if abs_change > 80:
            return False

        return True

    def _rank_key(self, row: dict) -> Tuple[float, float, float]:
        quote_volume = safe_float(row.get("quoteVolume"), 0.0)
        count = safe_float(row.get("count"), 0.0)
        abs_change = abs(safe_float(row.get("priceChangePercent"), 0.0))
        return (
            quote_volume,
            count,
            -abs_change,  # меньше аномальный памп => лучше
        )

    def _build_universe(self, raw_rows: List[dict]) -> List[str]:
        filtered: List[dict] = []

        for item in raw_rows:
            if not isinstance(item, dict):
                continue

            symbol = normalize_symbol(item.get("symbol"))
            if not is_tradable_universe_symbol(symbol):
                continue

            if not self._extra_universe_filters(symbol, item):
                continue

            filtered.append(item)

        filtered.sort(key=self._rank_key, reverse=True)

        universe = []
        seen = set()

        for item in filtered:
            symbol = normalize_symbol(item.get("symbol"))
            if not symbol or symbol in seen:
                continue
            universe.append(symbol)
            seen.add(symbol)
            if len(universe) >= CONFIG.universe.top_n:
                break

        return universe

    def _build_meta_cache(self, raw_rows: List[dict], selected: List[str]) -> Dict[str, Dict[str, float]]:
        selected_set = set(selected)
        meta: Dict[str, Dict[str, float]] = {}

        for item in raw_rows:
            symbol = normalize_symbol(item.get("symbol"))
            if symbol not in selected_set:
                continue

            meta[symbol] = {
                "last_price": safe_float(item.get("lastPrice"), 0.0),
                "quote_volume": safe_float(item.get("quoteVolume"), 0.0),
                "count": safe_float(item.get("count"), 0.0),
                "price_change_pct": safe_float(item.get("priceChangePercent"), 0.0),
            }

        return meta

    def _fallback_universe(self, limit: int) -> List[str]:
        clean = []
        seen = set()

        for symbol in self.fallback_symbols:
            sym = normalize_symbol(symbol)
            if not sym or sym in seen:
                continue
            if not is_tradable_universe_symbol(sym):
                continue

            base, _ = split_usdt_symbol(sym)
            if not is_ascii_asset_code(base):
                continue

            clean.append(sym)
            seen.add(sym)
            if len(clean) >= limit:
                break

        return clean

    async def refresh(self) -> List[str]:
        try:
            raw_rows = await self._fetch_binance_24h()
            universe = self._build_universe(raw_rows)

            if not universe:
                raise RuntimeError("empty universe after filtering")

            self.cache_all = universe
            self.cache_meta = self._build_meta_cache(raw_rows, universe)
            self.last_source = "remote"
            self.last_debug = f"remote-ok:{len(universe)}"
            self.last_refresh_ts = time.time()

            if self.logger:
                self.logger.info(
                    "SCREENER",
                    "universe refreshed",
                    {
                        "source": self.last_source,
                        "size": len(universe),
                        "top10": universe[:10],
                    },
                )

            return list(self.cache_all)

        except Exception as exc:
            self.last_source = "fallback"
            self.last_debug = f"fallback:{exc}"
            self.last_refresh_ts = time.time()

            fallback = self._fallback_universe(limit=CONFIG.universe.top_n)
            self.cache_all = fallback
            self.cache_meta = {
                sym: {
                    "last_price": 0.0,
                    "quote_volume": 0.0,
                    "count": 0.0,
                    "price_change_pct": 0.0,
                }
                for sym in fallback
            }

            if self.logger:
                self.logger.warning(
                    "SCREENER",
                    "fallback universe used",
                    {
                        "error": str(exc),
                        "size": len(fallback),
                        "top10": fallback[:10],
                    },
                )

            return list(self.cache_all)

    async def get_ranked_universe(self) -> List[str]:
        if not self.cache_all:
            return await self.refresh()
        return list(self.cache_all)

    async def get_top_symbols(self, limit: int = 10) -> List[str]:
        limit = max(1, int(limit))
        universe = await self.get_ranked_universe()
        return universe[:limit]

    async def get_market_buckets(self) -> Dict[str, List[str]]:
        universe = await self.get_ranked_universe()

        fut = universe[: CONFIG.universe.fut_pool_size]
        spot = universe[: CONFIG.universe.spot_pool_size]

        return {
            "universe_all": universe,
            "fut_candidates": fut,
            "spot_candidates": spot,
        }

    async def get_debug_info(self) -> Dict[str, object]:
        return {
            "is_ready": bool(self.cache_all),
            "cache_size": len(self.cache_all),
            "last_source": self.last_source,
            "last_debug": self.last_debug,
            "last_refresh_ts": self.last_refresh_ts,
            "top10": list(self.cache_all[:10]),
            "top10_meta": {sym: self.cache_meta.get(sym, {}) for sym in self.cache_all[:10]},
        }