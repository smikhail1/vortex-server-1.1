from strategy import SwingStrategy


def assert_true(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def build_small_edge_ctx() -> dict:
    return {
        "price": 100.0,
        "atr": 0.1,
        "ema20": 100.0,
        "ema50": 99.8,
        "rsi_main": 56.0,
        "vol_ratio": 1.2,
        "trend_4h": "strong_up",
        "trend_bias_30m": "up",
        "market_regime": "trend",
        "breakout": False,
        "breakout_dir": "",
        "near_support": True,
        "near_resistance": False,
        "pullback_long_ready": True,
        "pullback_short_ready": False,
        "retest_long_ready": False,
        "retest_short_ready": False,
        "vol_confirmed": True,
        "breakout_volume_confirmed": True,
        "recent_high": 102.0,
        "recent_low": 99.0,
    }


def build_good_edge_ctx() -> dict:
    return {
        "price": 100.0,
        "atr": 3.0,
        "ema20": 100.0,
        "ema50": 99.4,
        "rsi_main": 57.0,
        "vol_ratio": 1.3,
        "trend_4h": "strong_up",
        "trend_bias_30m": "up",
        "market_regime": "trend",
        "breakout": False,
        "breakout_dir": "",
        "near_support": True,
        "near_resistance": False,
        "pullback_long_ready": True,
        "pullback_short_ready": False,
        "retest_long_ready": False,
        "retest_short_ready": False,
        "vol_confirmed": True,
        "breakout_volume_confirmed": True,
        "recent_high": 105.0,
        "recent_low": 98.0,
    }


def scenario_fee_guard_blocks_small_futures() -> None:
    s = SwingStrategy()
    data = build_small_edge_ctx()
    data["trend_4h"] = "strong_down"
    data["trend_bias_30m"] = "down"
    data["near_support"] = False
    data["near_resistance"] = True
    data["pullback_long_ready"] = False
    data["pullback_short_ready"] = True
    data["recent_low"] = 98.0
    data["recent_high"] = 101.0
    data["ema20"] = 100.0
    data["ema50"] = 100.2

    result = s.analyze_futures(data, "allow_all")
    assert_true(result["should_open"] is False, "small futures edge must be blocked")
    assert_true("fee_guard fut" in (result["blocked_reason"] or ""), f"fee guard reason expected, got: {result}")
    print("OK: scenario_fee_guard_blocks_small_futures")


def scenario_fee_guard_allows_good_futures() -> None:
    s = SwingStrategy()
    data = build_good_edge_ctx()
    data["trend_4h"] = "strong_down"
    data["trend_bias_30m"] = "down"
    data["near_support"] = False
    data["near_resistance"] = True
    data["pullback_long_ready"] = False
    data["pullback_short_ready"] = True
    data["recent_low"] = 95.0
    data["recent_high"] = 103.0
    data["ema20"] = 100.0
    data["ema50"] = 100.4

    result = s.analyze_futures(data, "allow_all")
    assert_true(result["signal"] == "SHORT", f"short futures signal expected, got: {result}")
    assert_true("fee_guard fut" not in (result["blocked_reason"] or ""), f"fee guard should pass, got: {result}")
    print("OK: scenario_fee_guard_allows_good_futures")


def scenario_spot_default_tp_is_large_enough() -> None:
    s = SwingStrategy()
    data = build_small_edge_ctx()

    result = s.analyze_spot(data, "allow_all")
    assert_true(result["signal"] == "BUY", f"spot BUY expected, got: {result}")
    assert_true(
        "fee_guard spot" not in (result["blocked_reason"] or ""),
        f"spot fee guard should pass with default 2.8% TP, got: {result}",
    )
    print("OK: scenario_spot_default_tp_is_large_enough")


def scenario_fee_guard_allows_good_spot() -> None:
    s = SwingStrategy()
    data = build_good_edge_ctx()

    result = s.analyze_spot(data, "allow_all")
    assert_true(result["signal"] == "BUY", f"spot BUY expected, got: {result}")
    assert_true("fee_guard spot" not in (result["blocked_reason"] or ""), f"spot fee guard should pass, got: {result}")
    print("OK: scenario_fee_guard_allows_good_spot")


def run_all() -> None:
    scenario_fee_guard_blocks_small_futures()
    scenario_fee_guard_allows_good_futures()
    scenario_spot_default_tp_is_large_enough()
    scenario_fee_guard_allows_good_spot()
    print("ALL FEE GUARD TESTS PASSED")


if __name__ == "__main__":
    run_all()