import time
from dataclasses import dataclass


@dataclass
class FuturesPosition:
    symbol: str
    side: str
    qty: float
    entry: float
    mark_price: float
    tp: float
    tp2: float
    sl: float
    atr: float
    leverage: float
    margin: float
    notional: float
    fee_open: float
    fee_close_est: float
    open_time: float

    pnl: float = 0.0
    pnl_net: float = 0.0
    breakeven: bool = False
    tp1_hit: bool = False
    trail_sl: float = 0.0
    liq_price: float = 0.0
    max_pnl_net: float = 0.0
    tp1_time: float = 0.0

    setup_type: str = ""
    args_text: str = ""


class PaperFutures:
    """
    Реалистичный paper futures engine:
    - комиссия
    - spread
    - slippage
    - margin
    - liquidation
    - история сделок
    - timeout / fade / stall exits
    """

    def __init__(
        self,
        start_balance: float = 100.0,
        taker_fee: float = 0.0006,
        maker_fee: float = 0.0002,
        spread_bps: float = 4.0,
        slippage_bps: float = 2.0,
        maintenance_margin_rate: float = 0.005,
        profit_timeout_sec: int = 600,
        tp1_stall_sec: int = 420,
        min_timeout_profit_usdt: float = 0.20,
        fade_giveback_pct: float = 0.65,
    ):
        self.balance = float(start_balance)
        self.pos = None
        self.history = []

        self.taker_fee = float(taker_fee)
        self.maker_fee = float(maker_fee)
        self.spread_bps = float(spread_bps)
        self.slippage_bps = float(slippage_bps)
        self.maintenance_margin_rate = float(maintenance_margin_rate)

        self.profit_timeout_sec = int(profit_timeout_sec)
        self.tp1_stall_sec = int(tp1_stall_sec)
        self.min_timeout_profit_usdt = float(min_timeout_profit_usdt)
        self.fade_giveback_pct = float(fade_giveback_pct)

    def get_balance(self):
        return round(self.balance, 8)

    def get_position(self):
        return self.pos

    def get_trade_history(self):
        return list(self.history)

    def _normalize_side(self, side: str) -> str:
        s = str(side).lower()
        if s in ("long", "buy"):
            return "long"
        if s in ("short", "sell"):
            return "short"
        return s

    def _half_spread_pct(self) -> float:
        return (self.spread_bps / 10000.0) / 2.0

    def _slippage_pct(self) -> float:
        return self.slippage_bps / 10000.0

    def _entry_fill_price(self, ref_price: float, side: str) -> float:
        side = self._normalize_side(side)
        hp = self._half_spread_pct()
        sp = self._slippage_pct()

        if side == "long":
            return ref_price * (1.0 + hp + sp)
        return ref_price * (1.0 - hp - sp)

    def _exit_fill_price(self, ref_price: float, side: str) -> float:
        side = self._normalize_side(side)
        hp = self._half_spread_pct()
        sp = self._slippage_pct()

        if side == "long":
            return ref_price * (1.0 - hp - sp)
        return ref_price * (1.0 + hp + sp)

    def _calc_liq_price(self, entry: float, side: str, leverage: float) -> float:
        mmr = self.maintenance_margin_rate
        if leverage <= 0:
            leverage = 1.0

        if self._normalize_side(side) == "long":
            liq = entry * (1.0 - (1.0 / leverage) + mmr)
        else:
            liq = entry * (1.0 + (1.0 / leverage) - mmr)

        return max(liq, 0.0)

    def open_position(
        self,
        symbol: str,
        side: str,
        qty: float,
        price: float,
        tp: float,
        sl: float,
        atr: float,
        leverage: float = 3.0,
        use_maker: bool = False,
        setup_type: str = "",
        args_text: str = "",
    ):
        if self.pos is not None:
            return {"code": "ERROR", "msg": "Position already open"}

        if qty <= 0 or price <= 0 or leverage <= 0:
            return {"code": "ERROR", "msg": "Invalid qty/price/leverage"}

        side_norm = self._normalize_side(side)
        fill_price = self._entry_fill_price(price, side_norm)

        notional = qty * fill_price
        margin = notional / leverage
        fee_rate = self.maker_fee if use_maker else self.taker_fee
        fee_open = notional * fee_rate

        required = margin + fee_open
        if self.balance < required:
            return {"code": "ERROR", "msg": "Insufficient paper balance"}

        self.balance -= required

        tp2 = fill_price + atr * 5 if side_norm == "long" else fill_price - atr * 5
        trail_sl = sl
        liq_price = self._calc_liq_price(fill_price, side_norm, leverage)
        fee_close_est = notional * fee_rate

        self.pos = FuturesPosition(
            symbol=symbol,
            side=side_norm,
            qty=qty,
            entry=round(fill_price, 8),
            mark_price=round(fill_price, 8),
            tp=round(tp, 8),
            tp2=round(tp2, 8),
            sl=round(sl, 8),
            atr=round(float(atr), 8),
            leverage=float(leverage),
            margin=round(margin, 8),
            notional=round(notional, 8),
            fee_open=round(fee_open, 8),
            fee_close_est=round(fee_close_est, 8),
            open_time=time.time(),
            trail_sl=round(trail_sl, 8),
            liq_price=round(liq_price, 8),
            max_pnl_net=0.0,
            tp1_time=0.0,
            setup_type=str(setup_type or ""),
            args_text=str(args_text or ""),
        )

        return {
            "code": "00000",
            "data": {
                "symbol": symbol,
                "side": side_norm.upper(),
                "qty": round(qty, 8),
                "entry": self.pos.entry,
                "mark_price": self.pos.mark_price,
                "tp1": self.pos.tp,
                "tp2": self.pos.tp2,
                "sl": self.pos.sl,
                "trail_sl": self.pos.trail_sl,
                "liq_price": self.pos.liq_price,
                "pnl": self.pos.pnl,
                "pnl_net": self.pos.pnl_net,
                "tp1_hit": self.pos.tp1_hit,
                "breakeven": self.pos.breakeven,
                "setup_type": self.pos.setup_type,
                "args_text": self.pos.args_text,
            },
        }

    def _update_unrealized(self, current_price: float):
        if not self.pos:
            return

        p = self.pos
        p.mark_price = float(current_price)

        if p.side == "long":
            gross = (current_price - p.entry) * p.qty
        else:
            gross = (p.entry - current_price) * p.qty

        exit_notional_est = abs(current_price * p.qty)
        fee_close_est = exit_notional_est * self.taker_fee

        p.pnl = round(gross, 8)
        p.fee_close_est = round(fee_close_est, 8)
        p.pnl_net = round(gross - p.fee_open - fee_close_est, 8)

        if p.pnl_net > p.max_pnl_net:
            p.max_pnl_net = p.pnl_net

    def check_stops(self, current_price: float):
        if not self.pos:
            return None

        p = self.pos
        self._update_unrealized(current_price)
        now = time.time()

        # 1. Ликвидация
        if p.side == "long" and current_price <= p.liq_price:
            return self.close_position(current_price, reason="LIQ")
        if p.side == "short" and current_price >= p.liq_price:
            return self.close_position(current_price, reason="LIQ")

        # 2. TP1 -> перевод в BE
        if not p.breakeven and not p.tp1_hit:
            if p.side == "long" and current_price >= p.tp:
                p.breakeven = True
                p.tp1_hit = True
                p.tp1_time = now
                p.sl = p.entry
            elif p.side == "short" and current_price <= p.tp:
                p.breakeven = True
                p.tp1_hit = True
                p.tp1_time = now
                p.sl = p.entry

        # 3. Трейлинг после TP1
        if p.tp1_hit:
            if p.side == "long":
                new_trail = current_price - p.atr * 1.5
                if new_trail > p.trail_sl:
                    p.trail_sl = new_trail
                    p.sl = p.trail_sl
            else:
                new_trail = current_price + p.atr * 1.5
                if new_trail < p.trail_sl:
                    p.trail_sl = new_trail
                    p.sl = p.trail_sl

        # 4. Profit Timeout: позиция в плюсе, но тухнет слишком долго до TP1
        if (
            not p.tp1_hit
            and (now - p.open_time) >= self.profit_timeout_sec
            and p.pnl_net >= self.min_timeout_profit_usdt
        ):
            return self.close_position(current_price, reason="TIMEOUT")

        # 5. Fade exit v2: запрещаем микроприбыльные выходы
        min_fade_profit = max(self.min_timeout_profit_usdt, 0.05)

        if p.max_pnl_net >= min_fade_profit and p.pnl_net > 0:
            giveback = p.max_pnl_net - p.pnl_net
            if p.max_pnl_net > 0:
                giveback_ratio = giveback / p.max_pnl_net
                if giveback_ratio >= self.fade_giveback_pct and p.pnl_net >= min_fade_profit:
                    return self.close_position(current_price, reason="FADE")

        # 6. Stall после TP1
        if (
            p.tp1_hit
            and p.tp1_time > 0
            and (now - p.tp1_time) >= self.tp1_stall_sec
            and p.pnl_net > 0
        ):
            return self.close_position(current_price, reason="STALL")

        # 7. Базовые TP / SL / BU
        reason = None

        if p.side == "long":
            if current_price <= p.sl:
                reason = "BU" if p.breakeven else "SL"
            elif p.tp1_hit and current_price >= p.tp2:
                reason = "TP2"
            elif not p.tp1_hit and current_price >= p.tp:
                reason = "TP1"
        else:
            if current_price >= p.sl:
                reason = "BU" if p.breakeven else "SL"
            elif p.tp1_hit and current_price <= p.tp2:
                reason = "TP2"
            elif not p.tp1_hit and current_price <= p.tp:
                reason = "TP1"

        if reason:
            return self.close_position(current_price, reason=reason)

        return None

    def close_position(self, current_price: float, reason: str = "MANUAL"):
        if not self.pos:
            return None

        p = self.pos
        self._update_unrealized(current_price)

        exit_price = self._exit_fill_price(current_price, p.side)

        if p.side == "long":
            gross = (exit_price - p.entry) * p.qty
        else:
            gross = (p.entry - exit_price) * p.qty

        close_notional = abs(exit_price * p.qty)
        fee_close = close_notional * self.taker_fee
        pnl = round(gross, 8)
        pnl_net = round(gross - p.fee_open - fee_close, 8)

        # Возвращаем маржу + результат
        self.balance += p.margin + pnl_net

        result = {
            "code": "00000",
            "data": {
                "symbol": p.symbol,
                "side": p.side.upper(),
                "qty": round(p.qty, 8),
                "entry": p.entry,
                "exit_price": round(exit_price, 8),
                "pnl": pnl,
                "pnl_net": pnl_net,
                "reason": reason,
                "tp1_hit": p.tp1_hit,
                "breakeven": p.breakeven,
                "close_time": time.time(),
                "setup_type": p.setup_type,
                "args_text": p.args_text,
            },
        }

        self.history.append(result["data"])
        self.pos = None
        return result