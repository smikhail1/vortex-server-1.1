import asyncio
from collections import deque
from typing import Deque, Dict, List, Optional

from config import CONFIG
from market_regime import MarketRegimeEvaluator
from validators import safe_float


class TAService:
    """
    Усиленный TA слой.

    Берёт:
    - state.market.prices

    Пишет:
    - state.market.ta_data

    Даёт:
    - trend_4h
    - trend_bias_30m
    - market_regime
    - breakout / retest / pullback contexts
    - near_support / near_resistance
    """

    def __init__(self, state_manager, logger=None) -> None:
        self.state = state_manager
        self.logger = logger
        self.history: Dict[str, Deque[float]] = {}
        self.regime = MarketRegimeEvaluator()

    @staticmethod
    def _ema(values: List[float], period: int) -> float:
        if not values:
            return 0.0
        k = 2 / (period + 1)
        ema_val = float(values[0])
        for v in values[1:]:
            ema_val = float(v) * k + ema_val * (1 - k)
        return ema_val

    @staticmethod
    def _rsi_proxy(values: List[float]) -> float:
        if len(values) < 15:
            return 50.0

        ups = []
        downs = []

        for i in range(-14, 0):
            delta = values[i] - values[i - 1]
            if delta >= 0:
                ups.append(delta)
                downs.append(0.0)
            else:
                ups.append(0.0)
                downs.append(abs(delta))

        avg_up = sum(ups) / len(ups) if ups else 0.0
        avg_down = sum(downs) / len(downs) if downs else 0.0

        if avg_down == 0:
            return 100.0 if avg_up > 0 else 50.0

        rs = avg_up / avg_down
        return 100.0 - (100.0 / (1.0 + rs))

    def _ensure_history(self, symbol: str) -> None:
        if symbol not in self.history:
            self.history[symbol] = deque(maxlen=120)

    def _avg_abs_move(self, arr: List[float], lookback: int = 14) -> float:
        if len(arr) < 2:
            return 0.0
        tail = arr[-(lookback + 1):]
        diffs = [abs(tail[i] - tail[i - 1]) for i in range(1, len(tail))]
        return sum(diffs) / len(diffs) if diffs else 0.0

    def _build_symbol_ta(self, symbol: str, price: float) -> Optional[Dict[str, object]]:
        if price <= 0:
            return None

        self._ensure_history(symbol)
        self.history[symbol].append(price)
        arr = list(self.history[symbol])

        if len(arr) < 3:
            return None

        ema10 = self._ema(arr[-10:] if len(arr) >= 10 else arr, 10)
        ema20 = self._ema(arr[-20:] if len(arr) >= 20 else arr, 20)
        ema50 = self._ema(arr[-50:] if len(arr) >= 50 else arr, 50)

        avg_move = self._avg_abs_move(arr, 14)
        last_move = abs(arr[-1] - arr[-2]) if len(arr) >= 2 else 0.0
        atr = max(avg_move * 2.2, price * 0.002)
        atr_pct = (atr / price) * 100 if price > 0 else 0.0
        vol_ratio = max(last_move / avg_move, 1.0) if avg_move > 0 else 1.0

        recent = arr[-20:] if len(arr) >= 20 else arr
        prev_recent = recent[:-1] if len(recent) > 1 else recent

        recent_high = max(prev_recent) if prev_recent else price
        recent_low = min(prev_recent) if prev_recent else price
        recent_mid = (recent_high + recent_low) / 2 if recent_high > recent_low else price

        breakout = False
        breakout_dir = ""
        breakout_level = 0.0

        if price > recent_high + atr * CONFIG.regime.breakout_buffer_atr:
            breakout = True
            breakout_dir = "up"
            breakout_level = recent_high
        elif price < recent_low - atr * CONFIG.regime.breakout_buffer_atr:
            breakout = True
            breakout_dir = "down"
            breakout_level = recent_low

        near_support = price <= (recent_low + atr * 0.40)
        near_resistance = price >= (recent_high - atr * 0.40)

        zone_buffer = price * CONFIG.regime.pullback_zone_buffer_pct
        ema50_tol = price * CONFIG.regime.pullback_ema50_tolerance_pct

        pullback_long_ready = (
            price > ema50 * 0.995
            and price <= ema20 + zone_buffer
            and price >= ema50 - ema50_tol
            and ema20 >= ema50
        )

        pullback_short_ready = (
            price < ema50 * 1.005
            and price >= ema20 - zone_buffer
            and price <= ema50 + ema50_tol
            and ema20 <= ema50
        )

        retest_long_ready = (
            breakout_dir == "up"
            and breakout_level > 0
            and abs(price - breakout_level) <= atr * CONFIG.regime.retest_buffer_atr
        )

        retest_short_ready = (
            breakout_dir == "down"
            and breakout_level > 0
            and abs(price - breakout_level) <= atr * CONFIG.regime.retest_buffer_atr
        )

        setup_zone = "-"
        if near_support:
            setup_zone = "support"
        elif near_resistance:
            setup_zone = "resistance"
        elif abs(price - ema20) <= zone_buffer:
            setup_zone = "ema20"
        elif abs(price - ema50) <= ema50_tol:
            setup_zone = "ema50"

        rsi = self._rsi_proxy(arr)

        base = {
            "price": round(price, 8),
            "ema10": round(ema10, 8),
            "ema20": round(ema20, 8),
            "ema50": round(ema50, 8),
            "rsi": round(rsi, 2),
            "rsi_main": round(rsi, 2),
            "atr": round(atr, 8),
            "atr_pct": round(atr_pct, 4),
            "vol_ratio": round(vol_ratio, 4),
            "recent_high": round(recent_high, 8),
            "recent_low": round(recent_low, 8),
            "recent_mid": round(recent_mid, 8),
            "dist_to_support": round(((price - recent_low) / price) * 100, 4) if price > 0 else 0.0,
            "dist_to_resistance": round(((recent_high - price) / price) * 100, 4) if price > 0 else 0.0,
            "imbalance": 1.0,
            "breakout": breakout,
            "breakout_dir": breakout_dir,
            "breakout_level": round(breakout_level, 8),
            "near_support": near_support,
            "near_resistance": near_resistance,
            "pullback_long_ready": pullback_long_ready,
            "pullback_short_ready": pullback_short_ready,
            "retest_long_ready": retest_long_ready,
            "retest_short_ready": retest_short_ready,
            "setup_zone": setup_zone,
        }

        regime_ctx = self.regime.build_symbol_context(base)
        base.update(regime_ctx)

        return base

    async def loop(self) -> None:
        while True:
            try:
                dash = await self.state.get_dashboard_state()
                prices = dash.get("market", {}).get("prices", {}) or {}

                ta_data: Dict[str, Dict[str, object]] = {}

                for symbol, raw_price in prices.items():
                    price = safe_float(raw_price, 0.0)
                    item = self._build_symbol_ta(symbol, price)
                    if item is not None:
                        ta_data[symbol] = item

                await self.state.update_ta_data(ta_data)

            except Exception as exc:
                await self.state.add_sys_log("❌ [TA]", str(exc))
                if self.logger:
                    self.logger.error("TA_SERVICE", "ta loop failed", {"error": str(exc)})

            await asyncio.sleep(CONFIG.loops.ta_sec)