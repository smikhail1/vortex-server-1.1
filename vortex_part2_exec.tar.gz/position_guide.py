import time
from typing import Any, Dict, Optional

from config import CONFIG
from validators import safe_float, safe_str


class PositionGuide:
    """
    VORTEX 1.5 Position Guide.

    Active, always-on position management layer for ONE futures position.
    It does not open trades. It only protects, trails, or closes an existing trade.

    Decision contract:
    {
        "action": "HOLD" | "MOVE_SL" | "CLOSE",
        "reason": str,
        "new_sl": float,
        "meta": dict,
    }
    """

    def __init__(self) -> None:
        guide_cfg = getattr(CONFIG, "position_guide", None)

        self.enabled = bool(getattr(guide_cfg, "enabled", True))
        self.be_trigger_usdt = safe_float(getattr(guide_cfg, "be_trigger_usdt", 0.10), 0.10)
        self.be_min_hold_sec = int(safe_float(getattr(guide_cfg, "be_min_hold_sec", 180), 180))

        self.trail_trigger_usdt = safe_float(getattr(guide_cfg, "trail_trigger_usdt", 0.18), 0.18)
        self.trail_atr_mult = safe_float(getattr(guide_cfg, "trail_atr_mult", 1.20), 1.20)

        self.fade_min_max_pnl_usdt = safe_float(getattr(guide_cfg, "fade_min_max_pnl_usdt", 0.20), 0.20)
        self.fade_keep_ratio = safe_float(getattr(guide_cfg, "fade_keep_ratio", 0.55), 0.55)

        self.profit_lock_enabled = bool(getattr(guide_cfg, "profit_lock_enabled", True))
        self.profit_lock_min_max_pnl_usdt = safe_float(getattr(guide_cfg, "profit_lock_min_max_pnl_usdt", 0.18), 0.18)
        self.profit_lock_keep_ratio = safe_float(getattr(guide_cfg, "profit_lock_keep_ratio", 0.45), 0.45)
        self.profit_lock_min_net_usdt = safe_float(getattr(guide_cfg, "profit_lock_min_net_usdt", 0.06), 0.06)

        self.profit_timeout_sec = int(safe_float(getattr(guide_cfg, "profit_timeout_sec", 3600), 3600))
        self.profit_timeout_min_pnl_usdt = safe_float(
            getattr(guide_cfg, "profit_timeout_min_pnl_usdt", 0.10),
            0.10,
        )

        self.setup_died_enabled = bool(getattr(guide_cfg, "setup_died_enabled", True))
        self.setup_died_min_hold_sec = int(safe_float(getattr(guide_cfg, "setup_died_min_hold_sec", 600), 600))
        self.setup_died_score_lt = int(safe_float(getattr(guide_cfg, "setup_died_score_lt", 4), 4))

        self.early_bad_enabled = bool(getattr(guide_cfg, "early_bad_enabled", True))
        self.early_bad_min_hold_sec = int(safe_float(getattr(guide_cfg, "early_bad_min_hold_sec", 300), 300))
        self.early_bad_pnl_lt_usdt = safe_float(getattr(guide_cfg, "early_bad_pnl_lt_usdt", -0.12), -0.12)
        self.early_bad_score_lt = int(safe_float(getattr(guide_cfg, "early_bad_score_lt", 4), 4))

        # Anti-spam for GUIDE_TRAIL.
        # The guide still protects the position, but it will not move SL/log every tiny tick.
        self.trail_min_interval_sec = int(safe_float(getattr(guide_cfg, "trail_min_interval_sec", 30), 30))
        self.trail_min_sl_change_pct = safe_float(getattr(guide_cfg, "trail_min_sl_change_pct", 0.10), 0.10)
        self._last_trail_ts: Dict[str, float] = {}
        self._last_trail_sl: Dict[str, float] = {}

    def _hold(self, reason: str = "HOLD", meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return {
            "action": "HOLD",
            "reason": reason,
            "new_sl": 0.0,
            "meta": meta or {},
        }

    def _move_sl(self, reason: str, new_sl: float, meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return {
            "action": "MOVE_SL",
            "reason": reason,
            "new_sl": round(float(new_sl), 8),
            "meta": meta or {},
        }

    def _close(self, reason: str, meta: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return {
            "action": "CLOSE",
            "reason": reason,
            "new_sl": 0.0,
            "meta": meta or {},
        }


    def _profit_lock_sl(self, side: str, entry: float, qty: float, price: float, target_net: float) -> float:
        """Approximate SL price that preserves target_net USDT before fees."""
        if qty <= 0 or entry <= 0 or price <= 0 or target_net <= 0:
            return 0.0
        # Add a small fee/slippage buffer so the net result remains positive after closing.
        gross_target = target_net + 0.035
        if side == "long":
            value = entry + gross_target / qty
            return value if value < price else 0.0
        if side == "short":
            value = entry - gross_target / qty
            return value if value > price else 0.0
        return 0.0

    def _trail_allowed(self, symbol: str, new_sl: float, price: float, meta: Dict[str, Any]) -> bool:
        """Throttle micro trailing updates so logs/UI do not get flooded."""
        now = time.time()
        key = safe_str(symbol).upper()

        if not key:
            return True

        last_ts = safe_float(self._last_trail_ts.get(key), 0.0)
        last_sl = safe_float(self._last_trail_sl.get(key), 0.0)

        if last_sl <= 0:
            self._last_trail_ts[key] = now
            self._last_trail_sl[key] = float(new_sl)
            return True

        elapsed = now - last_ts
        base = abs(price) if price else abs(last_sl)
        if base <= 0:
            base = 1.0
        sl_change_pct = abs(float(new_sl) - last_sl) / base * 100.0

        if elapsed >= self.trail_min_interval_sec or sl_change_pct >= self.trail_min_sl_change_pct:
            self._last_trail_ts[key] = now
            self._last_trail_sl[key] = float(new_sl)
            meta["trail_elapsed_sec"] = round(elapsed, 3)
            meta["trail_sl_change_pct"] = round(sl_change_pct, 5)
            return True

        meta["trail_throttled"] = True
        meta["trail_elapsed_sec"] = round(elapsed, 3)
        meta["trail_sl_change_pct"] = round(sl_change_pct, 5)
        return False

    def evaluate(
        self,
        position: Dict[str, Any],
        current_price: float,
        ta_item: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if not self.enabled:
            return self._hold("GUIDE_DISABLED")

        if not position:
            return self._hold("NO_POSITION")

        symbol = safe_str(position.get("symbol")).upper()
        side = safe_str(position.get("side")).lower()
        entry = safe_float(position.get("entry"), 0.0)
        qty = safe_float(position.get("qty"), 0.0)
        sl = safe_float(position.get("sl"), 0.0)
        atr = safe_float(position.get("atr"), 0.0)
        pnl_net = safe_float(position.get("pnl_net"), 0.0)
        max_pnl_net = safe_float(position.get("max_pnl_net"), 0.0)
        hold_sec = int(safe_float(position.get("hold_sec"), 0.0))
        tp1_hit = bool(position.get("tp1_hit", False))
        breakeven = bool(position.get("breakeven", False))

        price = safe_float(current_price, 0.0)
        ta = ta_item or {}
        score = int(safe_float(ta.get("score", position.get("score", 0)), 0.0))

        if not symbol or side not in {"long", "short"} or entry <= 0 or price <= 0:
            return self._hold("BAD_POSITION_DATA")

        meta = {
            "symbol": symbol,
            "side": side.upper(),
            "entry": entry,
            "qty": qty,
            "price": price,
            "sl": sl,
            "atr": atr,
            "pnl_net": pnl_net,
            "max_pnl_net": max_pnl_net,
            "hold_sec": hold_sec,
            "score": score,
            "tp1_hit": tp1_hit,
            "breakeven": breakeven,
        }

        # 1) Early bad trade cut: if trade is in loss and current structure/score is weak.
        if (
            self.early_bad_enabled
            and hold_sec >= self.early_bad_min_hold_sec
            and pnl_net <= self.early_bad_pnl_lt_usdt
            and score > 0
            and score < self.early_bad_score_lt
        ):
            return self._close("EARLY_BAD_TRADE", meta)

        # 2) Profit lock / fade: protect a trade that already had real profit.
        if max_pnl_net >= self.profit_lock_min_max_pnl_usdt:
            lock_level = max(max_pnl_net * self.profit_lock_keep_ratio, self.profit_lock_min_net_usdt)
            meta["profit_lock_level"] = round(lock_level, 8)
            if self.profit_lock_enabled and qty > 0:
                lock_sl = self._profit_lock_sl(side, entry, qty, price, lock_level)
                if lock_sl > 0:
                    if side == "long" and (sl <= 0 or lock_sl > sl):
                        return self._move_sl("GUIDE_PROFIT_LOCK", lock_sl, meta)
                    if side == "short" and (sl <= 0 or lock_sl < sl):
                        return self._move_sl("GUIDE_PROFIT_LOCK", lock_sl, meta)

        if max_pnl_net >= self.fade_min_max_pnl_usdt:
            keep_level = max(max_pnl_net * self.fade_keep_ratio, self.profit_lock_min_net_usdt)
            if pnl_net <= keep_level:
                meta["keep_level"] = round(keep_level, 8)
                meta["giveback"] = round(max_pnl_net - pnl_net, 8)
                return self._close("FADE", meta)

        # 3) Profit timeout: if profit exists but target is too far, take money.
        if hold_sec >= self.profit_timeout_sec and pnl_net >= self.profit_timeout_min_pnl_usdt:
            return self._close("PROFIT_TIMEOUT", meta)

        # 4) Setup died: if score collapses after some time, don't wait blindly.
        if (
            self.setup_died_enabled
            and hold_sec >= self.setup_died_min_hold_sec
            and score > 0
            and score < self.setup_died_score_lt
        ):
            return self._close("SETUP_DIED", meta)

        # 5) Breakeven protection: protect small but real profit.
        if pnl_net >= self.be_trigger_usdt and hold_sec >= self.be_min_hold_sec and not breakeven:
            new_sl = entry
            if side == "long" and (sl <= 0 or new_sl > sl):
                return self._move_sl("BE_PROTECT", new_sl, meta)
            if side == "short" and (sl <= 0 or new_sl < sl):
                return self._move_sl("BE_PROTECT", new_sl, meta)

        # 6) ATR trailing after stronger profit.
        if pnl_net >= self.trail_trigger_usdt and atr > 0:
            if side == "long":
                new_sl = price - atr * self.trail_atr_mult
                if sl <= 0 or new_sl > sl:
                    if self._trail_allowed(symbol, new_sl, price, meta):
                        return self._move_sl("GUIDE_TRAIL", new_sl, meta)
                    return self._hold("GUIDE_TRAIL_THROTTLED", meta)
            else:
                new_sl = price + atr * self.trail_atr_mult
                if sl <= 0 or new_sl < sl:
                    if self._trail_allowed(symbol, new_sl, price, meta):
                        return self._move_sl("GUIDE_TRAIL", new_sl, meta)
                    return self._hold("GUIDE_TRAIL_THROTTLED", meta)

        return self._hold("NO_ACTION", meta)
