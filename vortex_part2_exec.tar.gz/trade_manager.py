import time

import aiohttp
from typing import Any, Dict, Optional

from validators import safe_float, safe_str
from position_guide import PositionGuide


class TradeManager:
    """
    VORTEX 1.5 Trade Manager.

    Contract with main.py:
    - TradeManager(logger=logger, position_state_engine=position_state_engine)
    - await trade_manager.loop(state=state, router=router, trade_logger=logger, risk_manager=risk_manager)

    Key fix:
    - exits/TP1/TRAIL must NOT depend only on cached state price;
    - for active futures position we fetch fresh Bitget futures ticker directly.
    """

    def __init__(self, logger=None, position_state_engine=None) -> None:
        self.logger = logger
        self.position_state_engine = position_state_engine
        self._price_cache: Dict[str, float] = {}
        self.guide = PositionGuide()
        self._price_diff_warn_ts: Dict[str, float] = {}

    async def loop(self, state, router, trade_logger=None, risk_manager=None, open_close_lock=None) -> None:
        await self.process_futures(
            state=state,
            router=router,
            trade_logger=trade_logger,
            risk_manager=risk_manager,
            open_close_lock=open_close_lock,
        )

        await self.process_spot(
            state=state,
            router=router,
            trade_logger=trade_logger,
            risk_manager=risk_manager,
        )

    # ==========================================================
    # Logging helpers
    # ==========================================================

    def _log_info(self, category: str, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        if self.logger:
            try:
                self.logger.info(category, message, extra or {})
            except Exception:
                pass

    def _log_warning(self, category: str, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        if self.logger:
            try:
                self.logger.warning(category, message, extra or {})
            except Exception:
                pass

    def _log_error(self, category: str, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        if self.logger:
            try:
                self.logger.error(category, message, extra or {})
            except Exception:
                pass

    async def _add_sys_log(self, state, tag: str, message: str) -> None:
        try:
            await state.add_sys_log(tag, message)
        except Exception:
            pass

    # ==========================================================
    # Position helpers
    # ==========================================================

    def _position_to_dict(self, pos: Any) -> Dict[str, Any]:
        if pos is None:
            return {}

        if isinstance(pos, dict):
            return pos

        data: Dict[str, Any] = {}

        for key in [
            "symbol",
            "side",
            "qty",
            "entry",
            "tp",
            "tp2",
            "sl",
            "pnl",
            "pnl_net",
            "setup_type",
            "args_text",
            "opened_at",
            "open_ts",
            "atr",
            "mark_price",
            "tp1_hit",
            "breakeven",
        ]:
            if hasattr(pos, key):
                data[key] = getattr(pos, key)

        return data

    def _get_futures_position(self, router) -> Dict[str, Any]:
        try:
            if hasattr(router, "get_futures_position"):
                return self._position_to_dict(router.get_futures_position())

            return self._position_to_dict(getattr(router, "fut_position", None))
        except Exception:
            return {}

    def _get_spot_positions(self, router) -> Dict[str, Dict[str, Any]]:
        try:
            if hasattr(router, "get_all_spot_positions"):
                raw = router.get_all_spot_positions()
            else:
                raw = getattr(router, "spot_positions", {}) or {}

            if isinstance(raw, dict):
                return {
                    safe_str(k).upper(): self._position_to_dict(v)
                    for k, v in raw.items()
                }

            if isinstance(raw, list):
                out: Dict[str, Dict[str, Any]] = {}

                for item in raw:
                    pos = self._position_to_dict(item)
                    sym = safe_str(pos.get("symbol")).upper()

                    if sym:
                        out[sym] = pos

                return out

            return {}

        except Exception:
            return {}

    # ==========================================================
    # Price helpers
    # ==========================================================

    def _get_cached_state_price(self, symbol: str, state_snapshot: Dict[str, Any]) -> float:
        symbol = safe_str(symbol).upper()

        market = state_snapshot.get("market", {}) or {}
        prices = market.get("prices", {}) or {}
        ta_data = market.get("ta_data", {}) or {}

        price = safe_float(prices.get(symbol), 0.0)

        if price <= 0:
            price = safe_float((ta_data.get(symbol) or {}).get("price"), 0.0)

        if price <= 0:
            price = safe_float(self._price_cache.get(symbol), 0.0)

        return price

    async def _fetch_bitget_futures_price(self, symbol: str) -> float:
        symbol = safe_str(symbol).upper()

        if not symbol:
            return 0.0

        url = "https://api.bitget.com/api/v2/mix/market/ticker"
        params = {
            "symbol": symbol,
            "productType": "USDT-FUTURES",
        }

        try:
            timeout = aiohttp.ClientTimeout(total=5)

            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, params=params) as resp:
                    if resp.status != 200:
                        return 0.0

                    payload = await resp.json()

            if safe_str(payload.get("code")) != "00000":
                return 0.0

            data = payload.get("data") or {}

            if isinstance(data, list):
                data = data[0] if data else {}

            for key in ["markPrice", "lastPr", "last", "close", "price"]:
                price = safe_float(data.get(key), 0.0)

                if price > 0:
                    self._price_cache[symbol] = price
                    return price

            return 0.0

        except Exception as exc:
            self._log_warning(
                "TRADE_MANAGER",
                "live futures price fetch failed",
                {
                    "symbol": symbol,
                    "error": str(exc),
                },
            )
            return 0.0

    async def _get_futures_price(self, symbol: str, state_snapshot: Dict[str, Any]) -> float:
        cached_price = self._get_cached_state_price(symbol, state_snapshot)
        live_price = await self._fetch_bitget_futures_price(symbol)

        if live_price > 0:
            if cached_price > 0:
                diff_pct = abs(live_price - cached_price) / cached_price * 100.0

                if diff_pct >= 1.0:
                    now = time.time()
                    last_warn = self._price_diff_warn_ts.get(symbol, 0.0)
                    if now - last_warn >= 60.0:
                        self._price_diff_warn_ts[symbol] = now
                        self._log_warning(
                            "TRADE_MANAGER",
                            "state price differs from live futures price",
                            {
                                "symbol": symbol,
                                "state_price": cached_price,
                                "live_price": live_price,
                                "diff_pct": round(diff_pct, 4),
                            },
                        )

            return live_price

        return cached_price

    def _get_ta_item(self, symbol: str, state_snapshot: Dict[str, Any]) -> Dict[str, Any]:
        symbol = safe_str(symbol).upper()
        market = state_snapshot.get("market", {}) or {}
        ta_data = market.get("ta_data", {}) or {}
        item = ta_data.get(symbol) or {}
        return item if isinstance(item, dict) else {}

    # ==========================================================
    # Risk / event helpers
    # ==========================================================

    def _safe_register_close(self, risk_manager, symbol: str, market: str, pnl_net: float, reason: str = "CLOSE") -> None:
        # v1.7.5.1: pass close reason into RiskManager.
        if risk_manager is None:
            return

        close_reason = safe_str(reason, "CLOSE")

        for args in [
            (symbol, market, pnl_net, close_reason),
            (symbol, market, pnl_net),
            (symbol, market),
        ]:
            try:
                risk_manager.register_close(*args)
                return
            except TypeError:
                continue
            except Exception:
                return

    def _safe_position_event(self, event: str, payload: Dict[str, Any]) -> None:
        # v1.7.5.1: direct lifecycle bridge into PositionStateEngine.
        engine = self.position_state_engine

        if engine is None:
            return

        event_u = safe_str(event).upper()
        data = payload if isinstance(payload, dict) else {}
        symbol = safe_str(data.get("symbol")).upper()
        market = safe_str(data.get("market")).upper()
        price = safe_float(data.get("price", data.get("exit_price", data.get("exit"))), 0.0)
        pnl_net = safe_float(data.get("pnl_net"), 0.0)
        reason = safe_str(data.get("reason") or data.get("event") or event_u, event_u)

        if event_u == "CLOSED" and hasattr(engine, "close"):
            try:
                engine.close(
                    symbol,
                    market,
                    {
                        "reason": reason,
                        "exit_price": price,
                        "pnl_net": pnl_net,
                        "pnl": safe_float(data.get("pnl"), pnl_net),
                        "data": data.get("data", data),
                    },
                )
                return
            except Exception:
                pass

        for method_name in [
            "record_event",
            "on_event",
            "handle_event",
            "update_event",
            "update_from_event",
        ]:
            method = getattr(engine, method_name, None)

            if not callable(method):
                continue

            try:
                method(event_u, data)
                return
            except TypeError:
                try:
                    method(data)
                    return
                except Exception:
                    return
            except Exception:
                return

    def _safe_position_update_obj(self, pos: Any, market: str, current_price: float = 0.0) -> None:
        # v1.7.5.1: keep PositionStateEngine synchronized for FUT and SPOT.
        engine = self.position_state_engine

        if engine is None or pos is None:
            return

        try:
            if hasattr(engine, "update_from_position"):
                engine.update_from_position(pos, market, current_price=current_price)
                return
        except TypeError:
            try:
                engine.update_from_position(pos, market)
                return
            except Exception:
                return
        except Exception:
            return

    def _safe_log_trade(self, trade_logger, data: Dict[str, Any], fallback_pos: Dict[str, Any], market: str) -> None:
        if trade_logger is None or not hasattr(trade_logger, "log_trade"):
            return

        symbol = safe_str(data.get("symbol") or fallback_pos.get("symbol")).upper()
        side = safe_str(data.get("side") or fallback_pos.get("side")).upper()

        entry = safe_float(data.get("entry"), 0.0)

        if entry <= 0:
            entry = safe_float(fallback_pos.get("entry"), 0.0)

        tp = safe_float(data.get("tp"), 0.0)

        if tp <= 0:
            tp = safe_float(fallback_pos.get("tp"), 0.0)

        exit_price = safe_float(
            data.get("exit_price", data.get("exit", data.get("price"))),
            0.0,
        )

        pnl = safe_float(data.get("pnl"), 0.0)
        pnl_net = safe_float(data.get("pnl_net"), pnl)
        reason = safe_str(data.get("reason"), "CLOSE")
        hold_sec = int(safe_float(data.get("hold_sec"), 0.0))

        setup_type = safe_str(data.get("setup_type") or fallback_pos.get("setup_type"))
        args_text = safe_str(data.get("args_text") or fallback_pos.get("args_text"))

        try:
            trade_logger.log_trade(
                symbol=symbol,
                side=side,
                market=market,
                entry=entry,
                tp=tp,
                exit_price=exit_price,
                pnl=pnl,
                pnl_net=pnl_net,
                reason=reason,
                hold_sec=hold_sec,
                setup_type=setup_type,
                args_text=args_text,
            )
        except Exception:
            pass

    async def _handle_futures_result(
        self,
        state,
        result,
        symbol: str,
        price: float,
        fallback_pos: Dict[str, Any],
        trade_logger=None,
        risk_manager=None,
    ) -> None:
        if result is None:
            return

        if not isinstance(result, dict):
            self._log_warning(
                "TRADE_MANAGER",
                "futures check returned invalid result",
                {"symbol": symbol, "price": price, "result": str(result)},
            )
            return

        if result.get("code") != "00000":
            self._log_warning(
                "TRADE_MANAGER",
                "futures check returned non-ok",
                {"symbol": symbol, "price": price, "result": result},
            )
            return

        data = result.get("data") or {}
        reason = safe_str(data.get("reason"), "EVENT")
        pnl_net = safe_float(data.get("pnl_net"), safe_float(data.get("pnl"), 0.0))
        exit_price = safe_float(data.get("exit_price", data.get("exit", data.get("price"))), price)

        if data.get("event_only"):
            msg = f"{symbol} {reason} @ {exit_price:.8f} | pnl_net={pnl_net:.6f}"
            await self._add_sys_log(state, "🟡 [FUT EVENT]", msg)
            self._log_info(
                "FUT EVENT",
                reason,
                {"symbol": symbol, "price": exit_price, "pnl_net": pnl_net, "data": data},
            )
            self._safe_position_event(
                reason,
                {
                    "symbol": symbol,
                    "market": "FUT",
                    "event": reason,
                    "price": exit_price,
                    "pnl_net": pnl_net,
                    "data": data,
                },
            )
            return

        if data.get("closed") or reason in {"SL", "TP1", "TP2", "BU", "BE", "TIMEOUT", "PROFIT_TIMEOUT", "FADE", "SETUP_DIED", "EARLY_BAD_TRADE", "STALL", "LIQ"}:
            msg = f"{symbol} CLOSED {reason} @ {exit_price:.8f} | pnl_net={pnl_net:.6f}"
            await self._add_sys_log(state, "🔴 [FUT CLOSED]", msg)
            self._log_info(
                "FUT CLOSED",
                reason,
                {"symbol": symbol, "price": exit_price, "pnl_net": pnl_net, "data": data},
            )
            self._safe_log_trade(
                trade_logger=trade_logger,
                data=data,
                fallback_pos=fallback_pos,
                market="FUT",
            )
            self._safe_register_close(
                risk_manager=risk_manager,
                symbol=symbol,
                market="fut",
                pnl_net=pnl_net,
                reason=reason,
            )
            self._safe_position_event(
                "CLOSED",
                {
                    "symbol": symbol,
                    "market": "FUT",
                    "reason": reason,
                    "price": exit_price,
                    "pnl_net": pnl_net,
                    "data": data,
                },
            )

    # ==========================================================
    # Futures
    # ==========================================================

    async def process_futures(self, state, router, trade_logger=None, risk_manager=None, open_close_lock=None) -> None:
        pos = self._get_futures_position(router)

        if not pos:
            return

        symbol = safe_str(pos.get("symbol")).upper()

        if not symbol:
            return

        dashboard = await state.get_dashboard_state()
        price = await self._get_futures_price(symbol, dashboard)

        if price <= 0:
            return

        # v1.7.5.1: sync futures lifecycle state.
        try:
            self._safe_position_update_obj(router.get_futures_position(), "FUT", current_price=price)
        except Exception:
            pass

        ta_item = self._get_ta_item(symbol, dashboard)
        live_pos = self._get_futures_position(router)
        guide_decision = self.guide.evaluate(live_pos, price, ta_item=ta_item)
        guide_action = safe_str(guide_decision.get("action"), "HOLD").upper()
        guide_reason = safe_str(guide_decision.get("reason"), "HOLD")

        if guide_action == "CLOSE":
            # VORTEX v1.6.1.1 HOTFIX: close/register under shared lock.
            lock = open_close_lock
            try:
                if lock is not None:
                    async with lock:
                        result = router.close_futures_position(price, reason=guide_reason)
                        await self._handle_futures_result(
                            state=state,
                            result=result,
                            symbol=symbol,
                            price=price,
                            fallback_pos=pos,
                            trade_logger=trade_logger,
                            risk_manager=risk_manager,
                        )
                else:
                    result = router.close_futures_position(price, reason=guide_reason)
                    await self._handle_futures_result(
                        state=state,
                        result=result,
                        symbol=symbol,
                        price=price,
                        fallback_pos=pos,
                        trade_logger=trade_logger,
                        risk_manager=risk_manager,
                    )
            except Exception as exc:
                self._log_error(
                    "TRADE_MANAGER",
                    "guide close failed",
                    {"symbol": symbol, "price": price, "reason": guide_reason, "error": str(exc)},
                )
            return

        if guide_action == "MOVE_SL":
            new_sl = safe_float(guide_decision.get("new_sl"), 0.0)
            if new_sl > 0 and hasattr(router, "update_futures_sl"):
                try:
                    guide_result = router.update_futures_sl(new_sl, reason=guide_reason)
                except Exception as exc:
                    self._log_error(
                        "TRADE_MANAGER",
                        "guide sl update failed",
                        {"symbol": symbol, "new_sl": new_sl, "reason": guide_reason, "error": str(exc)},
                    )
                    guide_result = None
                if guide_result is not None:
                    await self._handle_futures_result(
                        state=state,
                        result=guide_result,
                        symbol=symbol,
                        price=price,
                        fallback_pos=pos,
                        trade_logger=trade_logger,
                        risk_manager=risk_manager,
                    )

        try:
            lock = open_close_lock
            if lock is not None:
                async with lock:
                    result = router.check_futures_position(price)
                    await self._handle_futures_result(
                        state=state,
                        result=result,
                        symbol=symbol,
                        price=price,
                        fallback_pos=pos,
                        trade_logger=trade_logger,
                        risk_manager=risk_manager,
                    )
            else:
                result = router.check_futures_position(price)
                await self._handle_futures_result(
                    state=state,
                    result=result,
                    symbol=symbol,
                    price=price,
                    fallback_pos=pos,
                    trade_logger=trade_logger,
                    risk_manager=risk_manager,
                )
        except Exception as exc:
            self._log_error(
                "TRADE_MANAGER",
                "futures check failed",
                {
                    "symbol": symbol,
                    "price": price,
                    "error": str(exc),
                },
            )
            return

    # ==========================================================
    # Spot
    # ==========================================================

    async def process_spot(self, state, router, trade_logger=None, risk_manager=None) -> None:
        positions = self._get_spot_positions(router)

        if not positions:
            return

        dashboard = await state.get_dashboard_state()

        for symbol, pos in list(positions.items()):
            price = self._get_cached_state_price(symbol, dashboard)

            if price <= 0:
                continue

            # v1.7.5.1: sync spot lifecycle state.
            try:
                self._safe_position_update_obj(router.get_spot_position(symbol), "SPOT", current_price=price)
            except Exception:
                pass

            try:
                result = router.check_spot_position(symbol, price)
            except Exception as exc:
                self._log_error(
                    "TRADE_MANAGER",
                    "spot check failed",
                    {
                        "symbol": symbol,
                        "price": price,
                        "error": str(exc),
                    },
                )
                continue

            # None = HOLD / no event.
            if result is None:
                continue

            if not isinstance(result, dict):
                self._log_warning(
                    "TRADE_MANAGER",
                    "spot check returned invalid result",
                    {
                        "symbol": symbol,
                        "price": price,
                        "result": str(result),
                    },
                )
                continue

            if result.get("code") != "00000":
                self._log_warning(
                    "TRADE_MANAGER",
                    "spot check returned non-ok",
                    {
                        "symbol": symbol,
                        "price": price,
                        "result": result,
                    },
                )
                continue

            data = result.get("data") or {}
            reason = safe_str(data.get("reason"), "EVENT")
            pnl_net = safe_float(data.get("pnl_net"), safe_float(data.get("pnl"), 0.0))
            exit_price = safe_float(data.get("exit_price", data.get("exit", data.get("price"))), price)

            if data.get("event_only"):
                msg = f"{symbol} {reason} @ {exit_price:.8f} | pnl_net={pnl_net:.6f}"

                await self._add_sys_log(state, "🟡 [SPOT EVENT]", msg)

                self._log_info(
                    "SPOT EVENT",
                    reason,
                    {
                        "symbol": symbol,
                        "price": exit_price,
                        "pnl_net": pnl_net,
                        "data": data,
                    },
                )

                self._safe_position_event(
                    reason,
                    {
                        "symbol": symbol,
                        "market": "SPOT",
                        "event": reason,
                        "price": exit_price,
                        "pnl_net": pnl_net,
                        "data": data,
                    },
                )

                continue

            if data.get("closed") or reason in {"SL", "TP1", "TP2", "BU", "BE", "TIMEOUT", "FADE", "STALL"}:
                msg = f"{symbol} CLOSED {reason} @ {exit_price:.8f} | pnl_net={pnl_net:.6f}"

                await self._add_sys_log(state, "🔴 [SPOT CLOSED]", msg)

                self._log_info(
                    "SPOT CLOSED",
                    reason,
                    {
                        "symbol": symbol,
                        "price": exit_price,
                        "pnl_net": pnl_net,
                        "data": data,
                    },
                )

                self._safe_log_trade(
                    trade_logger=trade_logger,
                    data=data,
                    fallback_pos=pos,
                    market="SPOT",
                )

                self._safe_register_close(
                    risk_manager=risk_manager,
                    symbol=symbol,
                    market="spot",
                    pnl_net=pnl_net,
                    reason=reason,
                )

                self._safe_position_event(
                    "CLOSED",
                    {
                        "symbol": symbol,
                        "market": "SPOT",
                        "reason": reason,
                        "price": exit_price,
                        "pnl_net": pnl_net,
                        "data": data,
                    },
                )