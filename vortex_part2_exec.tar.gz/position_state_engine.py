import time
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

from config import CONFIG
from validators import normalize_symbol, safe_bool, safe_float, safe_str


@dataclass
class PositionEvent:
    ts: float
    event: str
    message: str = ""
    price: float = 0.0
    pnl: float = 0.0
    pnl_net: float = 0.0
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PositionState:
    trade_id: str
    symbol: str
    market: str
    side: str
    state: str
    entry: float
    current_price: float
    qty: float
    tp: float
    tp2: float
    sl: float
    trail_sl: float
    pnl: float
    pnl_net: float
    max_pnl_net: float
    max_drawdown_net: float
    open_time: float
    updated_at: float
    hold_sec: int
    setup_type: str = ""
    args_text: str = ""
    tp1_hit: bool = False
    breakeven: bool = False
    trail_active: bool = False
    close_reason: str = ""
    closed_at: float = 0.0
    events: List[PositionEvent] = field(default_factory=list)


class PositionStateEngine:
    """
    VORTEX 1.5 Position State Engine.

    Responsibility:
    - track every open/closed position as stateful lifecycle object;
    - log state transitions: OPENED -> TP1_HIT -> BREAKEVEN_ARMED -> TRAILING_ACTIVE -> CLOSED;
    - expose /api/positions/state snapshot;
    - prepare architecture for REAL execution later: ORDER_SENT/FILLED/REJECTED/PARTIAL_FILL.

    This module does NOT place orders. Execution stays in ExecutionRouter / Paper / Real executors.
    """

    def __init__(self, logger=None) -> None:
        self.logger = logger
        self.enabled = bool(CONFIG.position_state.enabled)
        self.max_events = int(CONFIG.position_state.max_events_per_position)
        self.max_closed = int(CONFIG.position_state.max_closed_positions)
        self._open: Dict[str, PositionState] = {}
        self._closed: List[PositionState] = []

    def _make_trade_id(self, symbol: str, market: str, side: str, open_time: float) -> str:
        sym = normalize_symbol(symbol)
        mkt = safe_str(market).upper()
        side_u = safe_str(side).upper()
        return f"{mkt}-{sym}-{side_u}-{int(open_time)}"

    def _key(self, symbol: str, market: str) -> str:
        return f"{normalize_symbol(symbol)}::{safe_str(market).upper()}"

    def _event(self, state: PositionState, event: str, message: str = "", price: Any = 0.0, pnl: Any = 0.0, pnl_net: Any = 0.0, extra: Optional[Dict[str, Any]] = None) -> None:
        ev = PositionEvent(
            ts=time.time(),
            event=safe_str(event).upper(),
            message=safe_str(message),
            price=safe_float(price, 0.0),
            pnl=safe_float(pnl, 0.0),
            pnl_net=safe_float(pnl_net, 0.0),
            extra=extra or {},
        )
        state.events.append(ev)
        if len(state.events) > self.max_events:
            state.events = state.events[-self.max_events:]

        if self.logger:
            self.logger.info("POSITION_STATE", ev.event, {
                "trade_id": state.trade_id,
                "symbol": state.symbol,
                "market": state.market,
                "side": state.side,
                "state": state.state,
                "message": ev.message,
                "price": ev.price,
                "pnl": ev.pnl,
                "pnl_net": ev.pnl_net,
                "extra": ev.extra,
            })

    def open_from_position(self, pos: Any, market: str) -> Optional[Dict[str, Any]]:
        if not self.enabled or pos is None:
            return None

        symbol = normalize_symbol(getattr(pos, "symbol", ""))
        if not symbol:
            return None

        market_u = safe_str(market).upper()
        side = safe_str(getattr(pos, "side", "BUY")).upper()
        if market_u == "SPOT":
            side = "BUY"

        open_time = safe_float(getattr(pos, "open_time", time.time()), time.time())
        key = self._key(symbol, market_u)
        current = self._open.get(key)
        if current:
            return self.to_public(current)

        entry = safe_float(getattr(pos, "entry", getattr(pos, "avg_price", 0.0)), 0.0)
        tp = safe_float(getattr(pos, "tp", 0.0), 0.0)
        tp2 = safe_float(getattr(pos, "tp2", 0.0), 0.0)
        sl = safe_float(getattr(pos, "sl", 0.0), 0.0)
        trail_sl = safe_float(getattr(pos, "trail_sl", 0.0), sl)
        qty = safe_float(getattr(pos, "qty", 0.0), 0.0)

        state = PositionState(
            trade_id=self._make_trade_id(symbol, market_u, side, open_time),
            symbol=symbol,
            market=market_u,
            side=side,
            state="OPENED",
            entry=entry,
            current_price=safe_float(getattr(pos, "mark_price", entry), entry),
            qty=qty,
            tp=tp,
            tp2=tp2,
            sl=sl,
            trail_sl=trail_sl,
            pnl=safe_float(getattr(pos, "pnl", 0.0), 0.0),
            pnl_net=safe_float(getattr(pos, "pnl_net", 0.0), 0.0),
            max_pnl_net=safe_float(getattr(pos, "max_pnl_net", 0.0), 0.0),
            max_drawdown_net=min(0.0, safe_float(getattr(pos, "pnl_net", 0.0), 0.0)),
            open_time=open_time,
            updated_at=time.time(),
            hold_sec=max(0, int(time.time() - open_time)),
            setup_type=safe_str(getattr(pos, "setup_type", "")),
            args_text=safe_str(getattr(pos, "args_text", "")),
            tp1_hit=safe_bool(getattr(pos, "tp1_hit", False)),
            breakeven=safe_bool(getattr(pos, "breakeven", False)),
            trail_active=False,
        )
        self._open[key] = state
        self._event(state, "OPENED", "position opened", price=entry, pnl=state.pnl, pnl_net=state.pnl_net)
        return self.to_public(state)

    def update_from_position(self, pos: Any, market: str, current_price: Any = None) -> Optional[Dict[str, Any]]:
        if not self.enabled or pos is None:
            return None

        symbol = normalize_symbol(getattr(pos, "symbol", ""))
        market_u = safe_str(market).upper()
        key = self._key(symbol, market_u)
        if key not in self._open:
            return self.open_from_position(pos, market_u)

        state = self._open[key]
        previous_state = state.state
        previous_sl = state.sl
        previous_trail = state.trail_sl
        previous_tp1 = state.tp1_hit
        previous_be = state.breakeven

        px = safe_float(current_price, 0.0)
        if px <= 0:
            px = safe_float(getattr(pos, "mark_price", 0.0), 0.0)
        if px <= 0:
            px = state.current_price

        state.current_price = px
        state.qty = safe_float(getattr(pos, "qty", state.qty), state.qty)
        state.tp = safe_float(getattr(pos, "tp", state.tp), state.tp)
        state.tp2 = safe_float(getattr(pos, "tp2", state.tp2), state.tp2)
        state.sl = safe_float(getattr(pos, "sl", state.sl), state.sl)
        state.trail_sl = safe_float(getattr(pos, "trail_sl", state.trail_sl), state.trail_sl)
        state.pnl = safe_float(getattr(pos, "pnl", state.pnl), state.pnl)
        state.pnl_net = safe_float(getattr(pos, "pnl_net", state.pnl_net), state.pnl_net)
        state.max_pnl_net = max(state.max_pnl_net, safe_float(getattr(pos, "max_pnl_net", state.max_pnl_net), state.max_pnl_net), state.pnl_net)
        state.max_drawdown_net = min(state.max_drawdown_net, state.pnl_net)
        state.tp1_hit = safe_bool(getattr(pos, "tp1_hit", state.tp1_hit), state.tp1_hit)
        state.breakeven = safe_bool(getattr(pos, "breakeven", state.breakeven), state.breakeven)
        state.hold_sec = max(0, int(time.time() - state.open_time))
        state.updated_at = time.time()

        if state.tp1_hit and not previous_tp1:
            state.state = "TP1_HIT"
            self._event(state, "TP1_HIT", "tp1 reached", price=px, pnl=state.pnl, pnl_net=state.pnl_net)

        if state.breakeven and not previous_be:
            state.state = "BREAKEVEN_ARMED"
            self._event(state, "BREAKEVEN_ARMED", "stop moved to breakeven", price=px, pnl=state.pnl, pnl_net=state.pnl_net, extra={"sl": state.sl})

        if state.tp1_hit and state.trail_sl > 0 and abs(state.trail_sl - previous_trail) > 1e-12:
            state.trail_active = True
            state.state = "TRAILING_ACTIVE"
            self._event(state, "TRAIL_UPDATED", "trailing stop updated", price=px, pnl=state.pnl, pnl_net=state.pnl_net, extra={"trail_sl": state.trail_sl})

        if abs(state.sl - previous_sl) > 1e-12 and state.state not in {"TRAILING_ACTIVE"}:
            self._event(state, "SL_UPDATED", "stop updated", price=px, pnl=state.pnl, pnl_net=state.pnl_net, extra={"sl": state.sl})

        if state.state == previous_state and previous_state == "OPENED" and state.tp1_hit:
            state.state = "TP1_HIT"

        return self.to_public(state)

    def event_from_check_result(self, symbol: str, market: str, data: Dict[str, Any]) -> None:
        if not self.enabled or not data:
            return
        key = self._key(symbol, market)
        state = self._open.get(key)
        if not state:
            return

        reason = safe_str(data.get("reason"), "EVENT").upper()
        px = safe_float(data.get("exit_price"), state.current_price)
        pnl = safe_float(data.get("pnl"), state.pnl)
        pnl_net = safe_float(data.get("pnl_net"), state.pnl_net)

        if reason in {"FADE", "TIMEOUT", "STALL", "TP2", "SL", "BU", "LIQ", "MANUAL"}:
            event_name = f"{reason}_TRIGGERED" if reason in {"FADE", "TIMEOUT", "STALL"} else reason
            self._event(state, event_name, f"management event {reason}", price=px, pnl=pnl, pnl_net=pnl_net)

    def close(self, symbol: str, market: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if not self.enabled:
            return None

        key = self._key(symbol, market)
        state = self._open.pop(key, None)
        if state is None:
            return None

        reason = safe_str(data.get("reason"), "UNKNOWN").upper()
        px = safe_float(data.get("exit_price"), state.current_price)
        pnl = safe_float(data.get("pnl"), state.pnl)
        pnl_net = safe_float(data.get("pnl_net"), pnl)

        state.current_price = px
        state.pnl = pnl
        state.pnl_net = pnl_net
        state.max_pnl_net = max(state.max_pnl_net, pnl_net)
        state.max_drawdown_net = min(state.max_drawdown_net, pnl_net)
        state.state = "CLOSED"
        state.close_reason = reason
        state.closed_at = time.time()
        state.updated_at = state.closed_at
        state.hold_sec = max(0, int(state.closed_at - state.open_time))
        self._event(state, "CLOSED", f"position closed: {reason}", price=px, pnl=pnl, pnl_net=pnl_net, extra={"reason": reason})

        self._closed.append(state)
        if len(self._closed) > self.max_closed:
            self._closed = self._closed[-self.max_closed:]
        return self.to_public(state)

    def snapshot(self) -> Dict[str, Any]:
        open_items = [self.to_public(x) for x in self._open.values()]
        closed_items = [self.to_public(x, include_events=False) for x in self._closed[-20:]]
        open_items.sort(key=lambda x: safe_float(x.get("updated_at")), reverse=True)
        closed_items.sort(key=lambda x: safe_float(x.get("closed_at")), reverse=True)
        return {
            "enabled": self.enabled,
            "open": open_items,
            "closed_recent": closed_items,
            "counts": {
                "open": len(open_items),
                "closed_recent": len(closed_items),
            },
        }

    def to_public(self, state: PositionState, include_events: bool = True) -> Dict[str, Any]:
        data = asdict(state)
        if include_events:
            data["events"] = [asdict(e) for e in state.events]
        else:
            data["events"] = []
        return data
